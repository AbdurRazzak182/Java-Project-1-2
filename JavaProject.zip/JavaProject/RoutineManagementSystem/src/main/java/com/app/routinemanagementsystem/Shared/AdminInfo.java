package com.app.routinemanagementsystem.Shared;

import java.io.Serializable;

public class AdminInfo implements Serializable {

}
