package com.app.routinemanagementsystem.Shared;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Wrapper {
    Socket socket;
    ObjectOutputStream oos;
    ObjectInputStream ois;
    public Wrapper(Socket soc) throws IOException {
        socket=soc;
        oos=new ObjectOutputStream(socket.getOutputStream());
        ois=new ObjectInputStream(socket.getInputStream());
    }
    public Object read() throws IOException, ClassNotFoundException {
        return ois.readUnshared();
    }
    public void write(Object o) throws IOException {
        oos.writeUnshared(o);
    }
    public void closeConnection() throws IOException {
        oos.close();
        ois.close();
    }
}
