package com.app.routinemanagementsystem;

//import com.app.routinemanagementsystem.Shared.Wrapper;
//import src.main.java.app.demo.Shared.Wrapper;
import com.app.routinemanagementsystem.Shared.Wrapper;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
//import src.main.java.app.demo.shared.Wrapper;

import java.io.IOException;
import java.net.Socket;
//import com.app.server.Shared.Wrapper;


public class Main extends Application {

    public static Wrapper wrapper;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  703,574);

        LoginController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Homepage");
        stage.setScene(scene);
        stage.show();

        new Thread(() -> {
            try {
                Socket socket = new Socket("localhost", 12345);
                wrapper = new Wrapper(socket);
                System.out.println("Connected to server.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static void main(String[] args) {

        launch();
    }
}