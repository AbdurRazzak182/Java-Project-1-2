package files.project;

import files.project.ClientS.*;
import files.project.clientT.*;
import files.project.Structure.*;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.application.Platform;

import java.io.IOException;

public class LoginController {
    private Stage stage;
    ClientConnection conn;
    @FXML private TextField Id;
    @FXML private PasswordField password;
    @FXML private Button loginButton;
    @FXML private Label labelShow;

    public void setStage(Stage stage) { this.stage = stage; }
    public Stage getStage() { return stage; }
    public void setConn(ClientConnection conn){
        this.conn=conn;
    }

    @FXML
    public void onLogInButtonClick(ActionEvent actionEvent) {
        final String id = Id.getText().trim();
        final String passWord = password.getText().trim();

        if (id.isEmpty() || passWord.isEmpty()) {
            labelShow.setText("Please enter both ID and password.");
            labelShow.setStyle("-fx-text-fill: red;");
            return;
        }

        labelShow.setText("Logging in...");
        labelShow.setStyle("-fx-text-fill: #000dff;");

        // Run network call in background
        Task<Void> loginTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                // ClientConnection conn = ClientConnection.getInstance();
                try {
                    conn.send(id + "," + passWord);
                    String response = conn.receiveString();
                    handleLoginResponse(id, response);
                } catch (IOException e) {
                    Platform.runLater(() -> {
                        labelShow.setText("Error communicating with server.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };

        new Thread(loginTask, "LoginTask").start();
    }

    /** Process server login reply on JavaFX thread */
    private void handleLoginResponse(String id, String response) {
        Platform.runLater(() -> {
            if (response == null) {
                labelShow.setText("No response from server.");
                labelShow.setStyle("-fx-text-fill: red;");
                return;
            }

            if (response.startsWith("SUCCESS")) {
                // Format: SUCCESS,ROLE
                String role = "UNKNOWN";
                int idx = response.indexOf(',');
                if (idx >= 0 && idx < response.length() - 1) {
                    role = response.substring(idx + 1);
                }


                labelShow.setText("Login successful (" + role + ")!");
                labelShow.setStyle("-fx-text-fill: green;");

                // Load next screen based on role
                switch (role) {
                    case "STUDENT" -> receiveStudentAndSwitch();
                    case "CR" -> receiveCRAndSwitch();
                    case "AUTHORITY" -> receiveAuthorityAndSwitch();
                    case "TEACHER" -> receiveTeacherAndSwitch();
                    default -> {
                        labelShow.setText("Server Has been Failed to detect your role");
                        Id.clear();
                        password.clear();
                     }
                }
            } else {
                labelShow.setText("Invalid username or password.");
                labelShow.setStyle("-fx-text-fill: red;");
                Id.clear();
                password.clear();
            }
        });
    }
    private void receiveCRAndSwitch(){
        Task<Void> receiveTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                try {
                    //ClientConnection conn = ClientConnection.getInstance();
                    Object obj = conn.receiveObject();
                    if (obj instanceof clientS_stu stu) {
                        Platform.runLater(() -> switchToCRScene(stu));
                    } else {
                        Platform.runLater(() -> {
                            labelShow.setText("Unexpected data received for cr.");
                            labelShow.setStyle("-fx-text-fill: red;");
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> {
                        labelShow.setText("Error receiving cr object.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };
        new Thread(receiveTask).start();
    }
    private void receiveStudentAndSwitch() {
        Task<Void> receiveTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                try {
                   // ClientConnection conn = ClientConnection.getInstance();
                    Object obj = conn.receiveObject();
                    if (obj instanceof clientS_stu stu) {
                        Platform.runLater(() -> switchToStudentScene(stu));
                    } else {
                        Platform.runLater(() -> {
                            labelShow.setText("Unexpected data received for student.");
                            labelShow.setStyle("-fx-text-fill: red;");
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> {
                        labelShow.setText("Error receiving student object.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };
        new Thread(receiveTask).start();
    }

    private void switchToCRScene(clientS_stu stu){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CR-Routine.fxml"));
            Scene scene = new Scene(loader.load());

            CRRoutineController controller = loader.getController();
            StudentConnection sConn=new StudentConnection(conn.getSocket(),conn.getInputStream(),conn.getOutputStream(),stu);
            controller.setConn(sConn);
            controller.setStage(stage);
            controller.initStudent(stu);
            sConn.startReceivingThread();

            stage.setTitle("Class Representative Routine");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load Student UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }
    private void switchToStudentScene(clientS_stu stu) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("StudentRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            StudentRoutineController controller = loader.getController();
            StudentConnection sConn=new StudentConnection(conn.getSocket(),conn.getInputStream(),conn.getOutputStream(),stu);
            controller.setConn(sConn);
            controller.setStage(stage);
            controller.initStudent(stu);
            sConn.startReceivingThread();

            stage.setTitle("Student Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load Student UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }


    private void receiveAuthorityAndSwitch() {
        Task<Void> receiveTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                try {
                  //  ClientConnection conn = ClientConnection.getInstance();
                    Object obj = conn.receiveObject();
                    if (obj instanceof Authority auth) {
                        Platform.runLater(() -> switchToAuthorityScene(auth));
                    } else {
                        Platform.runLater(() -> {
                            labelShow.setText("Unexpected data received for authority.");
                            labelShow.setStyle("-fx-text-fill: red;");
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> {
                        labelShow.setText("Error receiving authority object.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };
        new Thread(receiveTask).start();
    }
    private void switchToAuthorityScene(Authority auth) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Scene scene = new Scene(loader.load());

            AdminController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initAdmin(auth);

            stage.setTitle("Authority Home Page");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load Authority UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }
    private void receiveTeacherAndSwitch() {
        Task<Void> receiveTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                try {
                  //  ClientConnection conn = ClientConnection.getInstance();
                    Object obj = conn.receiveObject();
                    if (obj instanceof clientT_teacher tSchedule) {
                        Platform.runLater(() -> switchToTeacherScene(tSchedule));
                    } else {
                        Platform.runLater(() -> {
                            labelShow.setText("Unexpected data received for teacher.");
                            labelShow.setStyle("-fx-text-fill: red;");
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> {
                        labelShow.setText("Error receiving teacher object.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };
        new Thread(receiveTask).start();
    }
    private void switchToTeacherScene(clientT_teacher teacher) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TeacherRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            TeacherRoutineController controller = loader.getController();
            TeacherConnection tConn=new TeacherConnection(conn.getSocket(),conn.getInputStream(),conn.getOutputStream(),teacher);
            controller.setConn(tConn);
            controller.setStage(stage);
            controller.initTeacher(teacher);
            tConn.startReceivingThread();

            stage.setTitle("Teacher Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load Teacher UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }
}
