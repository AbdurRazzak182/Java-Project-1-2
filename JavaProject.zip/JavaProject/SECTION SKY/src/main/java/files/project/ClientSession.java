package files.project;

public final class ClientSession {
    private static String userId;
    private static String role; // AUTHORITY / TEACHER / CR / STUDENT
    private static Object userObj;
    private ClientSession() {}

    public static void set(String id, String r) {
        userId = id;
        role = r;
    }
    public static  void set(String id,String r,Object obj){
        userId = id;
        role = r;
        userObj=obj;
    }

    public static String getUserId() { return userId; }
    public static String getRole()   { return role; }

    public static boolean isAuthority() { return "AUTHORITY".equals(role); }
    public static boolean isTeacher()   { return "TEACHER".equals(role); }
    public static boolean isCR()        { return "CR".equals(role); }
    public static boolean isStudent()   { return "STUDENT".equals(role); }
    public static Object getUserObj() {
        return userObj;
    }
}