package files.project;

import files.project.Structure.*;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AdminCourseController implements Initializable {

    private ClientConnection conn;
    private Stage stage;
    private Authority author;

    // Context information
    private String departmentName;
    private int level;
    private int term;
    private List<Course> courseList;

    // FXML Components
    @FXML private TextField courseNameField;
    @FXML private TextField courseCodeField;
    @FXML private ComboBox<String> teacherComboBox;
    @FXML private ListView<String> courseListView;
    @FXML private Button cautionButton;
    @FXML private Button exitButton;
    @FXML private Label statusLabel;
    @FXML private Label contextLabel;
    @FXML private Label courseListLabel;

    // Observable lists
    private ObservableList<String> teacherList;
    private ObservableList<String> observableCourseList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeComponents();
    }

    private void initializeComponents() {
        // Initialize Teacher ComboBox
        teacherList = FXCollections.observableArrayList();
        teacherComboBox.setItems(teacherList);

        // Initialize Course ListView
        observableCourseList = FXCollections.observableArrayList();
        courseListView.setItems(observableCourseList);
    }

    public void initialization(Authority author, String departmentName, int level, int term) {
        this.author = author;
        this.departmentName = departmentName;
        this.level = level;
        this.term = term;

        // Update context labels
        updateContextLabels();

        // Load existing courses
        loadExistingCourses();

        // Load available teachers
        loadAvailableTeachers();

        // Refresh course list display
        refreshCourseListView();
    }

    private void updateContextLabels() {
        contextLabel.setText(String.format("Adding courses for %s - Level %d, Term %d",
                departmentName, level, term));
        courseListLabel.setText(String.format("Courses in %s L%dT%d",
                departmentName, level, term));
    }

    private void loadExistingCourses() {
        courseList = new ArrayList<>();

        try {
            if (author != null && author.getVarsity() != null &&
                    author.getVarsity().getFindDeptMap() != null &&
                    author.getVarsity().getFindDeptMap().containsKey(departmentName)) {

                Department dept = author.getVarsity().getFindDeptMap().get(departmentName);
                Level levelObj = dept.getLevel(level);
                if (levelObj != null) {
                    Term termObj = levelObj.getTerm(term);
                    if (termObj != null && termObj.getCourses() != null) {
                        courseList.addAll(termObj.getCourses());
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading existing courses: " + e.getMessage());
        }
    }

    private void loadAvailableTeachers() {
        teacherList.clear();

        try {
            if (author != null && author.getTeacherList() != null) {
                // Load teachers from the same department
                for (Teacher teacher : author.getVarsity().getFindDeptMap().get(departmentName).getTeachers()) {
                        String displayText = String.format("%s (ID: %s)",
                                teacher.getName(), teacher.getID());
                        teacherList.add(displayText);

                }
            }

            // If no teachers found in department, show all teachers
            if (teacherList.isEmpty() && author != null && author.getTeacherList() != null) {
                for (Teacher teacher : author.getTeacherList()) {
                    String displayText = String.format("%s (ID: %s) - %s",
                            teacher.getName(), teacher.getID(), teacher.getDepartment());
                    teacherList.add(displayText);
                }
            }

            // If still no teachers, add a placeholder
            if (teacherList.isEmpty()) {
                teacherList.add("No teachers available");
            }
        } catch (Exception e) {
            System.out.println("Error loading teachers: " + e.getMessage());
            teacherList.add("Error loading teachers");
        }
    }

    private void refreshCourseListView() {
        observableCourseList.clear();

        if (courseList != null) {
            for (Course course : courseList) {
                String teacherInfo = "No Teacher";
                if (course.getInstructor() != null) {
                    teacherInfo = course.getInstructor().getName();
                }

                String displayText = String.format("📚 %s (%s) - Teacher: %s",
                        course.getCourseName(),
                        course.getCourseCode(),
                        teacherInfo);
                observableCourseList.add(displayText);
            }
        }

        if (observableCourseList.isEmpty()) {
            observableCourseList.add("No courses added yet");
        }
    }

    @FXML
    private void handleAddCourse() {
        try {
            // Validate input fields
            if (!validateCourseInput()) {
                return;
            }

            String courseName = courseNameField.getText().trim();
            String courseCode = courseCodeField.getText().trim();
            String selectedTeacher = teacherComboBox.getValue();

            // Check if course code already exists
            if (courseExists(courseCode)) {
                showCautionMessage("Course with code: " + courseCode + " already exists");
                return;
            }

            // Create new course object
            Course course = new Course(courseName, courseCode,level,term);

            // Assign teacher if selected
            if (selectedTeacher != null && !selectedTeacher.equals("No teachers available")
                    && !selectedTeacher.equals("Error loading teachers")) {

                Teacher assignedTeacher = findTeacherByDisplayText(selectedTeacher);
                if (assignedTeacher != null) {
                    course.setInstructor(assignedTeacher);
                }
            }

            // Add course to the system
            addCourseToSystem(course);

            // Add to local list
            courseList.add(course);

            author.getVarsity().getFindDeptMap().get(departmentName).getLevel(level).getTerm(term).addCourse(course);
            author.getFindCourseMap().put(courseCode,course);
            author.getCourseList().add(course);

            // Refresh the display
            refreshCourseListView();

            // sending to server
            conn.send("ADD-COURSE");
            conn.send(departmentName);
            conn.sendObject(course);

            showSuccess("✅ Course '" + courseName + "' added successfully!");
            clearFormFields();

        } catch (Exception e) {
            showCautionMessage("Error adding course: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void addCourseToSystem(Course course) {
        try {
            if (author != null && author.getVarsity() != null &&
                    author.getVarsity().getFindDeptMap() != null &&
                    author.getVarsity().getFindDeptMap().containsKey(departmentName)) {

                Department dept = author.getVarsity().getFindDeptMap().get(departmentName);
                Level levelObj = dept.getLevel(level);
                if (levelObj != null) {
                    Term termObj = levelObj.getTerm(term);
                    if (termObj != null) {
                        if (termObj.getCourses() == null) {
                            termObj.setCourses(new ArrayList<>());
                        }
                        termObj.getCourses().add(course);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error adding course to system: " + e.getMessage());
        }
    }

    private Teacher findTeacherByDisplayText(String displayText) {
        try {
            if (author != null && author.getTeacherList() != null) {
                for (Teacher teacher : author.getTeacherList()) {
                    String teacherDisplay1 = String.format("%s (ID: %s)",
                            teacher.getName(), teacher.getID());
                    String teacherDisplay2 = String.format("%s (ID: %s) - %s",
                            teacher.getName(), teacher.getID(), teacher.getDepartment());

                    if (displayText.equals(teacherDisplay1) || displayText.equals(teacherDisplay2)) {
                        return teacher;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error finding teacher: " + e.getMessage());
        }
        return null;
    }

    private boolean validateCourseInput() {
        if (courseNameField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter course name!");
            courseNameField.requestFocus();
            return false;
        }

        if (courseCodeField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter course code!");
            courseCodeField.requestFocus();
            return false;
        }

        // Validate course code format (optional)
        String courseCode = courseCodeField.getText().trim();
        if (courseCode.length() < 3) {
            showCautionMessage("Course code must be at least 3 characters long!");
            courseCodeField.requestFocus();
            return false;
        }

        return true;
    }

    private boolean courseExists(String courseCode) {
        if (courseList != null) {
            for (Course course : courseList) {
                if (courseCode.equalsIgnoreCase(course.getCourseCode())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void clearFormFields() {
        courseNameField.clear();
        courseCodeField.clear();
        teacherComboBox.setValue(null);
    }

    private void showSuccess(String message) {
        if (statusLabel != null) {
            statusLabel.setText(message);
            statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
        }
    }

    private void showError(String message) {
        if (statusLabel != null) {
            statusLabel.setText("❌ " + message);
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    @FXML
    private void onBackButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Scene scene = new Scene(loader.load());

            AdminController controller = loader.getController();
            controller.setConn(conn);
            controller.initAdmin(author);
            controller.setStage(stage);

            stage.setTitle("Admin Dashboard");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            showCautionMessage("Error returning to admin dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleExit() {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Exit Confirmation");
            alert.setHeaderText("Are you sure you want to exit?");
            alert.setContentText("This will close the application.");

            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    if (conn != null) {
                        conn.close();
                    }
                    System.exit(0);
                }
            });
        } catch (Exception e) {
            showCautionMessage("Error during exit: " + e.getMessage());
        }
    }

    // Method to show caution message
    public void showCautionMessage(String message) {
        cautionButton.setText("⚠️ " + message);
        cautionButton.setVisible(true);
        cautionButton.setOpacity(1.0);

        // Auto-hide after 4 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(4), e -> hideCautionMessage()));
        timeline.play();
    }

    // Method to hide caution message
    public void hideCautionMessage() {
        cautionButton.setVisible(false);
        cautionButton.setOpacity(0.0);
    }

    @FXML
    private void handleShowCaution() {
        hideCautionMessage();
    }

    // Setters for dependency injection
    public void setConn(ClientConnection conn) {
        this.conn = conn;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }
}