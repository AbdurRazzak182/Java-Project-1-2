package files.project;

import files.project.clientT.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Arrays;
import java.util.ResourceBundle;

public class TeacherExamRoutineController implements Initializable {
    TeacherConnection conn;
    public void setConn(TeacherConnection conn){
        this.conn=conn;
    }

    private Stage stage;

    public void setStage(Stage stage) { this.stage = stage; }
    public Stage getStage() { return stage; }

    // Static teacher object to receive data from LoginController
    private clientT_teacher teacher;
    private int totalClass=0,totalLab=0,totalExam=0;

    @FXML
    private Label teacherIdLabel;
    @FXML
    private Button exitBtn;

    @FXML
    private Label totalExamsLabel;

    @FXML
    private Label upcomingExamsLabel;

    @FXML
    private Label thisWeekExamsLabel;

    @FXML
    private Label universityNameLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label deptLabel;

    @FXML
    private Button viewScheduleBtn;

    @FXML
    private Button examScheduleBtn;

    @FXML
    private ScrollPane examScrollPane;

    @FXML
    private VBox examListContainer;

    public void initTeacher(clientT_teacher teacherData) {
        this.teacher = teacherData;
        countSchedule(); // counting lab,exam,classes
        loadTeacherData();
        createExamList();
        updateStatistics();

        conn.setUiUpdateCallback(() -> Platform.runLater(() -> {
            countSchedule();
            createExamList();
            updateStatistics();
        }));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupUI();
        loadTeacherData();
        createExamList();
        setupButtonActions();
    }


    private void setupUI() {
        universityNameLabel.setText("Bangladesh University Engineering and Technology");
        universityNameLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: white;");

        // Set initial values if no teacher data
        if (teacher == null) {
            nameLabel.setText("Dr. Jane Smith");
            deptLabel.setText("Computer Science & Engineering");
            teacherIdLabel.setText("T-001");
        }
    }


    private void loadTeacherData() {
        if (teacher != null) {
            nameLabel.setText(teacher.getName());
            deptLabel.setText(teacher.getDeptName());
            teacherIdLabel.setText(teacher.getID());
        } else {
            // Default data for testing
            nameLabel.setText("Dr. Jane Smith");
            deptLabel.setText("Computer Science & Engineering");
            teacherIdLabel.setText("T-001");
        }
    }


    private void setupButtonActions() {
        viewScheduleBtn.setOnAction(e -> handleViewSchedule());
        examScheduleBtn.setOnAction(e -> handleExamSchedule());
    }

    // counting total exam,total class
    public void countSchedule(){
        for(clientT_date date: teacher.getDates()){
            for(clientT_schedule sch:date.getSchedules()){
                if(sch.getLocation().contains("Lab") | sch.getLocation().contains("lab")){
                    totalLab++;
                }else{
                    totalClass++;
                }
            }
            for(clientT_examSchedule exc:date.getExamSchedules()){
                totalExam++;
            }
        }
    }


    private void createExamList() {
        examListContainer.getChildren().clear();

        if (teacher != null && teacher.getDates() != null && !teacher.getDates().isEmpty()) {
            for (clientT_date dateEntry : teacher.getDates()) {
                HBox dateRow = createDateRow(dateEntry);
                examListContainer.getChildren().add(dateRow);
            }
        } else {
            // Create sample data for testing
            createSampleExamList();
        }
    }


    private HBox createDateRow(clientT_date dateEntry) {
        HBox dateRow = new HBox();
        dateRow.setAlignment(Pos.CENTER_LEFT);
        dateRow.setSpacing(15);
        dateRow.setPadding(new Insets(10, 0, 10, 0));
        dateRow.setStyle("-fx-border-color: #e0e0e0; -fx-border-width: 0 0 1 0;");

        // Left block: Date and weekday (fixed width 150px)
        VBox dateBlock = createDateBlock(dateEntry.getDate());
        dateRow.getChildren().add(dateBlock);

        // Right block: Exam schedules (flexible width)
        HBox examSchedulesBlock = createExamSchedulesBlock(dateEntry.getExamSchedules());
        HBox.setHgrow(examSchedulesBlock, Priority.ALWAYS);
        dateRow.getChildren().add(examSchedulesBlock);

        return dateRow;
    }


    private VBox createDateBlock(String dateString) {
        VBox dateBlock = new VBox();
        dateBlock.setAlignment(Pos.CENTER);
        dateBlock.setPrefWidth(150);
        dateBlock.setMinWidth(150);
        dateBlock.setMaxWidth(150);
        dateBlock.setPrefHeight(80);
        dateBlock.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #ccc; -fx-border-width: 1; -fx-background-radius: 8; -fx-border-radius: 8;");
        dateBlock.setPadding(new Insets(10));

        try {
            LocalDate date = LocalDate.parse(dateString);

            // Weekday label
            Label weekdayLabel = new Label(date.getDayOfWeek().toString().substring(0, 3).toUpperCase());
            weekdayLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-text-fill: #333;");

            // Date label
            Label dateLabel = new Label(date.format(DateTimeFormatter.ofPattern("MMM dd")));
            dateLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #666; -fx-font-weight: bold;");

            // Year label
            Label yearLabel = new Label(String.valueOf(date.getYear()));
            yearLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #999;");

            dateBlock.getChildren().addAll(weekdayLabel, dateLabel, yearLabel);
        } catch (DateTimeParseException e) {
            Label errorLabel = new Label("Invalid");
            errorLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #ff0000;");

            Label dateLabel = new Label("Date");
            dateLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #ff0000;");

            dateBlock.getChildren().addAll(errorLabel, dateLabel);
        }

        return dateBlock;
    }


    private HBox createExamSchedulesBlock(List<clientT_examSchedule> examSchedules) {
        HBox examBlock = new HBox();
        examBlock.setAlignment(Pos.CENTER_LEFT);
        examBlock.setSpacing(15);
        examBlock.setPadding(new Insets(5));

        if (examSchedules != null && !examSchedules.isEmpty()) {
            for (clientT_examSchedule examSchedule : examSchedules) {
                VBox examCard = createExamScheduleCard(examSchedule);
                examBlock.getChildren().add(examCard);
            }
        } else {
            // Show "No exams" message
            VBox noExamsCard = new VBox();
            noExamsCard.setAlignment(Pos.CENTER);
            noExamsCard.setPrefWidth(200);
            noExamsCard.setMinWidth(200);
            noExamsCard.setPrefHeight(80);
            noExamsCard.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-width: 2; -fx-border-style: dashed; -fx-background-radius: 8; -fx-border-radius: 8;");
            noExamsCard.setPadding(new Insets(10));

            Label noExamsLabel = new Label("No Exams");
            noExamsLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #999; -fx-font-style: italic; -fx-font-weight: bold;");

            Label scheduledLabel = new Label("Scheduled");
            scheduledLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #ccc; -fx-font-style: italic;");

            noExamsCard.getChildren().addAll(noExamsLabel, scheduledLabel);
            examBlock.getChildren().add(noExamsCard);
        }

        return examBlock;
    }


    private VBox createExamScheduleCard(clientT_examSchedule examSchedule) {
        VBox examCard = new VBox();
        examCard.setAlignment(Pos.CENTER);
        examCard.setSpacing(4);
        examCard.setPrefWidth(220);
        examCard.setMinWidth(220);
        examCard.setPrefHeight(100);
        examCard.setStyle("-fx-background-color: #9c27b0; -fx-background-radius: 8; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 4, 0, 0, 2);");
        examCard.setPadding(new Insets(12));

        // Course Code (prominent)
        Label courseCodeLabel = new Label(examSchedule.getCourse().getCourseCode());
        courseCodeLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: white;");

        // Time range
        String timeRange = formatTime(examSchedule.getStartTime()) + " - " + formatTime(examSchedule.getEndTime());
        Label timeLabel = new Label("⏰ " + timeRange);
        timeLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #e1bee7; -fx-font-weight: bold;");

        // Location
        Label locationLabel = new Label("📍 " + examSchedule.getLocation());
        locationLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #e1bee7;");

        // Exam Topic/Type
        String examType = examSchedule.getExamTopic() != null ? examSchedule.getExamTopic() : "Exam";
        Label topicLabel = new Label(examType);
        topicLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #ffeb3b; -fx-font-weight: bold; -fx-font-style: italic;");
        topicLabel.setWrapText(true);
        topicLabel.setMaxWidth(190);

        examCard.getChildren().addAll(courseCodeLabel, timeLabel, locationLabel, topicLabel);

        return examCard;
    }


    private String formatTime(String time24) {
        try {
            String[] parts = time24.split(":");
            int hour = Integer.parseInt(parts[0]);
            String minutes = parts[1];

            String amPm;
            int hour12;

            if (hour == 0) {
                hour12 = 12;
                amPm = "AM";
            } else if (hour < 12) {
                hour12 = hour;
                amPm = "AM";
            } else if (hour == 12) {
                hour12 = 12;
                amPm = "PM";
            } else {
                hour12 = hour - 12;
                amPm = "PM";
            }

            return hour12 + ":" + minutes + " " + amPm;
        } catch (Exception e) {
            return time24; // fallback if input format is invalid
        }
    }


    private void updateStatistics() {
        if (teacher != null && teacher.getDates() != null) {
            int totalExams = 0;
            int upcomingExams = 0;
            int thisWeekExams = 0;

            LocalDate today = LocalDate.now();
            LocalDate weekEnd = today.plusDays(7);

            for (clientT_date dateEntry : teacher.getDates()) {
                if (dateEntry.getExamSchedules() != null) {
                    int examsOnDate = dateEntry.getExamSchedules().size();
                    totalExams += examsOnDate;

                    try {
                        LocalDate examDate = LocalDate.parse(dateEntry.getDate());
                        if (examDate.isAfter(today)) {
                            upcomingExams += examsOnDate;
                        }
                        if (examDate.isAfter(today) && examDate.isBefore(weekEnd)) {
                            thisWeekExams += examsOnDate;
                        }
                    } catch (DateTimeParseException e) {
                        // Skip invalid dates
                    }
                }
            }

            totalExamsLabel.setText(String.valueOf(totalExams));
            upcomingExamsLabel.setText(String.valueOf(upcomingExams));
            thisWeekExamsLabel.setText(String.valueOf(thisWeekExams));
        } else {
            // Set default values for sample data
            totalExamsLabel.setText("5");
            upcomingExamsLabel.setText("2");
            thisWeekExamsLabel.setText("1");
        }
    }


    private void createSampleExamList() {
        // Sample date 1 with multiple exams
        String sampleDate1 = "2025-07-30";
        clientT_course course1 = new clientT_course("CSE101", "Programming Fundamentals");
        clientT_course course2 = new clientT_course("CSE102", "Data Structures");

        clientT_examSchedule exam1 = new clientT_examSchedule(course1, "09:00", "11:00", "Room-301", "Midterm Exam");
        clientT_examSchedule exam2 = new clientT_examSchedule(course2, "14:00", "16:00", "Lab-1", "Lab Test");

        List<clientT_examSchedule> examSchedules1 = Arrays.asList(exam1, exam2);
        clientT_date date1 = new clientT_date(sampleDate1, null, examSchedules1);

        // Sample date 2 with no exams
        String sampleDate2 = "2025-07-31";
        clientT_date date2 = new clientT_date(sampleDate2, null, Arrays.asList());

        // Sample date 3 with one exam
        String sampleDate3 = "2025-08-01";
        clientT_course course3 = new clientT_course("MAT101", "Calculus I");
        clientT_examSchedule exam3 = new clientT_examSchedule(course3, "10:00", "12:00", "Room-205", "Final Exam");

        List<clientT_examSchedule> examSchedules3 = Arrays.asList(exam3);
        clientT_date date3 = new clientT_date(sampleDate3, null, examSchedules3);

        // Sample date 4 with multiple exams
        String sampleDate4 = "2025-08-03";
        clientT_course course4 = new clientT_course("PHY101", "Physics I");
        clientT_course course5 = new clientT_course("ENG101", "English");

        clientT_examSchedule exam4 = new clientT_examSchedule(course4, "08:30", "10:30", "Room-201", "Quiz");
        clientT_examSchedule exam5 = new clientT_examSchedule(course5, "11:00", "12:30", "Room-105", "Viva");

        List<clientT_examSchedule> examSchedules4 = Arrays.asList(exam4, exam5);
        clientT_date date4 = new clientT_date(sampleDate4, null, examSchedules4);

        // Create rows for sample data
        HBox row1 = createDateRow(date1);
        HBox row2 = createDateRow(date2);
        HBox row3 = createDateRow(date3);
        HBox row4 = createDateRow(date4);

        examListContainer.getChildren().addAll(row1, row2, row3, row4);

        // Update statistics for sample data
        updateStatistics();
    }


    private void handleViewSchedule() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TeacherRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            TeacherRoutineController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initTeacher(teacher);

            stage.setTitle("Teacher Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Fallback alert if FXML file doesn't exist
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Full Schedule");
            alert.setHeaderText("Full Schedule");
            alert.setContentText("This feature will show the complete weekly schedule.");
            alert.showAndWait();
        }
    }


    private void handleExamSchedule() {
        // Refresh the current exam schedule view
        refreshExamList();
    }


    public void refreshExamList() {
        createExamList();
        updateStatistics();
    }


    public void setTeacher(clientT_teacher teacher) {
        this.teacher = teacher;
        loadTeacherData();
        refreshExamList();
    }


    public clientT_teacher getTeacher() {
        return this.teacher;
    }

    @FXML
    private void handleExit() {
        // Creating a confirmation dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Application");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("This will close the Teacher Routine Management System.");

        // Customizing the buttons
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

        // Showing the dialog and wait for user response
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.YES) {
            conn.running=false;
            conn.close();
            // Close the application
            Platform.exit();
            System.exit(0);
        }
    }
}