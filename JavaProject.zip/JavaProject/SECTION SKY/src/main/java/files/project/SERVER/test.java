package files.project.SERVER;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

public class test {
    public static void main(String[] args) {
        List<String> updatedLines = new ArrayList<>();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate today = LocalDate.now();
        List<String> lines = new ArrayList<>();

        try {
            File file = new File("DataBase/hello.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {
              lines.add(line);
            }

            reader.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (String line : lines) {
            if (line.isBlank()) {
                updatedLines.add("");
                continue;
            }

            String[] parts = line.split(",", 2); // Split into date and rest
            String dateStr = parts[0];
            LocalDate oldDate = LocalDate.parse(dateStr, dateFormatter);

            if (oldDate.isBefore(today)) {
                DayOfWeek targetDay = oldDate.getDayOfWeek();
                LocalDate newDate = today;

                // Find the next same weekday
                while (newDate.getDayOfWeek() != targetDay) {
                    newDate = newDate.plusDays(1);
                }

                dateStr = newDate.format(dateFormatter); // updated date string
            }

            // Reconstruct the line
            if (parts.length == 1) {
                updatedLines.add(dateStr); // No routine entries
            } else {
                updatedLines.add(dateStr + "," + parts[1]);
            }
        }

        // Overwrite the file with updated content
        //Files.write(Paths.get(fileName), updatedLines);
        System.out.println("Routine updated successfully.");

        try {
            // Write to file inside output/
            File file = new File("DataBase/hello.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file)); // append=true
            for(var line:updatedLines){
                System.out.println(line);
                writer.write(line);
                writer.newLine();
            }
            writer.close();
           // System.out.println("File written to: " + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
