package files.project;

import files.project.clientT.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;

public class TeacherConnection extends ClientConnection{
    Thread t;
    private Runnable uiUpdateCallback;
    public volatile boolean running=true;
    clientT_teacher userObj;
    public TeacherConnection(){
    }
    public TeacherConnection(Socket socket, ObjectInputStream in, ObjectOutputStream out, clientT_teacher stu){
        super(socket,in,out);
        this.userObj=stu;
    }

    public void setUiUpdateCallback(Runnable uiUpdateCallback) {
        this.uiUpdateCallback = uiUpdateCallback;
    }


    public void startReceivingThread() {
        Thread t = new Thread(() -> receiving());
        t.setDaemon(true);
        t.start();
    }

    private void receiving() {
        while (running) {
            try {
                String cmd = receiveString();
                if (cmd == null) continue;

                if (cmd.equals("UPDATE-SCHEDULE")) {
                    System.out.println("Received message: "+userObj.getID());
                    Object obj = receiveObject();
                    if (obj instanceof clientT_date serverDate) {
                       // clientT_date date= userObj.getDate(serverDate.getDate());
                        clientT_date date=userObj.getDate(serverDate.getDate());
                        if (date != null) {
                            date.setSchedules(serverDate.getSchedules());
                            if (uiUpdateCallback != null) uiUpdateCallback.run();
                        }
                    }
                }else if(cmd.equals("UPDATE-EXAM-SCHEDULE")){
                    System.out.println("Received message: "+userObj.getID());
                    Object obj = receiveObject();
                    if (obj instanceof clientT_date serverDate) {
                        clientT_date date = userObj.getDate(serverDate.getDate());
                        if (date != null) {
                            date.setExamSchedules(serverDate.getExamSchedules());
                            if (uiUpdateCallback != null) uiUpdateCallback.run();
                        }
                    }
                } else if (cmd.equals("EXIT")) {
                    return;
                }
            } catch (IOException | ClassNotFoundException e) {
                if (e instanceof SocketException && e.getMessage().equals("Socket closed")) {
                    System.out.println("Socket closed — receiving thread exiting cleanly.");
                } else {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
}
