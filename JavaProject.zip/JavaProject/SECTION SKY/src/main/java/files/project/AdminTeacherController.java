package files.project;

import files.project.Structure.*;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AdminTeacherController implements Initializable {

    private ClientConnection conn;
    private Stage stage;
    private Authority author;
    private List<Teacher> teacherList;

    // FXML Components
    @FXML private ComboBox<String> departmentComboBox;
    @FXML private TextField nameField;
    @FXML private TextField idField;
    @FXML private TextField passwordField;
    @FXML private ListView<String> teacherListView;
    @FXML private Button cautionButton;
    @FXML private Button exitButton;
    @FXML private Label statusLabel;

    // Observable lists
    private ObservableList<String> departmentList;
    private ObservableList<String> observableTeacherList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeComboBoxes();
        initializeTeacherList();
        setupEventHandlers();
    }

    private void initializeComboBoxes() {
        // Initialize Department ComboBox
        departmentList = FXCollections.observableArrayList();
        departmentComboBox.setItems(departmentList);

        // Initialize Teacher ListView
        observableTeacherList = FXCollections.observableArrayList();
        teacherListView.setItems(observableTeacherList);
    }

    private void initializeTeacherList() {
        if (teacherList == null) {
            teacherList = new ArrayList<>();
        }
    }

    private void setupEventHandlers() {
        // No additional event handlers needed for simplified form
    }

    public void initialization(Authority author) {
        this.author = author;
        this.teacherList = author.getTeacherList();
        loadDepartments();
        refreshTeacherListView();
    }

    private void loadDepartments() {
        departmentList.clear();

        if (author != null && author.getVarsity() != null) {
            try {
                // Get department names from the university structure
                for (Department dept : author.getVarsity().getDepartments()) {
                    departmentList.add(dept.getName());
                }

                // If no departments found, add some default ones
                if (departmentList.isEmpty()) {
                    addDefaultDepartments();
                }
            } catch (Exception e) {
                addDefaultDepartments();
            }
        } else {
            addDefaultDepartments();
        }
    }

    private void addDefaultDepartments() {
        departmentList.addAll(
                "Computer Science",
                "Electrical Engineering",
                "Mechanical Engineering",
                "Civil Engineering",
                "Business Administration",
                "Mathematics",
                "Physics",
                "Chemistry"
        );
    }



    private void refreshTeacherListView() {
        observableTeacherList.clear();
        if (teacherList != null) {
            for (Teacher teacher : teacherList) {
                String displayText = String.format("👨‍🏫 %s (ID: %s :: password:%s) - %s",
                        teacher.getName(),
                        teacher.getID(),
                        teacher.getPassword(),
                        teacher.getDepartment());
                observableTeacherList.add(displayText);
            }
        }
    }

    @FXML
    private void handleAddTeacher() {
        try {
            // Validate input fields
            if (!validateTeacherInput()) {
                return;
            }

            String name = nameField.getText().trim();
            String id = idField.getText().trim();
            String password = passwordField.getText().trim();
            String department = departmentComboBox.getValue();

            // Check if teacher ID already exists
            if (author.getFindTeacherMap().containsKey(id)) {
                showCautionMessage("Teacher with ID: " + id + " already exists");
                return;
            }

            // Create new teacher object
            Teacher teacher = new Teacher(name, id,password, department);

            // If you have a password field in Teacher class, set it here
            // teacher.setPassword(password);

            // Add to teacher list
            teacherList.add(teacher);

            // Add to authority's teacher list if it exists
            if (author != null && author.getTeacherList() != null) {
                author.getTeacherList().add(teacher);
                author.getVarsity().getFindDeptMap().get(department).addTeacher(teacher);
                author.getFindTeacherMap().put(id,teacher);
            }

            // Refresh the display
            refreshTeacherListView();

            // sending to server
            conn.send("ADD-TEACHER");
            conn.sendObject(teacher);

            showSuccess("✅ Teacher '" + name + "' added successfully!");
            clearFormFields();
        } catch (Exception e) {
            showCautionMessage("Error adding teacher: " + e.getMessage());
        }
    }

    private boolean validateTeacherInput() {
        if (departmentComboBox.getValue() == null) {
            showCautionMessage("Please select a department!");
            departmentComboBox.requestFocus();
            return false;
        }

        if (nameField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter teacher name!");
            nameField.requestFocus();
            return false;
        }

        if (idField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter teacher ID!");
            idField.requestFocus();
            return false;
        }

        if (passwordField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter password!");
            passwordField.requestFocus();
            return false;
        }

        // Additional validation for ID format
        String id = idField.getText().trim();
        if (id.length() < 4) {
            showCautionMessage("Teacher ID must be at least 4 characters long!");
            idField.requestFocus();
            return false;
        }

        return true;
    }


    private void clearFormFields() {
        nameField.clear();
        idField.clear();
        passwordField.clear();
        departmentComboBox.setValue(null);
    }

    private void showSuccess(String message) {
        if (statusLabel != null) {
            statusLabel.setText(message);
            statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
        }
    }

    private void showError(String message) {
        if (statusLabel != null) {
            statusLabel.setText("❌ " + message);
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    @FXML
    private void onBackButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Scene scene = new Scene(loader.load());

            AdminController controller = loader.getController();
            controller.setConn(conn);
            controller.initAdmin(author);
            controller.setStage(stage);

            stage.setTitle("Admin Dashboard");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            showCautionMessage("Error returning to admin dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleExit() {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Exit Confirmation");
            alert.setHeaderText("Are you sure you want to exit?");
            alert.setContentText("This will close the application.");

            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    if (conn != null) {
                        conn.close();
                    }
                    System.exit(0);
                }
            });
        } catch (Exception e) {
            showCautionMessage("Error during exit: " + e.getMessage());
        }
    }

    // Method to show caution message
    public void showCautionMessage(String message) {
        cautionButton.setText("⚠️ " + message);
        cautionButton.setVisible(true);
        cautionButton.setOpacity(1.0);

        // Auto-hide after 4 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(4), e -> hideCautionMessage()));
        timeline.play();
    }

    // Method to hide caution message
    public void hideCautionMessage() {
        cautionButton.setVisible(false);
        cautionButton.setOpacity(0.0);
    }

    @FXML
    private void handleShowCaution() {
        hideCautionMessage();
    }

    // Setters for dependency injection
    public void setConn(ClientConnection conn) {
        this.conn = conn;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }
}