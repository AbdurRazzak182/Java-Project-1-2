package files.project;

import files.project.Structure.*;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AdminStudentController implements Initializable {

    private ClientConnection conn;
    public void setConn(ClientConnection conn){
        this.conn=conn;
    }

    private Stage stage;

    public void setStage(Stage stage) { this.stage = stage; }
    public Stage getStage() { return stage; }

    Authority author;
    List<Student> studentList;
    private int level, term;
    private String deptName;

    @FXML
    private Button cautionButton;
    @FXML
    private Button exitButton;

    @FXML private TextField nameField;
    @FXML private TextField idField;
    @FXML private TextField passwordField;

    // Hidden fields for backward compatibility (not visible in UI)
    @FXML private TextField deptField;
    @FXML private TextField levelField;
    @FXML private TextField termField;

    @FXML private Label statusLabel;
    @FXML private Button addStudentBtn;
    @FXML private Button backBtn;
    @FXML private ListView<String> studentListView;

    private ObservableList<String> observableStudentList;

    // Default values for removed fields
    private static final String DEFAULT_DEPARTMENT = "Computer Science";
    private static final int DEFAULT_LEVEL = 1;
    private static final int DEFAULT_TERM = 1;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        observableStudentList = FXCollections.observableArrayList();
        studentListView.setItems(observableStudentList);

        // Set default values for hidden fields
        if (deptField != null) deptField.setText(DEFAULT_DEPARTMENT);
        if (levelField != null) levelField.setText(String.valueOf(DEFAULT_LEVEL));
        if (termField != null) termField.setText(String.valueOf(DEFAULT_TERM));
    }

    public void initialization(Authority author, List<Student> studentList, String deptName, int level, int term){
        this.author = author;
        this.studentList = studentList;
        this.level = level;
        this.term = term;
        this.deptName = deptName;

        // Set values for hidden fields
        if (deptField != null) deptField.setText(deptName);
        if (levelField != null) levelField.setText(String.valueOf(level));
        if (termField != null) termField.setText(String.valueOf(term));

        refreshStudentListView();
    }

    private void refreshStudentListView() {
        observableStudentList.clear();
        if (studentList != null) {
            for (Student student : studentList) {
                // Enhanced display format: Name - ID
                String displayText = String.format("👤 %s  #ID: %s",
                        student.getName(),
                        student.getID());
                observableStudentList.add(displayText);
            }
        }
    }

    //addition of student to term and a course
    @FXML
    private void handleAddStudent() {
        try {
            // Validate input fields
            if (!validateStudentInput()) {
                return;
            }

            String name = nameField.getText().trim();
            String id = idField.getText().trim();
            String password = passwordField.getText().trim();

            // Use default values for department, level, and term
            String department = DEFAULT_DEPARTMENT;
            int level = DEFAULT_LEVEL;
            int term = DEFAULT_TERM;

            // Check if student ID already exists
            if (author.getFindStuMap().containsKey(id)) {
                showCautionMessage("Student with ID: " + id + " already exists");
                return;
            }

            //creating new student object
            Student student = new Student(name, id, password, deptName, level, term);

            // Check if department exists in the system
            if (author.getVarsity() != null &&
                    author.getVarsity().getFindDeptMap() != null &&
                    author.getVarsity().getFindDeptMap().containsKey(deptName)) {

                List<Course> courses = author.getVarsity()
                        .getFindDeptMap().get(deptName)
                        .getLevel(level)
                        .getTerm(term)
                        .getCourses();

                for(Course course : courses){
                    course.addStudent(student);
                }
                student.setEnrolledCourses(courses);
            }

            author.getStudentList().add(student);
            studentList.add(student); // Also add to local list
            author.getFindStuMap().put(id, student); // Add to map for quick lookup

            refreshStudentListView();

            // sending to server
            conn.send("ADD-STUDENT");
            conn.sendObject(student);

            showSuccess("✅ Student '" + name + "' added successfully!");
            clearFormFields();

        } catch (Exception e) {
            showCautionMessage("Error adding student: " + e.getMessage());
        }
    }

    //validating a student
    private boolean validateStudentInput() {
        if (nameField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter student name!");
            nameField.requestFocus();
            return false;
        }

        if (idField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter student ID!");
            idField.requestFocus();
            return false;
        }

        if (passwordField.getText().trim().isEmpty()) {
            showCautionMessage("Please enter password!");
            passwordField.requestFocus();
            return false;
        }

        // Additional validation for ID format (optional)
        String id = idField.getText().trim();
        if (id.length() < 4) {
            showCautionMessage("Student ID must be at least 4 characters long!");
            idField.requestFocus();
            return false;
        }

        return true;
    }

    //checking existence of a student by id
    private boolean studentExists(String sid){
        for(Student obj : studentList){
            if(sid.equals(obj.getID())){
                return true;
            }
        }
        return false;
    }

    //clearing form
    private void clearFormFields() {
        nameField.clear();
        idField.clear();
        passwordField.clear();
        // Reset hidden fields to current values (not defaults)
        if (deptField != null) deptField.setText(deptName);
        if (levelField != null) levelField.setText(String.valueOf(level));
        if (termField != null) termField.setText(String.valueOf(term));
    }

    private void showSuccess(String message) {
        if (statusLabel != null) {
            statusLabel.setText(message);
            statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
        }
    }

    private void showError(String message) {
        if (statusLabel != null) {
            statusLabel.setText("❌ " + message);
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    private void clearStatusLabel() {
        if (statusLabel != null) {
            statusLabel.setText("");
        }
    }

    @FXML
    private void onBackButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("StudentSelection.fxml"));
            Scene scene = new Scene(loader.load());

            StudentSelectionController controller = loader.getController();
            controller.setConn(conn);
            controller.initialization(author);
            controller.setStage(stage);

            stage.setTitle("Student Selection Dashboard");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            showCautionMessage("Error returning to selection dashboard: " + e.getMessage());
            e.printStackTrace(); // Add this for debugging
        }
    }

    @FXML
    private void handleExit() {
        try {
            // Show confirmation dialog
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Exit Confirmation");
            alert.setHeaderText("Are you sure you want to exit?");
            alert.setContentText("This will close the application.");

            alert.showAndWait().ifPresent(response -> {
                if (response == javafx.scene.control.ButtonType.OK) {
                    conn.close();
                    // Close the application
                    System.exit(0);
                }
            });
        } catch (Exception e) {
            showCautionMessage("Error during exit: " + e.getMessage());
        }
    }

    // Method to show caution message
    public void showCautionMessage(String message) {
        cautionButton.setText("⚠️ " + message);
        cautionButton.setVisible(true);
        cautionButton.setOpacity(1.0);

        // Optional: Auto-hide after 4 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(4), e -> hideCautionMessage()));
        timeline.play();
    }

    // Method to hide caution message
    public void hideCautionMessage() {
        cautionButton.setVisible(false);
        cautionButton.setOpacity(0.0);
    }

    @FXML
    private void handleShowCaution() {
        // Handle caution button click (hide the message when clicked)
        hideCautionMessage();
    }
}