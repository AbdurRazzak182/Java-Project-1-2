package files.project.Structure;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Authority implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Course> courses = new ArrayList<>();
    private Map<String, Course> findCourse = new HashMap<>();

    private List<Student> students = new ArrayList<>();
    private Map<String, Student> findStu = new HashMap<>();

    private List<Teacher> teachers = new ArrayList<>();
    private Map<String, Teacher> findTeacher = new HashMap<>();

    private List<CR> crs = new ArrayList<>();
    private Map<String, CR> findCr = new HashMap<>();

    Course course;
    Term term;

    private Varsity handleVarsity;
    private String varifyID;
    private String password;

    public Authority() {
        handleVarsity = null;
    }

    public Authority(Varsity varsity) {
        if (varsity != null) {
            this.handleVarsity = varsity;
        }
    }

    public boolean verify(String id, String pass) {
        return this.varifyID.equals(id) && this.password.equals(pass);
    }

    public String getId() {
        return varifyID;
    }

    public void setID(String id) {
        this.varifyID = id;
    }

    public Varsity getVarsity() {
            return handleVarsity;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Student> getStudentList() {
        return students;
    }

    public void setStudentList(List<Student> studentList) {
        this.students = studentList;
    }

    public List<CR> getCrList() {
        return crs;
    }

    public void setCrList(List<CR> crList) {
        this.crs = crList;
    }

    public List<Teacher> getTeacherList() {
        return teachers;
    }

    public void setTeacherList(List<Teacher> teacherList) {
        this.teachers = teacherList;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Term getTerm() {
        return term;
    }

    public void setTerm(Term term) {
        this.term = term;
    }

    public Map<String, Course> getFindCourseMap() {
        return findCourse;
    }

    public void setFindCourseMap(Map<String, Course> courseMap) {
        findCourse = courseMap;
    }

    public Map<String, Student> getFindStuMap() {
        return findStu;
    }

    public void setFindStuMap(Map<String, Student> stuMap) {
        findStu = stuMap;
    }

    public Map<String, Teacher> getFindTeacherMap() {
        return findTeacher;
    }

    public void setFindTeacherMap(Map<String, Teacher> teacherMap) {
        findTeacher = teacherMap;
    }

    public Map<String, CR> getFindCrMap() {
        return findCr;
    }

    public void setFindCrMap(Map<String, CR> crMap) {
        findCr = crMap;
    }

    public void setCourseList(List<Course> courses){
        this.courses=courses;
    }

    public List<Course> getCourseList(){
        return courses;
    }
}
