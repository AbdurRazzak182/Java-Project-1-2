package files.project;

import files.project.ClientS.*;
import java.io.*;
import java.net.*;

public class testClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 5050)) {
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

            clientS_stu student = (clientS_stu) ois.readObject();

            System.out.println("Received Student:");
            System.out.println("Department: " + student.getDepartmentName());
            System.out.println("Courses:");
            for (var c : student.getEnrolledCourses()) {
                System.out.println("  - " + c.getCourseCode() + ": " + c.getCourseName() + " by " + c.getInstructor());
            }

            for (var d : student.getDates()) {
                System.out.println("Date: " + d.getDate());
                for (clientS_schedule s : d.getSchedules()) {
                    System.out.println("  Class at " + s.getLocation() + " [" + s.getStartTime() + "-" + s.getEndTime() + "]");
                }
                for (clientS_examSchedule e : d.getExamSchedules()) {
                    System.out.println("  Exam at " + e.getLocation() + " [" + e.getStartTime() + "-" + e.getEndTime() + "] on: " + e.getExamTopic());
                }
            }

            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}