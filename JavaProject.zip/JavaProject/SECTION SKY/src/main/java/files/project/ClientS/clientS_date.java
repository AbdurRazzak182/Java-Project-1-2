package files.project.ClientS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class clientS_date implements Serializable {
    private static final long serialVersionUID = 1L;

    private String date;
    private List<clientS_schedule> schedules;
    private List<clientS_examSchedule> examSchedules;

    // Default constructor
    public clientS_date() {
        this.date = "";
        this.schedules = new ArrayList<>();
        this.examSchedules = new ArrayList<>();
    }
    public clientS_date(String dateStr) {
        this.date =dateStr;
        this.schedules = new ArrayList<>();
        this.examSchedules = new ArrayList<>();
    }
    // Parameterized constructor
    public clientS_date(String date, List<clientS_schedule> schedules, List<clientS_examSchedule> examSchedules) {
        this.date = date;
        this.schedules = schedules;
        this.examSchedules = examSchedules;
    }

    // Getters and Setters
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<clientS_schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(List<clientS_schedule> schedules) {
        this.schedules = schedules;
    }

    public List<clientS_examSchedule> getExamSchedules() {
        return examSchedules;
    }

    public void setExamSchedules(List<clientS_examSchedule> examSchedules) {
        this.examSchedules = examSchedules;
    }

    // Add a single schedule
    public void addSchedule(clientS_schedule schedule) {
        if (schedule != null) {
            schedules.add(schedule);
        }
    }

    // Add a single exam schedule
    public void addExamSchedule(clientS_examSchedule examSchedule) {
        if (examSchedule != null) {
            examSchedules.add(examSchedule);
        }
    }
}
