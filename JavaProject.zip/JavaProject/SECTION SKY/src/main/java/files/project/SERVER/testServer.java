//package files.project.SERVER;
//
//
//import java.io.*;
//import java.net.*;
//import files.project.ClientS.*;
//
//
//public class testServer {
//    public static void main(String[] args) {
////        try (ServerSocket serverSocket = new ServerSocket(5050)) {
////            System.out.println("Server started. Waiting for client...");
////            Socket socket = serverSocket.accept();
////            System.out.println("Client connected.");
////
////            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
////
////            // Dummy object creation
////            clientS_stu student = createDummyStudent();
////            oos.writeObject(student);  // Send object
////            oos.flush();
////
////            System.out.println("Student object sent.");
////
////            oos.close();
////            socket.close();
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
//    }
//
//    private static clientS_stu createDummyStudent() {
////        clientS_stu stu = new clientS_stu("hi","CSE", 1, 1);
////
////        clientS_course course = new clientS_course("CSE101", "Intro to Programming", "Dr. Hasan");
////        stu.addCourse(course);
////
////        clientS_schedule schedule = new clientS_schedule(course, "08:00", "09:30", "Room 101");
////        clientS_examSchedule exam = new clientS_examSchedule(course, "10:00", "12:00", "Exam Hall A", "Midterm");
////
////        clientS_date date = new clientS_date();
////        date.setDate("2025-07-25");
////        date.addSchedule(schedule);
////        date.addExamSchedule(exam);
////
////        stu.addDate(date);
////
////        return stu;
//    }
//}
