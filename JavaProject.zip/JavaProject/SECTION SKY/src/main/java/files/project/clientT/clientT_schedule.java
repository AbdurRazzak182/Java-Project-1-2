package files.project.clientT;

import java.io.Serializable;

public class clientT_schedule implements Serializable {
    private static final long serialVersionUID = 1L;

    private String location;
    private clientT_course course;
    private String startTime;
    private String endTime;
    private boolean isOpen;

    // Default constructor
    public clientT_schedule() {
        this.location = "";
        this.course = null;
        this.startTime = "";
        this.endTime = "";
        this.isOpen = true;
    }
    public clientT_schedule(clientT_course course, String startTime, String endTime,String location) {
        this.location = location;
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isOpen = true;
    }
    // Parameterized constructor
    public clientT_schedule(clientT_course course, String startTime, String endTime,String location,  boolean isOpen) {
        this.location = location;
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isOpen = isOpen;
    }

    // Getters and Setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public clientT_course getCourse() {
        return course;
    }

    public void setCourse(clientT_course course) {
        this.course = course;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public boolean status() {
        return isOpen;
    }

    public void setOpen(boolean isOpen) {
        this.isOpen = isOpen;
    }
}
