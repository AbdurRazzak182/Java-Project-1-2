package files.project.Structure;

import java.io.Serializable;

public class Person implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private String id;
    private String password;
    // Constructors, getters, setters

    public Person() {
    }

    public Person(String name, String id,String password){
        this.name = name;
        this.id = id;
        this.password=password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getID() {
        return id;
    }

    public void setid(String id) {
        this.id = id;
    }

    public String getPassword(){
        return this.password;
    }
    public void setPassword(String password){
        this.password=password;
    }
}
