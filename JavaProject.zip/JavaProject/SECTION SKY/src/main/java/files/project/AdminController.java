package files.project;

import files.project.Structure.Authority;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class AdminController implements Initializable {
    private ClientConnection conn;
    private Stage stage;
    private Authority author;

    @FXML private Button manageStudentBtn;
    @FXML private Button manageCourseBtn;
    @FXML private Button manageTeacherBtn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // This method is called automatically after FXML loading
        // Any additional UI setup can be done here
    }

    public void setConn(ClientConnection conn) {
        this.conn = conn;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }

    public void initAdmin(Authority admin) {
        this.author = admin;
    }

    @FXML
    private void onManageStudentButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("StudentSelection.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            StudentSelectionController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initialization(author);

            stage.setScene(scene);
            stage.setTitle("Select Students");
            stage.centerOnScreen();
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading Student Selection page: " + e.getMessage());
        }
    }

    @FXML
    private void onManageCourseButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CourseSelection.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            CourseSelectionController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initialization(author);

            stage.setScene(scene);
            stage.setTitle("Manage Courses");
            stage.centerOnScreen();
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading Course Selection page: " + e.getMessage());
        }
    }

    @FXML
    private void onManageTeacherButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminTeacher.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            AdminTeacherController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initialization(author);

            stage.setScene(scene);
            stage.setTitle("Manage Teachers");
            stage.centerOnScreen();
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading Admin Teacher page: " + e.getMessage());
        }
    }
}