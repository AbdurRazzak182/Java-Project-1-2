package files.project;

import files.project.Structure.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CourseSelectionController implements Initializable {

    private ClientConnection conn;
    private Stage stage;
    private Authority author;

    // FXML Components
    @FXML
    private ComboBox<String> departmentComboBox;
    @FXML
    private ComboBox<String> levelComboBox;
    @FXML
    private ComboBox<String> termComboBox;
    @FXML
    private Button proceedButton;
    @FXML
    private Button exitButton;
    @FXML
    private Label statusLabel;

    // Observable lists for ComboBoxes
    private ObservableList<String> departmentList;
    private ObservableList<String> levelList;
    private ObservableList<String> termList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeComboBoxes();
        setupEventHandlers();
    }

    private void initializeComboBoxes() {
        // Initialize Department ComboBox with sample data
        departmentList = FXCollections.observableArrayList();
        departmentComboBox.setItems(departmentList);

        // Initialize Level ComboBox
        levelList = FXCollections.observableArrayList("1", "2", "3", "4");
        levelComboBox.setItems(levelList);

        // Initialize Term ComboBox
        termList = FXCollections.observableArrayList("1", "2");
        termComboBox.setItems(termList);

        // Initially disable proceed button
        proceedButton.setDisable(true);
    }

    private void setupEventHandlers() {
        // Add listeners to enable/disable proceed button based on selections
        departmentComboBox.setOnAction(e -> checkSelections());
        levelComboBox.setOnAction(e -> checkSelections());
        termComboBox.setOnAction(e -> checkSelections());
    }

    public void initialization(Authority author) {
        this.author = author;
        loadDepartments();
    }

    private void loadDepartments() {
        departmentList.clear();

        // Load departments from authority/university structure
        if (author != null && author.getVarsity() != null) {
            try {
                // Get department names from the university structure
                for (Department dept : author.getVarsity().getDepartments()) {
                    departmentList.add(dept.getName());
                }

                // If no departments found, add some default ones
                if (departmentList.isEmpty()) {
                    departmentList.addAll("Computer Science ", "Electrical Engineering",
                            "Mechanical Engineering", "Civil Engineering",
                            "Business Administration", "Mathematics",
                            "Physics", "Chemistry");
                }
            } catch (Exception e) {
                // Fallback to default departments
                departmentList.addAll("Computer Science", "Electrical Engineering",
                        "Mechanical Engineering", "Civil Engineering",
                        "Business Administration", "Mathematics",
                        "Physics", "Chemistry");
            }
        } else {
            // Default departments if no authority provided
            departmentList.addAll("Computer Science", "Electrical Engineering",
                    "Mechanical Engineering", "Civil Engineering",
                    "Business Administration", "Mathematics",
                    "Physics", "Chemistry");
        }
    }

    private void checkSelections() {
        boolean allSelected = departmentComboBox.getValue() != null &&
                levelComboBox.getValue() != null &&
                termComboBox.getValue() != null;

        proceedButton.setDisable(!allSelected);

        if (allSelected) {
            clearStatusMessage();
        }
    }

    @FXML
    private void handleProceed() {
        try {
            // Validate all selections are made
            if (!validateSelections()) {
                return;
            }

            String selectedDepartment = departmentComboBox.getValue();
            String selectedLevel = levelComboBox.getValue();
            String selectedTerm = termComboBox.getValue();

            // Load the AdminStudent FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CourseManagement.fxml"));
            Scene scene = new Scene(loader.load());

            String departmentName=selectedDepartment;
            int level=Integer.parseInt(selectedLevel);
            int term=Integer.parseInt(selectedTerm);
          //  System.out.println(selectedDepartment+" "+level+" "+term);
            AdminCourseController controller = loader.getController();
            controller.setStage(stage);
            controller.setConn(conn);
//            if(author.getVarsity().getFindDeptMap().get(departmentName)==null){
//                System.out.println("null dept");
//            }
//            if(author.getVarsity()==null) System.out.println("varsity null");
//            if(author==null) System.out.println("author is null");
//            if(author.getVarsity().getFindDeptMap().get(departmentName).getLevel(level)==null) System.out.println("level nulll");
//            if(author.getVarsity().getFindDeptMap().get(departmentName).getLevel(level).getTerm(term)==null)
//                System.out.println("term null");
//            if(author.getVarsity().getFindDeptMap().get(departmentName).getLevel(level).getTerm(term).getStudents()==null)
//                System.out.println("list null");
            controller.initialization(author,selectedDepartment,level,term);

            // stage.setTitle("Student Management - " + selectedDepartment + " L" + selectedLevel + "T" + selectedTerm);
            stage.setTitle("add Course");
            stage.setScene(scene);
            stage.show();
            System.out.println("Adding");
        } catch (Exception e) {
            showError("Error proceeding to student management: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Scene scene = new Scene(loader.load());

            AdminController controller = loader.getController();
            controller.setConn(conn);
            controller.initAdmin(author);
            controller.setStage(stage);

            stage.setTitle("Admin Dashboard");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            showError("Error returning to admin dashboard: " + e.getMessage());
        }
    }

    @FXML
    private void handleExit() {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Exit Confirmation");
            alert.setHeaderText("Are you sure you want to exit?");
            alert.setContentText("This will close the application.");

            alert.showAndWait().ifPresent(response -> {
                if (response == javafx.scene.control.ButtonType.OK) {
                    System.exit(0);
                }
            });
        } catch (Exception e) {
            showError("Error during exit: " + e.getMessage());
        }
    }

    private boolean validateSelections() {
        if (departmentComboBox.getValue() == null) {
            showError("Please select a department!");
            departmentComboBox.requestFocus();
            return false;
        }

        if (levelComboBox.getValue() == null) {
            showError("Please select an academic level!");
            levelComboBox.requestFocus();
            return false;
        }

        if (termComboBox.getValue() == null) {
            showError("Please select an academic term!");
            termComboBox.requestFocus();
            return false;
        }

        return true;
    }

    private void showError(String message) {
        statusLabel.setText("❌ " + message);
        statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
    }

    private void showSuccess(String message) {
        statusLabel.setText("✅ " + message);
        statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
    }

    private void clearStatusMessage() {
        statusLabel.setText("");
    }

    // Setters for dependency injection
    public void setConn(ClientConnection conn) {
        this.conn = conn;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }
}