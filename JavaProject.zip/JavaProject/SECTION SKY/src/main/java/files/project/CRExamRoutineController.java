package files.project;

import files.project.ClientS.*;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.application.Platform;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class CRExamRoutineController implements Initializable {
    private StudentConnection conn;
    public void setConn(StudentConnection conn){
        this.conn=conn;
    }

    private Stage stage;
    private clientS_stu student;

    // FXML Elements
    @FXML
    private Label universityNameLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label idLabel;

    @FXML
    private Label deptLabel;

    @FXML
    private Label levelLabel;

    @FXML
    private Label termLabel;

    @FXML
    private Label totalExamsLabel;

    @FXML
    private Label upcomingExamsLabel;

    @FXML
    private Label thisWeekExamsLabel;

    @FXML
    private ScrollPane examScrollPane;

    @FXML
    private VBox examListContainer;

    @FXML
    private Button viewScheduleBtn;

    @FXML
    private Button examScheduleBtn;

    @FXML
    private Button exitBtn;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }

    public void initStudent(clientS_stu studentData) {
        this.student = studentData;
        updateStudentInfo();
        createExamList();
        updateStatistics();

        conn.setUiUpdateCallback(() -> Platform.runLater(() -> {
            createExamList();
            updateStatistics();
        }));

//        Task<Void> receiveTask = new Task<>() {
//            @Override
//            protected Void call() throws Exception {
//                try {
//                    conn.receiving(() -> Platform.runLater(() -> {
//                        createExamList();
//                        updateStatistics();
//                    }));
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                return null;
//            }
//        };
//        new Thread(receiveTask).start();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupUI();
        createExamList();
        setupButtonActions();
    }

    /**
     * Setup basic UI components
     */
    private void setupUI() {
        universityNameLabel.setText("Bangladesh University Engineering and Technology");
        universityNameLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: white;");

        // Set initial values if no student data
        if (student == null) {
            nameLabel.setText("John Doe");
            idLabel.setText("CSE-2021-001");
            deptLabel.setText("Computer Science & Engineering");
            levelLabel.setText("3rd Year");
            termLabel.setText("1st Term");
        }
    }

    /**
     * Update student information labels
     */
    private void updateStudentInfo() {
        if (student != null) {
            nameLabel.setText(student.getName() != null ? student.getName() : "N/A");
            idLabel.setText(student.getId() != null ? student.getId() : "N/A");
            deptLabel.setText(student.getDepartmentName() != null ? student.getDepartmentName() : "N/A");

            // Get level and term from enrolled courses (assuming first course for simplicity)
            levelLabel.setText(student.getLevel()+"");
            termLabel.setText(student.getTerm()+"");
        }
    }

    /**
     * Setup button actions
     */
    private void setupButtonActions() {
        viewScheduleBtn.setOnAction(e -> handleViewSchedule());
        examScheduleBtn.setOnAction(e -> handleExamSchedule());
    }

    /**
     * Handle View Schedule button
     */
    private void handleViewSchedule() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CR-Routine.fxml"));
            Scene scene = new Scene(loader.load());

            CRRoutineController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initStudent(student);

            stage.setTitle("Student Exam Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle Exam Schedule button
     */
    private void handleExamSchedule() {
        // Refresh the current exam schedule view
        refreshExamList();
    }

    /**
     * Create and populate the exam schedule list
     */
    private void createExamList() {
        examListContainer.getChildren().clear();

        if (student != null && student.getDates() != null && !student.getDates().isEmpty()) {
            for (clientS_date dateEntry : student.getDates()) {
                HBox dateRow = createDateRow(dateEntry);
                examListContainer.getChildren().add(dateRow);
            }
        } else {
            // Create sample data for testing
            createSampleExamList();
        }
    }

    /**
     * Create a row for a specific date with its exam schedules
     */
    private HBox createDateRow(clientS_date dateEntry) {
        HBox dateRow = new HBox();
        dateRow.setAlignment(Pos.CENTER_LEFT);
        dateRow.setSpacing(15);
        dateRow.setPadding(new Insets(10, 0, 10, 0));
        dateRow.setStyle("-fx-border-color: #e0e0e0; -fx-border-width: 0 0 1 0;");

        // Left block: Date and weekday (fixed width 150px)
        VBox dateBlock = createDateBlock(dateEntry.getDate());
        dateRow.getChildren().add(dateBlock);

        // Right block: Exam schedules (flexible width)
        HBox examSchedulesBlock = createExamSchedulesBlock(dateEntry.getExamSchedules());
        HBox.setHgrow(examSchedulesBlock, Priority.ALWAYS);
        dateRow.getChildren().add(examSchedulesBlock);

        return dateRow;
    }

    /**
     * Create the left date block showing date and weekday
     */
    private VBox createDateBlock(String dateString) {
        VBox dateBlock = new VBox();
        dateBlock.setAlignment(Pos.CENTER);
        dateBlock.setPrefWidth(150);
        dateBlock.setMinWidth(150);
        dateBlock.setMaxWidth(150);
        dateBlock.setPrefHeight(80);
        dateBlock.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #ccc; -fx-border-width: 1; -fx-background-radius: 8; -fx-border-radius: 8;");
        dateBlock.setPadding(new Insets(10));

        try {
            LocalDate date = LocalDate.parse(dateString);

            // Weekday label
            Label weekdayLabel = new Label(date.getDayOfWeek().toString().substring(0, 3).toUpperCase());
            weekdayLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-text-fill: #333;");

            // Date label
            Label dateLabel = new Label(date.format(DateTimeFormatter.ofPattern("MMM dd")));
            dateLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #666; -fx-font-weight: bold;");

            // Year label
            Label yearLabel = new Label(String.valueOf(date.getYear()));
            yearLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #999;");

            dateBlock.getChildren().addAll(weekdayLabel, dateLabel, yearLabel);
        } catch (DateTimeParseException e) {
            Label errorLabel = new Label("Invalid");
            errorLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #ff0000;");

            Label dateLabel = new Label("Date");
            dateLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #ff0000;");

            dateBlock.getChildren().addAll(errorLabel, dateLabel);
        }

        return dateBlock;
    }

    /**
     * Create the right block containing exam schedules
     */
    private HBox createExamSchedulesBlock(List<clientS_examSchedule> examSchedules) {
        HBox examBlock = new HBox();
        examBlock.setAlignment(Pos.CENTER_LEFT);
        examBlock.setSpacing(15);
        examBlock.setPadding(new Insets(5));

        if (examSchedules != null && !examSchedules.isEmpty()) {
            for (clientS_examSchedule examSchedule : examSchedules) {
                VBox examCard = createExamScheduleCard(examSchedule);
                examBlock.getChildren().add(examCard);
            }
        } else {
            // Show "No exams" message
            VBox noExamsCard = new VBox();
            noExamsCard.setAlignment(Pos.CENTER);
            noExamsCard.setPrefWidth(200);
            noExamsCard.setMinWidth(200);
            noExamsCard.setPrefHeight(80);
            noExamsCard.setStyle("-fx-background-color: #fffff; -fx-border-color: #e0e0e0; -fx-border-width: 2; -fx-border-style: dashed; -fx-background-radius: 8; -fx-border-radius: 8;");
            noExamsCard.setPadding(new Insets(10));

            Label noExamsLabel = new Label("No Exams");
            noExamsLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #999; -fx-font-style: italic; -fx-font-weight: bold;");

            Label scheduledLabel = new Label("Scheduled");
            scheduledLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #ccc; -fx-font-style: italic;");

            noExamsCard.getChildren().addAll(noExamsLabel, scheduledLabel);
            examBlock.getChildren().add(noExamsCard);
        }

        return examBlock;
    }

    /**
     * Create a card for a single exam schedule
     */
    private VBox createExamScheduleCard(clientS_examSchedule examSchedule) {
        VBox examCard = new VBox();
        examCard.setAlignment(Pos.CENTER);
        examCard.setSpacing(4);
        examCard.setPrefWidth(220);
        examCard.setMinWidth(220);
        examCard.setPrefHeight(100);
        examCard.setStyle("-fx-background-color: #D43DFE; -fx-background-radius: 8; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 4, 0, 0, 2);");
        examCard.setPadding(new Insets(12));

        // Course Code (prominent)
        Label courseCodeLabel = new Label(examSchedule.getCourse().getCourseCode());
        courseCodeLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: white;");

        // Time range
        String timeRange = formatTime(examSchedule.getStartTime()) + " - " + formatTime(examSchedule.getEndTime());
        Label timeLabel = new Label("⏰ " + timeRange);
        timeLabel.setStyle("-fx-font-size: 9px; -fx-text-fill: #e1bee7; -fx-font-weight: bold;");

        // Location
        Label locationLabel = new Label("📍 " + examSchedule.getLocation());
        locationLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #e1bee7;");

        // Exam Topic
        Label topicLabel = new Label(examSchedule.getExamTopic());
        topicLabel.setStyle("-fx-font-size: 15px; -fx-text-fill: #D5FE01; -fx-font-weight: bold; -fx-font-style: italic;");
        topicLabel.setWrapText(true);
        topicLabel.setMaxWidth(190);

        examCard.getChildren().addAll(courseCodeLabel, timeLabel, locationLabel, topicLabel);

        return examCard;
    }

    /**
     * Format time string (assumes HH:mm format input)
     */
    private String formatTime(String time24) {
        try {
            String[] parts = time24.split(":");
            int hour = Integer.parseInt(parts[0]);
            String minutes = parts[1];

            String amPm;
            int hour12;

            if (hour == 0) {
                hour12 = 12;
                amPm = "AM";
            } else if (hour < 12) {
                hour12 = hour;
                amPm = "AM";
            } else if (hour == 12) {
                hour12 = 12;
                amPm = "PM";
            } else {
                hour12 = hour - 12;
                amPm = "PM";
            }

            return hour12 + ":" + minutes + " " + amPm;
        } catch (Exception e) {
            return time24; // fallback if input format is invalid
        }
    }

    /**
     * Update statistics labels
     */
    private void updateStatistics() {
        if (student != null && student.getDates() != null) {
            int totalExams = 0;
            int upcomingExams = 0;
            int thisWeekExams = 0;

            LocalDate today = LocalDate.now();
            LocalDate weekEnd = today.plusDays(7);

            for (clientS_date dateEntry : student.getDates()) {
                if (dateEntry.getExamSchedules() != null) {
                    int examsOnDate = dateEntry.getExamSchedules().size();
                    totalExams += examsOnDate;

                    try {
                        LocalDate examDate = LocalDate.parse(dateEntry.getDate());
                        if (examDate.isAfter(today)) {
                            upcomingExams += examsOnDate;
                        }
                        if (examDate.isAfter(today) && examDate.isBefore(weekEnd)) {
                            thisWeekExams += examsOnDate;
                        }
                    } catch (DateTimeParseException e) {
                        // Skip invalid dates
                    }
                }
            }

            totalExamsLabel.setText(String.valueOf(totalExams));
            upcomingExamsLabel.setText(String.valueOf(upcomingExams));
            thisWeekExamsLabel.setText(String.valueOf(thisWeekExams));
        } else {
            // Set default values for sample data
            totalExamsLabel.setText("8");
            upcomingExamsLabel.setText("3");
            thisWeekExamsLabel.setText("2");
        }
    }
    @FXML
    private void handleUpdate() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CRExamRoutineUpdate.fxml"));
            Scene scene = new Scene(loader.load());

            CRExamRoutineUpdateController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initStudent(student);


            stage.setTitle("Update Exam Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Show error alert if FXML file cannot be loaded
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Cannot load Update page");
            alert.setContentText("The CRExamRoutineUpdate.fxml file could not be loaded. Please check if the file exists.");
            alert.showAndWait();
        }
    }
    /**
     * Create sample exam list for testing
     */
    private void createSampleExamList() {
        // Sample date 1 with multiple exams
        String sampleDate1 = "2025-07-28";
        clientS_course course1 = new clientS_course("CSE101", "Programming Fundamentals", "Dr. Smith");
        clientS_course course2 = new clientS_course("MAT101", "Calculus I", "Dr. Johnson");

        clientS_examSchedule exam1 = new clientS_examSchedule(course1, "09:00", "11:00", "Room-301", "Midterm Exam");
        clientS_examSchedule exam2 = new clientS_examSchedule(course2, "14:00", "16:00", "Room-302", "Quiz 1");

        List<clientS_examSchedule> examSchedules1 = Arrays.asList(exam1, exam2);
        clientS_date date1 = new clientS_date(sampleDate1, null, examSchedules1);

        // Sample date 2 with no exams
        String sampleDate2 = "2025-07-29";
        clientS_date date2 = new clientS_date(sampleDate2, null, Arrays.asList());

        // Sample date 3 with one exam
        String sampleDate3 = "2025-07-30";
        clientS_course course3 = new clientS_course("CSE102", "Data Structures", "Dr. Wilson");
        clientS_examSchedule exam3 = new clientS_examSchedule(course3, "10:00", "12:00", "UCL-Lab", "Lab Test");

        List<clientS_examSchedule> examSchedules3 = Arrays.asList(exam3);
        clientS_date date3 = new clientS_date(sampleDate3, null, examSchedules3);

        // Sample date 4 with multiple exams
        String sampleDate4 = "2025-08-01";
        clientS_course course4 = new clientS_course("PHY101", "Physics I", "Dr. Brown");
        clientS_course course5 = new clientS_course("ENG101", "English", "Dr. Davis");

        clientS_examSchedule exam4 = new clientS_examSchedule(course4, "08:30", "10:30", "Room-201", "Final Exam");
        clientS_examSchedule exam5 = new clientS_examSchedule(course5, "11:00", "12:30", "Room-105", "Term Paper Defense");

        List<clientS_examSchedule> examSchedules4 = Arrays.asList(exam4, exam5);
        clientS_date date4 = new clientS_date(sampleDate4, null, examSchedules4);

        // Sample date 5 with single exam
        String sampleDate5 = "2025-08-03";
        clientS_course course6 = new clientS_course("CSE201", "Algorithm", "Dr. Taylor");
        clientS_examSchedule exam6 = new clientS_examSchedule(course6, "15:00", "17:00", "Room-401", "Midterm Exam");

        List<clientS_examSchedule> examSchedules5 = Arrays.asList(exam6);
        clientS_date date5 = new clientS_date(sampleDate5, null, examSchedules5);

        // Create rows for sample data
        HBox row1 = createDateRow(date1);
        HBox row2 = createDateRow(date2);
        HBox row3 = createDateRow(date3);
        HBox row4 = createDateRow(date4);
        HBox row5 = createDateRow(date5);

        examListContainer.getChildren().addAll(row1, row2, row3, row4, row5);

        // Update statistics for sample data
        updateStatistics();
    }

    /**
     * Handle exit button action
     */
    @FXML
    private void handleExit() {
        // Create a confirmation dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Application");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("This will close the Student Exam Schedule System.");

        // Customize the buttons
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

        // Show the dialog and wait for user response
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.YES) {
            try {
               // ClientConnection conn = ClientConnection.getInstance();
                conn.running=false;
                conn.close();
            } catch (Exception e) {
                // Handle connection close error if needed
                System.err.println("Error closing connection: " + e.getMessage());
            }
            // Close the application
            Platform.exit();
            System.exit(0);
        }
    }

    /**
     * Refresh the exam list (can be called when data is updated)
     */
    public void refreshExamList() {
        createExamList();
        updateStatistics();
    }

    /**
     * Set student data and refresh the display
     */
    public void setStudent(clientS_stu student) {
        this.student = student;
        updateStudentInfo();
        refreshExamList();
    }

    /**
     * Get current student data
     */
    public clientS_stu getStudent() {
        return this.student;
    }
}