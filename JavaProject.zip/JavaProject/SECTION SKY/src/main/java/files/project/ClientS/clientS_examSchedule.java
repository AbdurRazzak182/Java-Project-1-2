package files.project.ClientS;

import java.io.Serializable;

public class clientS_examSchedule implements Serializable {
    private static final long serialVersionUID = 1L;

    private String location;
    private clientS_course course;
    private String startTime;
    private String endTime;
    private String examTopic;


    public clientS_examSchedule() {
        this.location = "";
        this.course = null;
        this.startTime = "";
        this.endTime = "";
        this.examTopic = "";
    }


    public clientS_examSchedule(clientS_course course, String startTime, String endTime,String location, String examTopic) {
        this.location = location;
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.examTopic = examTopic;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public clientS_course getCourse() {
        return course;
    }

    public void setCourse(clientS_course course) {
        this.course = course;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getExamTopic() {
        return examTopic;
    }

    public void setExamTopic(String examTopic) {
        this.examTopic = examTopic;
    }
}
