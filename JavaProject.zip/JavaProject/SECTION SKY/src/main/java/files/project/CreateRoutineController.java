package files.project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class CreateRoutineController {

    @FXML private TextField departmentField;
    @FXML private TextField levelField;
    @FXML private TextField termField;
    @FXML private TextField academicYearField;
    @FXML private TextField startTimeField;
    @FXML private TextField endTimeField;
    @FXML private TextField classDurationField;
    @FXML private TextField breakDurationField;
    @FXML private VBox routineGrid;
    @FXML private Label statusLabel;
    @FXML private Button generateSlotsBtn;
    @FXML private Button saveRoutineBtn;
    @FXML private Button previewRoutineBtn;
    @FXML private Button clearRoutineBtn;
    @FXML private Button backBtn;

    private List<String> timeSlots = new ArrayList<>();
    private Map<String, Map<String, String>> routineData = new HashMap<>();
    private final String[] DAYS = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"};
    private final String[] DAY_COLORS = {"#e74c3c", "#e67e22", "#f39c12", "#27ae60", "#3498db"};

    private List<String> availableCourses = new ArrayList<>();
    private List<String> availableTeachers = new ArrayList<>();

    @FXML
    private void initialize() {
        loadCoursesAndTeachers();
        setupDefaultValues();
        initializeRoutineData();
    }

    private void setupDefaultValues() {
        startTimeField.setText("08:00 AM");
        endTimeField.setText("05:00 PM");
        classDurationField.setText("90");
        breakDurationField.setText("15");
    }

    private void loadCoursesAndTeachers() {
        // Load courses from teachers.txt file
        try {
            File teachersFile = new File("teachers.txt");
            if (teachersFile.exists()) {
                List<String> lines = Files.readAllLines(Paths.get("teachers.txt"));
                for (String line : lines) {
                    String[] parts = line.split(",");
                    if (parts.length >= 2) {
                        String teacherId = parts[0].trim();
                        String courseName = parts[1].trim();

                        if (!availableTeachers.contains(teacherId)) {
                            availableTeachers.add(teacherId);
                        }
                        if (!availableCourses.contains(courseName)) {
                            availableCourses.add(courseName);
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading courses and teachers: " + e.getMessage());
        }

        // Add some default courses if file doesn't exist
        if (availableCourses.isEmpty()) {
            availableCourses.addAll(Arrays.asList(
                    "Programming Fundamentals", "Data Structures", "Database Systems",
                    "Operating Systems", "Computer Networks", "Software Engineering",
                    "Web Development", "Mobile Computing", "Artificial Intelligence",
                    "Machine Learning", "Computer Graphics", "Discrete Mathematics"
            ));
        }

        if (availableTeachers.isEmpty()) {
            availableTeachers.addAll(Arrays.asList(
                    "T001", "T002", "T003", "T004", "T005", "T006"
            ));
        }
    }

    private void initializeRoutineData() {
        for (String day : DAYS) {
            routineData.put(day, new HashMap<>());
        }
    }

    @FXML
    private void handleGenerateTimeSlots() {
        try {
            String startTimeStr = startTimeField.getText().trim();
            String endTimeStr = endTimeField.getText().trim();
            int classDuration = Integer.parseInt(classDurationField.getText().trim());
            int breakDuration = Integer.parseInt(breakDurationField.getText().trim());

            generateTimeSlots(startTimeStr, endTimeStr, classDuration, breakDuration);
            createRoutineGrid();

            statusLabel.setText("✅ Time slots generated successfully!");
            statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");

        } catch (Exception e) {
            statusLabel.setText("❌ Error generating time slots: " + e.getMessage());
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    private void generateTimeSlots(String startTime, String endTime, int classDuration, int breakDuration) {
        timeSlots.clear();

        LocalTime start = parseTime(startTime);
        LocalTime end = parseTime(endTime);

        LocalTime current = start;

        while (current.plusMinutes(classDuration).isBefore(end) ||
                current.plusMinutes(classDuration).equals(end)) {

            LocalTime slotEnd = current.plusMinutes(classDuration);
            String timeSlot = formatTime(current) + " - " + formatTime(slotEnd);
            timeSlots.add(timeSlot);

            current = slotEnd.plusMinutes(breakDuration);
        }
    }

    private LocalTime parseTime(String timeStr) {
        timeStr = timeStr.toUpperCase().trim();
        DateTimeFormatter formatter;

        if (timeStr.contains("AM") || timeStr.contains("PM")) {
            formatter = DateTimeFormatter.ofPattern("hh:mm a");
        } else {
            formatter = DateTimeFormatter.ofPattern("HH:mm");
        }

        return LocalTime.parse(timeStr, formatter);
    }

    private String formatTime(LocalTime time) {
        return time.format(DateTimeFormatter.ofPattern("hh:mm a"));
    }

    private void createRoutineGrid() {
        routineGrid.getChildren().clear();

        for (String timeSlot : timeSlots) {
            HBox row = createTimeSlotRow(timeSlot);
            routineGrid.getChildren().add(row);
        }
    }

    private HBox createTimeSlotRow(String timeSlot) {
        HBox row = new HBox();
        row.setSpacing(2);

        // Time slot label
        Label timeLabel = new Label(timeSlot);
        timeLabel.setPrefWidth(120);
        timeLabel.setStyle("-fx-background-color: #34495e; -fx-text-fill: white; -fx-font-weight: bold; " +
                "-fx-padding: 10; -fx-alignment: center; -fx-font-size: 12px;");
        row.getChildren().add(timeLabel);

        // Day cells
        for (int i = 0; i < DAYS.length; i++) {
            String day = DAYS[i];
            String color = DAY_COLORS[i];

            VBox dayCell = createDayCell(day, timeSlot, color);
            row.getChildren().add(dayCell);
        }

        return row;
    }

    private VBox createDayCell(String day, String timeSlot, String color) {
        VBox cell = new VBox();
        cell.setPrefWidth(200);
        cell.setMinHeight(80);
        cell.setSpacing(5);
        cell.setStyle("-fx-background-color: rgba(255,255,255,0.9); -fx-border-color: " + color +
                "; -fx-border-width: 2; -fx-padding: 8; -fx-background-radius: 5;");

        // Course ComboBox
        ComboBox<String> courseCombo = new ComboBox<>();
        courseCombo.setItems(FXCollections.observableArrayList(availableCourses));
        courseCombo.setPromptText("Select Course");
        courseCombo.setPrefWidth(180);
        courseCombo.setStyle("-fx-font-size: 11px; -fx-background-radius: 3;");

        // Teacher ComboBox
        ComboBox<String> teacherCombo = new ComboBox<>();
        teacherCombo.setItems(FXCollections.observableArrayList(availableTeachers));
        teacherCombo.setPromptText("Select Teacher");
        teacherCombo.setPrefWidth(180);
        teacherCombo.setStyle("-fx-font-size: 11px; -fx-background-radius: 3;");

        // Room TextField
        TextField roomField = new TextField();
        roomField.setPromptText("Room");
        roomField.setPrefWidth(180);
        roomField.setStyle("-fx-font-size: 11px; -fx-background-radius: 3;");

        // Event handlers to save data
        courseCombo.setOnAction(e -> saveSlotData(day, timeSlot, "course", courseCombo.getValue()));
        teacherCombo.setOnAction(e -> saveSlotData(day, timeSlot, "teacher", teacherCombo.getValue()));
        roomField.textProperty().addListener((obs, oldVal, newVal) ->
                saveSlotData(day, timeSlot, "room", newVal));

        cell.getChildren().addAll(courseCombo, teacherCombo, roomField);
        return cell;
    }

    private void saveSlotData(String day, String timeSlot, String field, String value) {
        String key = day + "_" + timeSlot;
        Map<String, String> slotData = routineData.get(day);

        if (!slotData.containsKey(timeSlot)) {
            slotData.put(timeSlot, "");
        }

        // Store the field data
        slotData.put(timeSlot + "_" + field, value != null ? value : "");
    }

    @FXML
    private void handleSaveRoutine() {
        try {
            if (validateRoutineData()) {
                saveRoutineToFile();
                statusLabel.setText("✅ Routine saved successfully!");
                statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
            }
        } catch (Exception e) {
            statusLabel.setText("❌ Error saving routine: " + e.getMessage());
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    private boolean validateRoutineData() {
        if (departmentField.getText().trim().isEmpty() ||
                levelField.getText().trim().isEmpty() ||
                termField.getText().trim().isEmpty()) {

            statusLabel.setText("❌ Please fill in all routine information fields!");
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
            return false;
        }

        if (timeSlots.isEmpty()) {
            statusLabel.setText("❌ Please generate time slots first!");
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
            return false;
        }

        return true;
    }

    private void saveRoutineToFile() throws IOException {
        String filename = String.format("routine_%s_L%s_T%s.txt",
                departmentField.getText().trim().replaceAll("\\s+", ""),
                levelField.getText().trim(),
                termField.getText().trim());

        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            // Write header information
            writer.println("# University Routine");
            writer.println("Department: " + departmentField.getText().trim());
            writer.println("Level: " + levelField.getText().trim());
            writer.println("Term: " + termField.getText().trim());
            writer.println("Academic Year: " + academicYearField.getText().trim());
            writer.println("Generated Date: " + java.time.LocalDateTime.now());
            writer.println();

            // Write routine data
            writer.println("Time Slot,Saturday,Sunday,Monday,Tuesday,Wednesday");

            for (String timeSlot : timeSlots) {
                StringBuilder line = new StringBuilder(timeSlot);

                for (String day : DAYS) {
                    String course = getSlotData(day, timeSlot, "course");
                    String teacher = getSlotData(day, timeSlot, "teacher");
                    String room = getSlotData(day, timeSlot, "room");

                    String cellData = "";
                    if (!course.isEmpty() || !teacher.isEmpty() || !room.isEmpty()) {
                        cellData = String.format("%s|%s|%s", course, teacher, room);
                    }

                    line.append(",").append(cellData);
                }

                writer.println(line.toString());
            }
        }
    }

    private String getSlotData(String day, String timeSlot, String field) {
        Map<String, String> dayData = routineData.get(day);
        String key = timeSlot + "_" + field;
        return dayData.getOrDefault(key, "");
    }

    @FXML
    private void handlePreviewRoutine() {
        if (timeSlots.isEmpty()) {
            statusLabel.setText("❌ Please generate time slots first!");
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
            return;
        }

        // Create preview window
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Routine Preview");
        alert.setHeaderText("Preview of " + departmentField.getText() + " - Level " +
                levelField.getText() + ", Term " + termField.getText());

        StringBuilder preview = new StringBuilder();
        preview.append("Time Slots Generated: ").append(timeSlots.size()).append("\n");
        preview.append("Department: ").append(departmentField.getText()).append("\n");
        preview.append("Academic Year: ").append(academicYearField.getText()).append("\n\n");

        // Count filled slots
        int filledSlots = 0;
        int totalSlots = timeSlots.size() * DAYS.length;

        for (String day : DAYS) {
            for (String timeSlot : timeSlots) {
                String course = getSlotData(day, timeSlot, "course");
                if (!course.isEmpty()) {
                    filledSlots++;
                }
            }
        }

        preview.append("Progress: ").append(filledSlots).append("/").append(totalSlots)
                .append(" slots filled (").append(String.format("%.1f", (filledSlots * 100.0 / totalSlots)))
                .append("%)\n\n");

        // Show sample schedule for first day
        preview.append("Sample Schedule (Saturday):\n");
        for (String timeSlot : timeSlots) {
            String course = getSlotData("Saturday", timeSlot, "course");
            String teacher = getSlotData("Saturday", timeSlot, "teacher");
            String room = getSlotData("Saturday", timeSlot, "room");

            preview.append(timeSlot).append(": ");
            if (!course.isEmpty()) {
                preview.append(course);
                if (!teacher.isEmpty()) preview.append(" (").append(teacher).append(")");
                if (!room.isEmpty()) preview.append(" - Room: ").append(room);
            } else {
                preview.append("Free Period");
            }
            preview.append("\n");
        }

        alert.setContentText(preview.toString());
        alert.showAndWait();

        statusLabel.setText("📋 Routine preview displayed!");
        statusLabel.setStyle("-fx-text-fill: #3498db; -fx-font-weight: bold;");
    }

    @FXML
    private void handleClearRoutine() {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Clear Routine");
        confirmation.setHeaderText("Clear All Routine Data");
        confirmation.setContentText("Are you sure you want to clear all routine data? This action cannot be undone.");

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            clearAllData();
            statusLabel.setText("🗑️ All routine data cleared!");
            statusLabel.setStyle("-fx-text-fill: #e67e22; -fx-font-weight: bold;");
        }
    }

    private void clearAllData() {
        // Clear form fields
        departmentField.clear();
        levelField.clear();
        termField.clear();
        academicYearField.clear();

        // Reset time fields to defaults
        setupDefaultValues();

        // Clear routine data
        initializeRoutineData();
        timeSlots.clear();

        // Clear the grid
        routineGrid.getChildren().clear();
    }

    @FXML
    private void handleBackToAdmin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) backBtn.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.centerOnScreen();

        } catch (Exception e) {
            statusLabel.setText("❌ Error returning to admin panel: " + e.getMessage());
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    // Utility method to export routine to different formats
    public void exportRoutineToCSV() {
        try {
            String filename = String.format("routine_%s_L%s_T%s.csv",
                    departmentField.getText().trim().replaceAll("\\s+", ""),
                    levelField.getText().trim(),
                    termField.getText().trim());

            try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
                // Write CSV header
                writer.println("Time Slot,Saturday,Sunday,Monday,Tuesday,Wednesday");

                for (String timeSlot : timeSlots) {
                    StringBuilder line = new StringBuilder("\"" + timeSlot + "\"");

                    for (String day : DAYS) {
                        String course = getSlotData(day, timeSlot, "course");
                        String teacher = getSlotData(day, timeSlot, "teacher");
                        String room = getSlotData(day, timeSlot, "room");

                        String cellData = "";
                        if (!course.isEmpty()) {
                            cellData = course;
                            if (!teacher.isEmpty()) cellData += " (" + teacher + ")";
                            if (!room.isEmpty()) cellData += " - " + room;
                        }

                        line.append(",\"").append(cellData).append("\"");
                    }

                    writer.println(line.toString());
                }
            }

            statusLabel.setText("✅ Routine exported to CSV: " + filename);
            statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");

        } catch (IOException e) {
            statusLabel.setText("❌ Error exporting to CSV: " + e.getMessage());
            statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        }
    }

    // Method to validate time conflicts
    private boolean hasTimeConflicts() {
        Map<String, Set<String>> teacherSchedule = new HashMap<>();
        Map<String, Set<String>> roomSchedule = new HashMap<>();

        for (String day : DAYS) {
            for (String timeSlot : timeSlots) {
                String teacher = getSlotData(day, timeSlot, "teacher");
                String room = getSlotData(day, timeSlot, "room");

                if (!teacher.isEmpty()) {
                    String scheduleKey = day + "_" + timeSlot;
                    teacherSchedule.computeIfAbsent(teacher, k -> new HashSet<>()).add(scheduleKey);
                }

                if (!room.isEmpty()) {
                    String scheduleKey = day + "_" + timeSlot;
                    roomSchedule.computeIfAbsent(room, k -> new HashSet<>()).add(scheduleKey);
                }
            }
        }

        // Check for conflicts
        for (Set<String> schedule : teacherSchedule.values()) {
            if (schedule.size() > timeSlots.size()) return true;
        }

        for (Set<String> schedule : roomSchedule.values()) {
            if (schedule.size() > timeSlots.size()) return true;
        }

        return false;
    }

    // Method to get routine statistics
    public Map<String, Object> getRoutineStatistics() {
        Map<String, Object> stats = new HashMap<>();

        int totalSlots = timeSlots.size() * DAYS.length;
        int filledSlots = 0;
        Set<String> uniqueCourses = new HashSet<>();
        Set<String> uniqueTeachers = new HashSet<>();
        Set<String> uniqueRooms = new HashSet<>();

        for (String day : DAYS) {
            for (String timeSlot : timeSlots) {
                String course = getSlotData(day, timeSlot, "course");
                String teacher = getSlotData(day, timeSlot, "teacher");
                String room = getSlotData(day, timeSlot, "room");

                if (!course.isEmpty()) {
                    filledSlots++;
                    uniqueCourses.add(course);
                }
                if (!teacher.isEmpty()) {
                    uniqueTeachers.add(teacher);
                }
                if (!room.isEmpty()) {
                    uniqueRooms.add(room);
                }
            }
        }

        stats.put("totalSlots", totalSlots);
        stats.put("filledSlots", filledSlots);
        stats.put("fillPercentage", (filledSlots * 100.0 / totalSlots));
        stats.put("uniqueCourses", uniqueCourses.size());
        stats.put("uniqueTeachers", uniqueTeachers.size());
        stats.put("uniqueRooms", uniqueRooms.size());
        stats.put("hasConflicts", hasTimeConflicts());

        return stats;
    }

    // Method to auto-fill routine with available courses
    public void autoFillRoutine() {
        Random random = new Random();

        for (String day : DAYS) {
            for (String timeSlot : timeSlots) {
                // Only fill empty slots
                String existingCourse = getSlotData(day, timeSlot, "course");
                if (existingCourse.isEmpty() && random.nextDouble() < 0.7) { // 70% chance to fill

                    String course = availableCourses.get(random.nextInt(availableCourses.size()));
                    String teacher = availableTeachers.get(random.nextInt(availableTeachers.size()));
                    String room = "R-" + (random.nextInt(50) + 101); // Generate room numbers

                    saveSlotData(day, timeSlot, "course", course);
                    saveSlotData(day, timeSlot, "teacher", teacher);
                    saveSlotData(day, timeSlot, "room", room);
                }
            }
        }

        // Refresh the grid to show the auto-filled data
        createRoutineGrid();

        statusLabel.setText("🤖 Routine auto-filled with available courses!");
        statusLabel.setStyle("-fx-text-fill: #9b59b6; -fx-font-weight: bold;");
    }

    // Method to check routine completeness
    private double getRoutineCompleteness() {
        int totalSlots = timeSlots.size() * DAYS.length;
        int filledSlots = 0;

        for (String day : DAYS) {
            for (String timeSlot : timeSlots) {
                String course = getSlotData(day, timeSlot, "course");
                if (!course.isEmpty()) {
                    filledSlots++;
                }
            }
        }

        return totalSlots > 0 ? (filledSlots * 100.0 / totalSlots) : 0.0;
    }

    // Method to validate routine before saving
    private boolean validateCompleteRoutine() {
        double completeness = getRoutineCompleteness();

        if (completeness < 50.0) {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Incomplete Routine");
            warning.setHeaderText("Routine is only " + String.format("%.1f", completeness) + "% complete");
            warning.setContentText("Consider filling more time slots before saving. Continue anyway?");

            Optional<ButtonType> result = warning.showAndWait();
            return result.isPresent() && result.get() == ButtonType.OK;
        }

        return true;
    }
}