package files.project;

import java.io.*;
import java.net.Socket;

public class ClientConnection {
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public ClientConnection() {}

    public ClientConnection(Socket socket, ObjectInputStream in, ObjectOutputStream out) {
        this.socket = socket;
        this.in = in;
        this.out = out;
    }

    public void connect(String host, int port) throws IOException {
        if (socket != null && socket.isConnected()) return;
        socket = new Socket(host, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(socket.getInputStream());
    }

    // ✅ Send string (synchronized on out)
    public void send(String msg) throws IOException {
        synchronized (out) {
            out.writeObject(msg);
            out.flush();
        }
    }

    // ❗ Read methods: Assume only one thread reads from input, so no sync needed here.
    public Object receiveObject() throws IOException, ClassNotFoundException {
        return in.readObject(); // reading is single-threaded (e.g., in background thread)
    }

    public String receiveString() throws IOException, ClassNotFoundException {
        Object o = receiveObject();
        return (o instanceof String s) ? s : null;
    }

    // ✅ Send any object (synchronized on out)
    public void sendObject(Object obj) {
        if (obj != null) {
            synchronized (out) {
                try {
                    out.writeObject(obj);
                    out.flush();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public void close() {
        String ExitResponse = "EXIT";
        try {
            synchronized (out) {
                out.writeObject(ExitResponse);
                out.flush();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try { if (in != null) in.close(); } catch (IOException ignored) {}
        try { if (out != null) out.close(); } catch (IOException ignored) {}
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
    }

    // ✅ Getters
    public Socket getSocket() {
        return socket;
    }

    public ObjectOutputStream getOutputStream() {
        return out;
    }

    public ObjectInputStream getInputStream() {
        return in;
    }
}
