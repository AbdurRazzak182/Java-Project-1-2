package files.project.Structure;


import java.io.Serializable;

public class Schedule implements Serializable {
    private static final long serialVersionUID = 1L;
    private String location;
    private Course course;
    private String startTime;
    private String endTime;
    private boolean isOpen;

    // Constructor
    public Schedule(Course course, String startTime, String endTime, String location) {
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
        isOpen=true;
    }
    public Schedule(Course course, String startTime, String endTime, String location,boolean isOpen) {
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
        this.isOpen=isOpen;
    }
    // Getters
    public Course getCourse() {
        return course;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getLocation() {
        return location;
    }

    // Setters
    public void setCourse(Course course) {
        this.course = course;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setStatus(boolean isOpen){
        this.isOpen=isOpen;
    }
    public boolean status(){
        return isOpen;
    }
}