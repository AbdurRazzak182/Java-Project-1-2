package files.project.clientT;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class clientT_teacher implements Serializable {
    private String name,id;
    private String deptName;
    private List<clientT_course> assignedCourses;
    private List<clientT_date> dates;

    // Constructor with name and deptName
    public clientT_teacher(String id,String name, String deptName) {
        this.id=id;
        this.name = name;
        this.deptName = deptName;
        assignedCourses=new ArrayList<>();
        dates=new ArrayList<>();
    }

    // Default constructor
    public clientT_teacher() {
    }

    // Getters and Setters
    public String getName() {
        return name;
    }
    public String getID(){
        return id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public List<clientT_course> getAssignedCourses() {
        return assignedCourses;
    }

    public void setAssignedCourses(List<clientT_course> assignedCourses) {
        this.assignedCourses = assignedCourses;
    }

    public List<clientT_date> getDates() {
        return dates;
    }

    public void setDates(List<clientT_date> dates) {
        this.dates = dates;
    }
    public void addCourse(clientT_course course){
        if(course!=null){
            this.assignedCourses.add(course);
        }
    }
    public void addDate(clientT_date date){
        if(date!=null){
            this.dates.add(date);
        }
    }
    public clientT_date getDate(String dateStr){
        for(clientT_date dt:dates){
            if(dt.getDate().equals(dateStr)){
                return dt;
            }
        }
        return null;
    }
}
