package files.project.SERVER;


import files.project.Structure.*;
import files.project.ClientS.*;
import files.project.clientT.*;
import java.io.*;
import java.io.BufferedReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.time.format.DateTimeFormatter;

public class Server {
    private static String varsityName;

    // to store all department list
    private static List<Department> departments=new ArrayList<>();
    //  key="Dept name", value=department object
    private static Map<String,Department> findDept=new HashMap<>();


    private static List<Course> courses=new ArrayList<>();
    //  Course Code -> Course object
    private static Map<String,Course> findCourse=new HashMap<>();


    private static List<Student> students=new ArrayList<>();
    // student id -> student object
    private static Map<String,Student> findStu=new HashMap<>();


    private static List<Teacher> teachers=new ArrayList<>();
    // teacher id -> teacher object
    private static Map<String,Teacher> findTeacher=new HashMap<>();


    private static List<CR> crs=new ArrayList<>();
    // cr id -> teacher object
    private static Map<String,CR> findCr=new HashMap<>();


    private static Varsity varsity;
    private static Authority authority;


    // All data read here
    static{
        varsityName="Bangladesh University of Engineering and Technology";


        File deptFile_Name = new File("DataBase/Data/department.txt");
        // storing department in departments list
        try (BufferedReader br = new BufferedReader(new FileReader(deptFile_Name))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length < 2) continue; // skip invalid lines

                String deptName = parts[0].trim();
                String deptCode = parts[1].trim();

                Department department = new Department(deptName, deptCode);

                // updating deptName
                findDept.put(deptName, department);

                // adding in list
                departments.add(department);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        File courseFile_Name = new File("DataBase/Data/course.txt");
        // course code, course name, dept name, level, term
        try (BufferedReader br = new BufferedReader(new FileReader(courseFile_Name))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length < 5) continue; // skip malformed lines

                String courseCode = parts[0].trim();
                String courseName = parts[1].trim();
                String deptName = parts[2].trim();
                int level = Integer.parseInt(parts[3].trim());
                int term = Integer.parseInt(parts[4].trim());

                Course course = new Course(courseCode, courseName, level, term);

                // Adding course to department/level/term
                if (!findDept.containsKey(deptName)) {
                    Department department = new Department(deptName);
                    departments.add(department);
                    findDept.put(deptName, department);
                }

                findDept.get(deptName).getLevel(level).getTerm(term).addCourse(course);

                // Add to list
                courses.add(course);

                // Add to map
                findCourse.put(courseCode, course);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        File stuFile_Name = new File("DataBase/Data/student.txt");
        // Read student file: name,id,password,dept name,level,term
        try (BufferedReader br = new BufferedReader(new FileReader(stuFile_Name))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length < 6) {
                    System.out.println("Skipping malformed line: " + line);
                    continue;
                }

                String name = parts[0].trim();
                String id = parts[1].trim();
                String password = parts[2].trim();
                String deptName = parts[3].trim();
                int level = Integer.parseInt(parts[4].trim());
                int term = Integer.parseInt(parts[5].trim());

                if (!findDept.containsKey(deptName)) {
                    System.out.println("⚠️ Error: student(name: " + name + ") belongs to unknown department: " + deptName);
                    continue;
                }

                Student student = new Student(name, id, password, deptName, level, term);

                // Add to list and map
                students.add(student);
                findStu.put(id, student);

                // Set enrolled courses
                List<Course> courses = findDept.get(deptName)
                        .getLevel(level)
                        .getTerm(term)
                        .getCourses();
                student.setEnrolledCourses(courses);

                // Add student to term
                findDept.get(deptName)
                        .getLevel(level)
                        .getTerm(term)
                        .addStudent(student);

                // Add student to each course
                for (Course c : courses) {
                    c.addStudent(student);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        File teacherFile_Name=new File("DataBase/Data/teacher.txt");
        // Dr. Hossain Kabir,3003,hossain789,Electrical and Electronic Engineering,[EEE103;EEE203;EEE303]
        try(BufferedReader br = new BufferedReader(new FileReader(teacherFile_Name))){
            String line;
            while((line=br.readLine())!=null){
                String[] parts=line.trim().split(",");

                String name=parts[0];
                String id=parts[1];
                String password=parts[2];
                String deptName=parts[3];
                if(!findDept.containsKey(deptName)){
                    System.out.println("Error: Teacher(name:"+name+") in text file with unknown department");
                    continue;
                }
                // Last part (index 4 here) contains assigned courses string
                String assignedCourses = parts[4];  // "[CE101;CE201;CE301]"

                // Remove brackets and split
                assignedCourses = assignedCourses.trim().substring(1, assignedCourses.length() - 1);
                String[] courseCodes = assignedCourses.trim().split(";");


                Teacher teacher=new Teacher(name,id,password,deptName);
                //System.out.println(teacher.getName());
                for (int i = 0; i < courseCodes.length; i++) {
                    courseCodes[i] = courseCodes[i].trim();
                    //System.out.println(courseCodes[i]);

                    // searching if it is valid course code
                    if(findCourse.containsKey(courseCodes[i])){
                        // add course to the course list of teacher
                        teacher.addCourse(findCourse.get(courseCodes[i]));

                        // assigning course teacher to the course
                        findCourse.get(courseCodes[i]).setInstructor(teacher);
                    }else{
                        System.out.println("Techer: "+teacher.getName()+" assigned to a non-exist course");
                    }
                }

                // add teacher to the department
                findDept.get(deptName).addTeacher(teacher);

                // add in the teacher list
                teachers.add(teacher);

                // add in the map
                findTeacher.put(id,teacher);
            }
        }catch(Exception e){
            e.printStackTrace();
        }


        File crFile_Name=new File("DataBase/Data/cr.txt");
        // name,id,password,dept name,level,term
        try(BufferedReader br = new BufferedReader(new FileReader(crFile_Name))){
            String line;
            while((line=br.readLine())!=null){
                String[] parts=line.trim().split(",");

                String name=parts[0];
                String id=parts[1];
                String password=parts[2];
                String deptName=parts[3];
                int level=Integer.valueOf(parts[4]);
                int term=Integer.valueOf(parts[5]);

                CR cr=new CR(name,id,password,deptName,level,term);
                // add to list
                crs.add(cr);
                // add to map
                findCr.put(id,cr);

                // if belong dept not exist create it
                if(!findDept.containsKey(deptName)){
                    Department department=new Department(deptName);
                    departments.add(department);
                    findDept.put(deptName,department);
                    System.out.println("Added");
                }
                // set enrolled course
                cr.setEnrolledCourses(findDept.get(deptName).getLevel(level).getTerm(term).getCourses());

                // add the student to the term and term
                findDept.get(deptName).getLevel(level).getTerm(term).addCR(cr);

                // add the student to the course
                for(Course takenCourse:findDept.get(deptName).getLevel(level).getTerm(term).getCourses()){
                    takenCourse.addStudent((Student)cr);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }



        varsity=new Varsity(varsityName,departments);
        varsity.setFindDeptMap(findDept);

        authority=new Authority(varsity);
        authority.setStudentList(students);
        authority.setFindStuMap(findStu);

        authority.setCrList(crs);
        authority.setFindCrMap(findCr);

        authority.setCourseList(courses);
        authority.setFindCourseMap(findCourse);

        authority.setTeacherList(teachers);
        authority.setFindTeacherMap(findTeacher);

        File authorFile = new File("DataBase/Data/authority.txt");
        try (BufferedReader br = new BufferedReader(new FileReader(authorFile))) {
            String line = br.readLine();
            String[] parts = line.trim().split("\\|");
            if (parts.length != 2) {
                System.out.println("Authority file invalid");
                throw new RuntimeException("File read invalid");
            } else {
                authority.setID(parts[0]);
                authority.setPassword(parts[1]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        // Read all schedules for date [include all department] and  set them to its term's date list
        for(var dept:departments){
            String deptCode=dept.getDeptCode();
            for(int level=1;level<=4;level++){
                for(int term=1;term<=2;term++){
                    //System.out.println(fileName);
                    List<String> updatedLines = new ArrayList<>();
                    List<String> lines = new ArrayList<>();

                    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate today = LocalDate.now();

                    try {
                        File file = new File("DataBase/ClassRoutine/"+deptCode+"/Level"+level+"_Term"+term+".txt");
                        BufferedReader reader = new BufferedReader(new FileReader(file));
                        String line;

                        while ((line = reader.readLine()) != null) {
                            lines.add(line);
                        }

                        reader.close();
                    } catch (FileNotFoundException e) {
                        System.err.println("File not found");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // updating weekday to its corresponding date
                    for (String line : lines) {
                        if (line.isBlank()) {
                            updatedLines.add("");
                            continue;
                        }

                        String[] parts = line.split(",", 2); // Split into date and rest
                        String dateStr = parts[0];
                        LocalDate oldDate = LocalDate.parse(dateStr, dateFormatter);

                        if (oldDate.isBefore(today)) {
                            // it was just a temporary schedule, so remove it when it passed
                            if(line.contains("temp")){
                                String[] courseEntries= parts[1].split(",");
                                StringBuilder rebuilt = new StringBuilder();

                                for (String entry : courseEntries) {
                                    if (!entry.contains("temp")) {
                                        if(!rebuilt.isEmpty()) rebuilt.append(",");
                                        rebuilt.append(entry);
                                    }
                                }
                                parts[1] = rebuilt.toString();
                              //System.out.println(parts[1]);
                            }

                            DayOfWeek targetDay = oldDate.getDayOfWeek();
                            LocalDate newDate = today;

                            // Find the next same weekday
                            while (newDate.getDayOfWeek() != targetDay) {
                                newDate = newDate.plusDays(1);
                            }

                            dateStr = newDate.format(dateFormatter); // updated date string
                        }

                        // Reconstruct the line
                        if (parts.length == 1) {
                            updatedLines.add(dateStr); // No routine entries
                        } else {
                            updatedLines.add(dateStr + "," + parts[1]);
                        }

                    }

                    Map<LocalDate, String> lineMap = new HashMap<>();
                    for (String line : updatedLines) {
                        String[] parts = line.split(",", 2);
                        LocalDate date = LocalDate.parse(parts[0], dateFormatter);
                        lineMap.put(date, line);
                    }

                    List<String> sortedLines = new ArrayList<>();
                    for (int i = 0; i < 14; i++) { // look ahead up to 2 weeks
                        LocalDate target = today.plusDays(i);
                        if (lineMap.containsKey(target)) {
                            sortedLines.add(lineMap.get(target));
                        }
                    }

                        for(String line:sortedLines){
                            // Step 1: Split the date from the rest
                            String[] parts = line.split(",", 2);// take date part, another schedules parts
                            String dateStr = parts[0];
                            String[] courseEntries={""};
                            if(parts.length>1) courseEntries= parts[1].split(",");

                            // System.out.println("Date: " + dateStr);
                            Date date=new Date(dateStr);
                            dept.getLevel(level).getTerm(term).addDate(date);
                            if(parts.length<2){
                                continue;
                            }
                            for (String entry : courseEntries) {
                                // Step 2: Extract course details
                                //   CSE101[08:00;09:00;Room-204]
                                String courseCode = entry.substring(0, entry.indexOf('[')); // prior to courseCode
                                String insideBrackets = entry.substring(entry.indexOf('[') + 1, entry.indexOf(']'));// time and locations inside brackets

                                String[] details = insideBrackets.split(";");

                                String startTime = details[0];
                                String endTime = details[1];
                                String room = details[2];

                                Schedule schedule=new Schedule(findCourse.get(courseCode),startTime,endTime,room);
                                if(details.length==4){
                                    if(details[3].equals("closed")){
                                        schedule.setStatus(false);
                                    }
                                }
                                date.addSchedule(schedule);
                            }
                        }

                    try {
                        // Write to file inside output/
                        File file = new File("DataBase/ClassRoutine/"+deptCode+"/Level"+level+"_Term"+term+".txt");
                        BufferedWriter writer = new BufferedWriter(new FileWriter(file)); // append=true
                        for(var line:sortedLines){
                           // System.out.println(line);
                            writer.write(line);
                            writer.newLine();
                        }
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }


        // Read all exam schedules for date [include all department] and  set them to its term's date list
        for(var dept:departments){
            String deptCode=dept.getDeptCode();
            for(int level=1;level<=4;level++){
                for(int term=1;term<=2;term++){
                    // fileName  ="/CSE/Level1_Term1.txt"
                    //System.out.println(fileName);
                    List<String> updatedLines = new ArrayList<>();
                    List<String> lines = new ArrayList<>();

                    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate today = LocalDate.now();

                    try {
                        File file = new File("DataBase/ExamRoutine/"+deptCode+"/Level"+level+"_Term"+term+".txt");
                        BufferedReader reader = new BufferedReader(new FileReader(file));
                        String line;

                        while ((line = reader.readLine()) != null) {
                            lines.add(line);
                        }

                        reader.close();
                    } catch (FileNotFoundException e) {
                        System.err.println("File not found");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // updating weekday to its corresponding date
                    for (String line : lines) {
                        if (line.isBlank()) {
                            updatedLines.add("");
                            continue;
                        }

                        String[] parts = line.split("\\|", 2); // Split into date and rest
                        String dateStr = parts[0];
                        LocalDate oldDate = LocalDate.parse(dateStr, dateFormatter);

                        if (oldDate.isBefore(today)) {
                            DayOfWeek targetDay = oldDate.getDayOfWeek();
                            LocalDate newDate = today;

                            // Find the next same weekday
                            while (newDate.getDayOfWeek() != targetDay) {
                                newDate = newDate.plusDays(1);
                            }

                            dateStr = newDate.format(dateFormatter); // updated date string
                        }else{
                            updatedLines.add(line);
                            continue;
                        }

                        // Reconstruct the line
                        updatedLines.add(dateStr);// previous exam schedules will be deleted
                    }

                    Map<LocalDate, String> lineMap = new HashMap<>();
                    for (String line : updatedLines) {
                        String[] parts = line.split("\\|", 2);
                        LocalDate date = LocalDate.parse(parts[0], dateFormatter);
                        lineMap.put(date, line);
                    }

                    List<String> sortedLines = new ArrayList<>();
                    for (int i = 0; i < 14; i++) { // look ahead up to 2 weeks
                        LocalDate target = today.plusDays(i);
                        if (lineMap.containsKey(target)) {
                            sortedLines.add(lineMap.get(target));
                        }
                    }

                        for(String line:sortedLines){
                            // Step 1: Split the date from the rest
                            String[] parts = line.split("\\|", 2);// take date part, another schedules parts
                            String dateStr = parts[0];
                            Date date=dept.getLevel(level).getTerm(term).getDate(dateStr.trim());
                            if(date==null){
                                date=new Date(dateStr);
                                dept.getLevel(level).getTerm(term).addDate(date);
                            }
                            if(parts.length<2){  // when no exam   [2025-7-12                           ]
                                continue;
                            }

                            // couting total exam Schedules
                            String[] courseEntries = parts[1].split("\\|");

                            // System.out.println("Date: " + dateStr);
                            for (String entry : courseEntries) {
                                // Step 2: Extract course details
                                //   CSE101[08:00;09:00;Room-204]
                                String courseCode = entry.substring(0, entry.indexOf('[')); // prior to courseCode
                                String insideBrackets = entry.substring(entry.indexOf('[') + 1, entry.indexOf(']'));// time and locations inside brackets

                                String[] details = insideBrackets.split(";");

                                String startTime = details[0];
                                String endTime = details[1];
                                String room = details[2];

                                examSchedule exam=new examSchedule(findCourse.get(courseCode),startTime,endTime,room);
                                if(details.length==4){
                                    exam.setExamTopic(details[3]);
                                }
                                date.addExamSchedule(exam);
                            }

                        }

                }
            }
        }
    }


    // here no checking for valid level,term or student id exist or not
    public static void addStudent(String name,String id,String password,String deptName,int level,int term){

        // if belong unknown dept, no entry
        if(!findDept.containsKey(deptName)){
            System.out.println("Error: student(name:"+name+") in text file with unknown department");
            return;
        }

        Student student=new Student(name,id,password,deptName,level,term);
        // add to list
        students.add(student);
        // add to map
        findStu.put(id,student);

        // set enrolled course
        student.setEnrolledCourses(findDept.get(deptName).getLevel(level).getTerm(term).getCourses());

        // add the student to the term and term
        findDept.get(deptName).getLevel(level).getTerm(term).addStudent(student);

        // add the student to the course
        for(Course takenCourse:findDept.get(deptName).getLevel(level).getTerm(term).getCourses()){
            takenCourse.addStudent(student);
        }

        // adding to file
        try {
            File file = new File("DataBase/Data/student.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));

            String lineFormat=name+","+id+","+password+","+deptName+","+level+","+term+"\n";
            writer.write(lineFormat);
            writer.close();
            //System.out.println("Line written successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addTeacher(String name,String id,String password,String deptName){
        if(!findDept.containsKey(deptName)){
            System.out.println("Error: Teacher(name:"+name+") in text file with unknown department");
            return;
        }
        Teacher teacher=new Teacher(name,id,password,deptName);
        // add teacher to the department
        findDept.get(deptName).addTeacher(teacher);

        // add in the teacher list
        teachers.add(teacher);

        // add in the map
        findTeacher.put(id,teacher);

        // adding to file
        try {
            // Use a real writable path, not getResourceAsStream
            File file = new File("DataBase/Data/teacher.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));

            String lineFormat=name+","+id+","+password+","+deptName+"[]\n";
            writer.write(lineFormat);
            writer.close();
            //System.out.println("Line written successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // no check
    //     course code, instructor id
    public static void addCourse(String courseCode,String courseTitle,String deptName,int level,int term,String instructorID){
        if(!findDept.containsKey(deptName)){
            System.out.println("Error: Trying to add course in unknown department");
            return;
        }

        Teacher instructor=findTeacher.get(instructorID);
        if(instructor==null) {
            System.out.println("NULL teacher,Failed to add course");
            return;
        }

        Course course=new Course(courseCode,courseTitle,level,term);
        course.setInstructor(instructor);

        // add to cousre list
        courses.add(course);

        // add to map
        findCourse.put(courseCode,course);

        // add to the term
        Term term_obj=findDept.get(deptName).getLevel(level).getTerm(term);
        term_obj.addCourse(course);

        // add all students list to the course
        course.setEnrolledStudents(term_obj.getStudents());

        // adding course to file
        try {
            // Use a real writable path, not getResourceAsStream
            File file = new File("DataBase/Data/course.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));

            String lineFormat=courseCode+","+courseTitle+","+deptName+","+level+","+term+"\n";
            writer.write(lineFormat);
            writer.close();
            //System.out.println("Line written successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }



        // update course list for the teacher he was assigned
        //   -> copy all line into a string list except the expected teacher
        List<String> updatedLines=new ArrayList<>();

        // Dr. Hossain Kabir,3003,hossain789,Electrical and Electronic Engineering,[EEE103;EEE203;EEE303]
        try{
            String instructorId=instructor.getID();
            String line;

            File file = new File("DataBase/Data/teacher.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            while((line=reader.readLine())!=null){
                String[] parts=line.trim().split(",");//divide into five parts
                if(parts[1].equals(instructorId.trim())){// id check
                    String coursePart = parts[4].trim(); // "[CE407;CE302;CE103]"

                    // Remove brackets and split
                    String courseListRaw = coursePart.substring(1, coursePart.length() - 1);// CE407;CE302;CE103
                    String newCourseList="["+courseListRaw+";"+courseCode+"]";

                    // Reconstruct the line
                    String updatedLine = String.join(",", parts[0], parts[1], parts[2], parts[3], newCourseList);
                    updatedLines.add(updatedLine);
                }else{
                    updatedLines.add(line);
                }
                //System.out.println(line);
            }
            reader.close();
        }catch(Exception e){
            e.printStackTrace();
        }


        // adding to file
        try {
            // Use a real writable path, not getResourceAsStream
            File file = new File("DataBase/Data/teacher.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for(var updatedLine:updatedLines){
                writer.write(updatedLine);
                writer.write("\n");
            }
            writer.close();
            //System.out.println("Line written successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // if any basic schedule status update then add "closed" it status false
    //   if new add, then added temp when new add course's status is true
    //   if new add is temp, and it status is false then remove the schedule
    public static void updateScedule(String date,String departmentName,int levelTh,int termTh,Schedule sch){
         Department dp=findDept.get(departmentName);
         if(dp==null){
             System.out.println("updated Schedule called on non-exist department");
             return;
         }

         Level level=dp.getLevel(levelTh);
         Term term=level.getTerm(termTh);
         Date dateObj=term.getDate(date);
         if(dateObj==null){
             System.out.println("Date passed in updateSchedule not hold, failed to update schedule");
             return;
         }

         boolean addScedule=true;
         for(Schedule schedule:dateObj.getSchedules()){
             if(schedule.getCourse().equals(sch.getCourse())){
                 if(schedule.getStartTime().equals(sch.getStartTime()) && schedule.getEndTime().equals((sch.getEndTime()))){
                     System.out.println("Existed Called");
                     if(sch.status()!=schedule.status()){
                         schedule.setStatus(sch.status());
                       //  System.out.println("Status changed");
                     }
                     addScedule=false;
                    // System.out.println("Founded one");
                 }
             }
         }
         if(addScedule){
             dateObj.addSchedule(sch);
         }


        String filePath="DataBase/ClassRoutine/"+dp.getDeptCode()+"/Level"+levelTh+"_Term"+termTh+".txt";
        List<String> lines=new ArrayList<>();
        try{
            File file=new File(filePath);
            BufferedReader reader=new BufferedReader(new FileReader(file));
            String line;
            while((line=reader.readLine())!=null){
                if(line.isEmpty()){
                    continue;
                }
                String[] parts=line.split(",",2);
                if(parts[0].equals(date)){
                      StringBuilder updateLine= new StringBuilder(date);
                      if(parts.length>1){
                          String[] courseEntries=parts[1].trim().split(",");
                          for (String entry : courseEntries) {
                              //System.out.println(entry);
                              // Step 2: Extract course details
                              //   CSE101[08:00;09:00;Room-204]
                              String courseCode = entry.substring(0, entry.indexOf('[')); // prior to courseCode
                              String insideBrackets = entry.substring(entry.indexOf('[') + 1, entry.indexOf(']'));// time and locations inside brackets

                              String[] details = insideBrackets.split(";");

                              String startTime = details[0];
                              String endTime = details[1];
                              String room = details[2];

                              if(sch.getCourse().getCourseCode().equals(courseCode) && sch.getStartTime().equals(startTime) && sch.getEndTime().equals(endTime)){
                                 // System.out.println("matches run");
                                  if(details.length==4 && details[3].equals("temp")){
                                      if(sch.status())
                                          updateLine.append(",").append(entry);
                                      else if(!addScedule){
                                          System.out.println("Tried to remove");
                                          dateObj.removeSchedule(sch);
                                      }
                                  }else if(details.length==4 && details[3].equals("closed")){
                                      if(sch.status()){
                                          updateLine.append(",").append(courseCode).append("[").append(startTime).append(";").append(endTime).append(";").append(room).append("]");
                                      }
                                  }else if(!sch.status()){
                                      updateLine.append(",").append(courseCode).append("[").append(startTime).append(";").append(endTime).append(";").append(room).append(";closed]");
                                  }else{
                                      updateLine.append(",").append(entry);
                                  }
                              }else{
                                //  System.out.println("Unmatches run");
                                  updateLine.append(",").append(entry);
                              }
                          }
                      }
                      if(addScedule && sch.status()){
                          updateLine.append(",").append(sch.getCourse().getCourseCode()).append("[").append(sch.getStartTime()).append(";").append(sch.getEndTime()).append(";").append(sch.getLocation()).append(";temp]");
                      }

                      lines.add(updateLine.toString());
                }else{
                    lines.add(line);
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            // Write to file inside output/
            File file = new File(filePath);
            BufferedWriter writer = new BufferedWriter(new FileWriter(file)); // append=true
            for(String line:lines){
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            // System.out.println("File written to: " + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void updateExamScedule(String date,String departmentName,int levelTh,int termTh,examSchedule sch){
        Department dp=findDept.get(departmentName);
        if(dp==null){
            System.out.println("updated Schedule called on non-exist department");
            return;
        }

        Level level=dp.getLevel(levelTh);
        Term term=level.getTerm(termTh);
        Date dateObj=term.getDate(date);
        if(dateObj==null){
            System.out.println("Date passed in updateSchedule not hold, failed to update schedule");
            return;
        }

        boolean addScedule=true;
        for(examSchedule schedule:dateObj.getExamSchedules()){
            if(schedule.getCourse().equals(sch.getCourse())){
                if(schedule.getStartTime().equals(sch.getStartTime()) && schedule.getEndTime().equals((sch.getEndTime()))){
                    addScedule=false;
                }
            }
        }
        if(addScedule){
            dateObj.addExamSchedule(sch);
        }


        String filePath="DataBase/ExamRoutine/"+dp.getDeptCode()+"/Level"+levelTh+"_Term"+termTh+".txt";
        try {
            // Write to file inside output/
            File file = new File(filePath);
            BufferedWriter writer = new BufferedWriter(new FileWriter(file)); // append=true
            for(var dt:term.getDates()){
                String line="";
                line+=dt.getDate();
                for(examSchedule sObj:dt.getExamSchedules()){
                    line+="|"+sObj.getCourse().getCourseCode()+"["+sObj.getStartTime()+";"+sObj.getEndTime()+";"+sObj.getLocation();
                    if(!sObj.getExamTopic().equals("")){
                        line+=";"+ sObj.getExamTopic()+"]";
                    }else{
                        line+="]";
                    }
                }
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            // System.out.println("File written to: " + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



//    public static void main(String[] args) throws IOException {
//        addStudent("himel roy","2050","#himel11","Computer Science and Engineering",1,2);
//       addTeacher("Prof. Salah Uddin","7012","%salah","Electrical and Electronic Engineering");
//         addCourse("CSE-109","Data Structrue","Computer Science and Engineering",1,2,"6008");

//        Course crs=findCourse.get("CSE108");
//        Schedule sc=new Schedule(crs,"10:00","11:00","Room-405");
//        sc.setStatus(true);
//        updateScedule("2025-07-30","Computer Science and Engineering",1,2,sc);
//    }


    public static void main(String[] args) {
        int port = 5000;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port " + port);
            ExecutorService connectionPool = Executors.newCachedThreadPool();
            while (true) {
                Socket clientSocket = serverSocket.accept();
                connectionPool.execute(new ConnectionTask(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Handles the initial login handshake, then dispatches to a role session.
     * We create ObjectOutputStream FIRST, flush, then ObjectInputStream (classic pattern to avoid deadlock).
     */
    private static class ConnectionTask implements Runnable {
        private final Socket socket;
        ConnectionTask(Socket s) { this.socket = s; }
        @Override public void run() {
            ObjectOutputStream out = null;
            ObjectInputStream in = null;
            try {
                out = new ObjectOutputStream(socket.getOutputStream());
                out.flush();
                in = new ObjectInputStream(socket.getInputStream());

                boolean loggedIn = false;
                String role = null;
                Object userObj = null;

                while (!loggedIn) {
                    Object obj = in.readObject();
                    if (!(obj instanceof String creds)) {
                        out.writeObject("FAIL,EXPECTED_STRING");
                        out.flush();
                        continue;
                    }
                    String[] parts = creds.split(",", 2);
                    if (parts.length < 2) {
                        out.writeObject("FAIL,BAD_FORMAT");
                        out.flush();
                        continue;
                    }
                    String id = parts[0].trim();
                    String pw = parts[1].trim();

                    if (authority != null && authority.getId().equals(id) && authority.getPassword().equals(pw)) {
                        loggedIn = true; role = "AUTHORITY"; userObj = authority;
                    } else if (findTeacher.containsKey(id) && findTeacher.get(id).getPassword().equals(pw)) {
                        loggedIn = true; role = "TEACHER"; userObj = findTeacher.get(id);
                    } else if (findCr.containsKey(id) && findCr.get(id).getPassword().equals(pw)) {
                        loggedIn = true; role = "CR"; userObj = findCr.get(id);
                    } else if (findStu.containsKey(id) && findStu.get(id).getPassword().equals(pw)) {
                        loggedIn = true; role = "STUDENT"; userObj = findStu.get(id);
                    }

                    if (loggedIn) {
                        out.writeObject("SUCCESS," + role);
                        //System.out.println(role);
                        out.flush();

                        // === NEW: Immediately send the logged-in user object if Student ===
                        if ("STUDENT".equals(role) | "CR".equals(role)) {
                            Student st=(Student)userObj;
                            out.writeObject(packetStudent(st));// sending client student
                            out.flush();
                            System.out.println(st.getID()+" Logged in");
                        }else if("TEACHER".equals(role)){
                            Teacher teacher=(Teacher)userObj;
                            out.writeObject(packetTeacher(teacher));// sending client  teacher
                            out.flush();
                            System.out.println(teacher.getID()+" Logged in");
                        }else if("AUTHORITY".equals(role)){
                            out.writeObject(authority);
                            out.flush();
                            System.out.println("Authority logged in");
                        }
                    } else {
                        System.out.println("Else run");
                        out.writeObject("FAIL,INVALID_CREDENTIALS");
                        out.flush();
                    }
                }

                // Hand off to role session (shares same streams)
                Runnable session = switch (role) {
                    case "AUTHORITY" -> {
                        AuthoritySession s = new AuthoritySession((Authority) userObj, in, out, socket);
                        activeAuthoritySessions.put(((Authority) userObj).getId(), s);
                        yield s;
                    }
                    case "TEACHER" -> {
                        TeacherSession s = new TeacherSession((Teacher) userObj, in, out, socket);
                        activeTeacherSessions.put(((Teacher) userObj).getID(), s);
                        yield s;
                    }
                    case "CR" -> {
                        CRSession s = new CRSession((CR) userObj, in, out, socket);
                        activeCRSessions.put(((CR) userObj).getID(), s);
                        yield s;
                    }
                    case "STUDENT" -> {
                        StudentSession s = new StudentSession((Student) userObj, in, out, socket);
                        activeStudentSessions.put(((Student) userObj).getID(), s);
                        yield s;
                    }
                    default -> null;
                };
                if (session != null) session.run(); // or new Thread(session).start();
            } catch (EOFException ignore) {
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try { if (in != null) in.close(); } catch (IOException ignored) {}
                try { if (out != null) out.close(); } catch (IOException ignored) {}
                try { socket.close(); } catch (IOException ignored) {}
            }
        }
    }

    private static final Map<String, StudentSession> activeStudentSessions = new ConcurrentHashMap<>();
    private static final Map<String, TeacherSession> activeTeacherSessions = new ConcurrentHashMap<>();
    private static final Map<String, CRSession> activeCRSessions = new ConcurrentHashMap<>();
    private static final Map<String, AuthoritySession> activeAuthoritySessions = new ConcurrentHashMap<>();

    /**
     * Abstract role session. Reads serialized command objects (Strings for now) and writes responses.
     */
    private static abstract class AbstractSession implements Runnable {
        protected final ObjectInputStream in;
        protected final ObjectOutputStream out;
        protected final Socket socket;
        protected boolean running = true;
        AbstractSession(ObjectInputStream in, ObjectOutputStream out, Socket socket) {
            this.in = in; this.out = out; this.socket = socket;
        }
        @Override
        public void run() {
            try {
                while (running) {
                    Object obj = in.readObject();
                    if (!(obj instanceof String cmd)) {
                        out.writeObject("ERR,EXPECTED_STRING_CMD");
                        out.flush();
                        continue;
                    }
                    handleCommand(cmd);
                }
            } catch (EOFException | SocketException e) {
                System.out.println("Client disconnected: ");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                // Always cleanup here
                try {
                    in.close();
                    out.close();
                    socket.close();
                } catch (IOException ignored) {}

                // Remove from active session map
                System.out.println("Session closed");
            }
        }
        protected abstract void handleCommand(String cmd);
    }

    private static class AuthoritySession extends AbstractSession {
        private final Authority user;
        AuthoritySession(Authority user, ObjectInputStream in, ObjectOutputStream out, Socket socket) {
            super(in, out, socket); this.user = user; }
        protected void handleCommand(String cmd) {
            if (cmd.equals("EXIT")) {
                try {
                    out.close();
                    in.close();
                    socket.close();
                    System.out.println("Autority Logged out");
                    activeAuthoritySessions.remove(authority.getId());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                running = false;
            }else if(cmd.equals("ADD-STUDENT")){
                try {
                    Object obj=in.readObject();
                    if(!(obj instanceof Student student)){
                        System.out.println("Failed to receive student");
                        return;
                    }

                    addStudent(student.getName(),student.getID(),student.getPassword(),student.getDepartmentName(),student.getLevel(),student.getTerm());
                    System.out.println("added "+student.getID()+" successfully");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }else if(cmd.equals("ADD-TEACHER")){
                try {
                    Object obj=in.readObject();
                    if(!(obj instanceof Teacher teacher)){
                        System.out.println("Failed to receive student");
                        return;
                    }
                    addTeacher(teacher.getName(),teacher.getID(), teacher.getPassword(),teacher.getDepartment());
                    System.out.println("added "+teacher.getID()+" successfully");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }else if(cmd.equals("ADD-COURSE")){
                try {
                    Object obj1=in.readObject();
                    if(!(obj1 instanceof String dept)){
                        System.out.println("Failed to receive department name");
                        return;
                    }
                    Object obj2=in.readObject();
                    if(!(obj2 instanceof Course course)){
                        System.out.println("Failed to receive student");
                        return;
                    }
                    addCourse(course.getCourseCode(),course.getCourseName(),dept,course.getLevel(),course.getTerm(),course.getInstructor().getID());
                    System.out.println("added "+course.getCourseCode()+" successfully");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private static class TeacherSession extends AbstractSession {
        private final Teacher user;
        TeacherSession(Teacher user, ObjectInputStream in, ObjectOutputStream out, Socket socket) {
            super(in, out, socket); this.user = user; }
        protected void handleCommand(String cmd) {
            if (cmd.equals("EXIT")) {
                try {
                    out.close();
                    in.close();
                    socket.close();
                    System.out.println(user.getName()+" Logged out");
                    activeTeacherSessions.remove(user.getID());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                running = false;
            }
        }
    }

    private static class StudentSession extends AbstractSession {
        private final Student user;
        StudentSession(Student u, ObjectInputStream in, ObjectOutputStream out, Socket s) { super(in,out,s); this.user=u; }
        @Override  protected void handleCommand(String cmd) {
            if (cmd.equals("EXIT")) {
                try {
                    out.close();
                    in.close();
                    socket.close();
                    System.out.println(user.getID()+" Logged out");
                    activeStudentSessions.remove(user.getID());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                running = false;
            }
        }
    }

    private static class CRSession extends AbstractSession {
        private final CR user;
        CRSession(CR user, ObjectInputStream in, ObjectOutputStream out, Socket socket) {
            super(in, out, socket); this.user = user; }
        protected void handleCommand(String cmd) {
            if (cmd.equals("EXIT")) {
                try {
                    out.close();
                    in.close();
                    socket.close();
                    System.out.println(user.getID()+" Logged out");
                    activeCRSessions.remove(user.getID());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                running = false;
            }else if(cmd.equals("UPDATE-SCHEDULE")){
                try {
                        Object strObj = in.readObject();
                        if(!(strObj instanceof String dateStr)){
                            System.out.println("Failed to get dateStr");
                            return;
                        }

                        Object obj=in.readObject();
                        if (!(obj instanceof clientS_schedule schedule)) {
                            System.out.println("Failed to get Date object");
                            return;
                            //out.writeObject("ERR,EXPECTED_STRING_CMD");
                            //out.flush();
                        }

                        System.out.println("Received: "+schedule.getCourse().getCourseCode()+": "+schedule.getStartTime()+": "+schedule.getEndTime()+": "+schedule.getLocation()+": "+schedule.status());
                        Course course=findCourse.get(schedule.getCourse().getCourseCode());
                        Schedule newSchedule=new Schedule(course,schedule.getStartTime(),schedule.getEndTime(),schedule.getLocation(),schedule.status());
                        updateScedule(dateStr,user.getDepartmentName(),user.getLevel(),user.getTerm(),newSchedule);

                        clientS_date sentDate=new clientS_date(dateStr);
                        Department dp=findDept.get(user.getDepartmentName());
                        Level lv=dp.getLevel(user.getLevel());
                        Term tr=lv.getTerm(user.getTerm());

                        for(Schedule sc:tr.getDate(dateStr).getSchedules()){
                            clientS_course scCourse=new clientS_course(sc.getCourse().getCourseCode(),sc.getCourse().getCourseName(),sc.getCourse().getInstructor().getName());
                            clientS_schedule cSC=new clientS_schedule(scCourse,sc.getStartTime(),sc.getEndTime(),sc.getLocation(),sc.status());
                            sentDate.addSchedule(cSC);
                        }
                        for(Student st:tr.getStudents()){
                            if(activeStudentSessions.containsKey(st.getID())){
                                StudentSession stSession=activeStudentSessions.get(st.getID());
                                stSession.out.writeObject("UPDATE-SCHEDULE");
                                stSession.out.writeObject(sentDate);
                                System.out.println("Object successfully sent to "+user.getID());
                            }
                        }
                        for(CR cr:tr.getCrs()){
                            if(activeCRSessions.containsKey(cr.getID())){
                                CRSession crSession=activeCRSessions.get(cr.getID());
                                crSession.out.writeObject("UPDATE-SCHEDULE");
                                crSession.out.writeObject(sentDate);
                            }
                        }

                        // date transfer to teacher
                        Teacher teacher=course.getInstructor();
                        String teacherId=teacher.getID();
                        if(!activeTeacherSessions.containsKey(teacherId)){
                            return;
                        }
                        clientT_date sentTdate=new clientT_date(dateStr);
                        Department department=findDept.get(teacher.getDepartment());
                        for(Course crs:teacher.getAssignedCourses()){
                            Level lev=department.getLevel(crs.getLevel());
                            Term term=lev.getTerm(crs.getTerm());

                            Date dt=term.getDate(dateStr);
                            for(Schedule es:dt.getSchedules()){
                                if(crs.equals(es.getCourse())){
                                    clientT_course clientCourse=new clientT_course(crs.getCourseCode(),crs.getCourseName());
                                    clientT_schedule esch=new clientT_schedule(clientCourse,es.getStartTime(),es.getEndTime(),es.getLocation(),es.status());
                                    sentTdate.addSchedule(esch);
                                }
                            }
                        }

                        TeacherSession teacherSession=activeTeacherSessions.get(teacherId);
                        teacherSession.out.writeObject("UPDATE-SCHEDULE");
                        teacherSession.out.writeObject(sentTdate);
                } catch (EOFException | SocketException e) {
                    System.out.println("Client disconnected: ");
                    // Always cleanup here
                    try {
                        in.close();
                        out.close();
                        socket.close();
                        running=false;
                    } catch (IOException ignored) {}
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else if(cmd.equals("UPDATE-EXAM-SCHEDULE")){
                try {
                    Object strObj = in.readObject();
                    if(!(strObj instanceof String dateStr)){
                        System.out.println("Failed to get dateStr");
                        return;
                    }

                    Object obj=in.readObject();
                    if (!(obj instanceof clientS_examSchedule schedule)) {
                        System.out.println("Failed to get Date object");
                        return;
                        //out.writeObject("ERR,EXPECTED_STRING_CMD");
                        //out.flush();
                    }

                    System.out.println("Received: "+schedule.getCourse().getCourseCode()+": "+schedule.getStartTime()+": "+schedule.getEndTime()+": "+schedule.getLocation()+": "+schedule.getExamTopic());
                    Course course=findCourse.get(schedule.getCourse().getCourseCode());
                    examSchedule newSchedule=new examSchedule(course,schedule.getStartTime(),schedule.getEndTime(),schedule.getLocation(),schedule.getExamTopic());
                    updateExamScedule(dateStr,user.getDepartmentName(),user.getLevel(),user.getTerm(),newSchedule);

                    clientS_date sentDate=new clientS_date(dateStr);
                    Department dp=findDept.get(user.getDepartmentName());
                    Level lv=dp.getLevel(user.getLevel());
                    Term tr=lv.getTerm(user.getTerm());

                    for(examSchedule sc:tr.getDate(dateStr).getExamSchedules()){
                        clientS_course scCourse=new clientS_course(sc.getCourse().getCourseCode(),sc.getCourse().getCourseName(),sc.getCourse().getInstructor().getName());
                        clientS_examSchedule cESC=new clientS_examSchedule(scCourse,sc.getStartTime(),sc.getEndTime(),sc.getLocation(),sc.getExamTopic());
                        sentDate.addExamSchedule(cESC);
                    }
                    for(Student st:tr.getStudents()){
                        if(activeStudentSessions.containsKey(st.getID())){
                            StudentSession stSession=activeStudentSessions.get(st.getID());
                            stSession.out.writeObject("UPDATE-EXAM-SCHEDULE");
                            stSession.out.writeObject(sentDate);
                            System.out.println("Object successfully sent to "+user.getID());
                        }
                    }
                    for(CR cr:tr.getCrs()){
                        if(activeCRSessions.containsKey(cr.getID())){
                            CRSession crSession=activeCRSessions.get(cr.getID());
                            crSession.out.writeObject("UPDATE-EXAM-SCHEDULE");
                            crSession.out.writeObject(sentDate);
                            System.out.println("Object successfully sent to "+user.getID());
                        }
                    }


                    Teacher teacher=course.getInstructor();
                    String teacherId=teacher.getID();
                    if(!activeTeacherSessions.containsKey(teacherId)){
                        return;
                    }
                    clientT_date sentTdate=new clientT_date(dateStr);
                    Department department=findDept.get(teacher.getDepartment());
                    for(Course crs:teacher.getAssignedCourses()){
                        Level lev=department.getLevel(crs.getLevel());
                        Term term=lev.getTerm(crs.getTerm());

                        Date dt=term.getDate(dateStr);
                            for(examSchedule es:dt.getExamSchedules()){
                                if(crs.equals(es.getCourse())){
                                    clientT_course clientCourse=new clientT_course(crs.getCourseCode(),crs.getCourseName());
                                    clientT_examSchedule esch=new clientT_examSchedule(clientCourse,es.getStartTime(),es.getEndTime(),es.getLocation(),es.getExamTopic());
                                    sentTdate.addExamSchedule(esch);
                                }
                            }
                    }
                    TeacherSession teacherSession=activeTeacherSessions.get(teacherId);
                    teacherSession.out.writeObject("UPDATE-EXAM-SCHEDULE");
                    teacherSession.out.writeObject(sentTdate);
                } catch (EOFException | SocketException e) {
                    System.out.println("Client disconnected: ");
                    // Always cleanup here
                    try {
                        in.close();
                        out.close();
                        socket.close();
                        running=false;
                    } catch (IOException ignored) {}
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    private static clientS_stu packetStudent(Student st){
        clientS_stu stu=new clientS_stu(st.getID(),st.getName(),st.getDepartmentName(),st.getLevel(), st.getTerm());

        HashMap<String,clientS_course> find_stuCourses=new HashMap<>();
        Department stuDept=findDept.get(st.getDepartmentName());
        Level stuLev=stuDept.getLevel(st.getLevel());
        Term stuTerm=stuLev.getTerm(st.getTerm());
        for(Course crs:stuTerm.getCourses()){
            clientS_course stu_crs=new clientS_course(crs.getCourseCode(),crs.getCourseName(),crs.getInstructor().getName());
            find_stuCourses.put(crs.getCourseCode(),stu_crs);
            stu.addCourse(stu_crs);
        }

        for(Date dt:stuTerm.getDates()){
            List<clientS_schedule> c_schedules=new ArrayList<>();
            List<clientS_examSchedule> c_ex_schedules=new ArrayList<>();
            for(Schedule sc:dt.getSchedules()){
                Course crs=sc.getCourse();
                clientS_schedule sch=new clientS_schedule(find_stuCourses.get(crs.getCourseCode()),sc.getStartTime(),sc.getEndTime(),sc.getLocation());
                if(!sc.status()){
                    //System.out.println("one found");
                    sch.setStatus(false);
                }
                c_schedules.add(sch);
            }
            for(examSchedule exsc:dt.getExamSchedules()){
                Course crs= exsc.getCourse();
                clientS_examSchedule exsch=new clientS_examSchedule(find_stuCourses.get(crs.getCourseCode()),exsc.getStartTime(),exsc.getEndTime(),exsc.getLocation(),exsc.getExamTopic());
                c_ex_schedules.add(exsch);
            }
            clientS_date date=new clientS_date(dt.getDate(),c_schedules,c_ex_schedules);
            stu.addDate(date);
        }

        return stu;
    }

    private static clientT_teacher packetTeacher(Teacher teacher){
        clientT_teacher cTeacher=new clientT_teacher(teacher.getID(),teacher.getName(),teacher.getDepartment());

        List<clientT_date> clientDates=new ArrayList<>();
        HashMap<String,clientT_date> findCdates=new HashMap<>();

        LocalDate today = LocalDate.now();
        String formattedDate = today.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate startDate = LocalDate.parse(formattedDate, formatter);

        // creating 7days object
        for (int i = 0; i < 7; i++) {
            LocalDate nextDate = startDate.plusDays(i);
            formattedDate=nextDate.format(formatter);
            clientT_date cDate=new clientT_date(formattedDate);
            //System.out.println(cDate.getDate());
            clientDates.add(cDate);
            findCdates.put(formattedDate,cDate);
        }

        Department department=findDept.get(teacher.getDepartment());
        for(Course crs:teacher.getAssignedCourses()){
            clientT_course clientCourse=new clientT_course(crs.getCourseCode(),crs.getCourseName());
            cTeacher.addCourse(clientCourse);

            Level lev=department.getLevel(crs.getLevel());
            Term term=lev.getTerm(crs.getTerm());
            for(Date date:term.getDates()){
                if(!findCdates.containsKey(date.getDate())){
                    break;
                }
                for(Schedule sch:date.getSchedules()){
                    if(crs.equals(sch.getCourse())){
                        clientT_schedule csch=new clientT_schedule(clientCourse,sch.getStartTime(),sch.getEndTime(),sch.getLocation(),sch.status());
                        findCdates.get(date.getDate()).addSchedule(csch);
                    }
                }
                for(examSchedule es:date.getExamSchedules()){
                    if(crs.equals(es.getCourse())){
                        clientT_examSchedule esch=new clientT_examSchedule(clientCourse,es.getStartTime(),es.getEndTime(),es.getLocation(),es.getExamTopic());
                        findCdates.get(date.getDate()).addExamSchedule(esch);
                    }
                }
            }
        }

        cTeacher.setDates(clientDates);

        return cTeacher;
    }

}

/*
      //addStudent("himel roy","2050","#himel11","Computer Science and Engineering",1,2);
          // addTeacher("Prof. Salah Uddin","7012","%salah","Electrical and Electronic Engineering");
           addCourse("CSE-143","dummy","Computer Science and Engineering",1,1,"6009");
//
//         for(var x:departments){
//             System.out.println("dept Name: " +x.getName());
//         }

//         for(var x:courses){
//             System.out.println("code: " + x.getCourseCode() + " ,Name: "+x.getCourseName()+" , Level: "+x.getLevel()+" , Term: "+x.getTerm());
//         }
//


        //printing courses under dept,level and terms
//         for(var x:departments){
//            System.out.println("Course fordept: "+x.getName());
//             for(Level level:x.getLevels()){
//                  for(Term term:level.getTerms()){
//                    // System.out.println("level: "+level+", term: "+term);
//                         for(Course course:term.getCourses()){
//                             System.out.println(course.getCourseCode());
//                         }
//                     System.out.println();
//                  }
//             }
//            System.out.print("\n\n\n");
//         }
//





        // // find the enrolled courses of a student by id
//        String inputId;
//        Scanner sc=new Scanner(System.in);
//        while (true) {
//            System.out.println("Inter student id: ");
//            inputId=sc.nextLine();
//            if(inputId.equals("q")) break;
//
//            if(findStu.containsKey(inputId.trim())){
//                Student stu=findStu.get(inputId);
//                System.out.println("Student Name: "+stu.getName());
//                System.out.println("Enrolled Courses: ");
//                for(var x:stu.getEnrolledCourses()){
//                    System.out.println("course code: "+x.getCourseCode());
//                }
//            }else{
//                System.out.println("wrong id");
//            }
//        }



//
//        // find the assigned courses of a teacher by id
//         Scanner sc=new Scanner(System.in);
//         String inputId;
//         while (true) {
//             System.out.println("Inter teacher id: ");
//             inputId=sc.nextLine();
//             if(inputId.equals("q")) break;
//
//             if(findTeacher.containsKey(inputId.trim())){
//                 Teacher techer=findTeacher.get(inputId);
//                 System.out.println("Teacher Name: "+techer.getName());
//                 System.out.println("assigned Courses: ");
//                 for(var x:techer.getAssignedCourses()){
//                      System.out.println("course code: "+x.getCourseCode());
//                 }
//             }else{
//                 System.out.println("wrong id");
//             }
//         }





        // // printing crs list nder dept,level and terms
//         for(var x:departments){
//            System.out.println("\nCR fordept: "+x.getName());
//             for(Level level:x.getLevels()){
//                  for(Term term:level.getTerms()){
//                    // System.out.println("level: "+level+", term: "+term);
//                         for(CR cr:term.getCrs()){
//                             System.out.println(cr.getName());
//                         }
//                    // System.out.println();
//                  }
//             }
//            System.out.print("\n");
//         }




        // checking the access of authority
//        while(true){
//            System.err.println("1: get deparment names");
//            System.err.println("2: get students of a department");
//            System.err.println("3: get teacher of a department");
//            System.err.println("Enter choice: ");
//
//            Scanner sc=new Scanner(System.in);
//            String inputLine=sc.nextLine();
//            if(inputLine.equals("q")) break;
//            try {
//                int choice = Integer.parseInt(inputLine.trim());
//                switch (choice) {
//                    case 1:
//                        String id,password;
//                        System.out.println("Enter authority id: ");
//                        id=sc.nextLine();
//
//                        System.out.println("Enter authority password: ");
//                        password=sc.nextLine();
//                        if(authority.verify(id, password)){
//                            System.out.println("Departments: ");
//                            for(Department dept:authority.getVarsity(id,password).getDepartments()){
//                                System.out.println(dept.getName());
//                            }
//                        }else{
//                            System.out.println("Unauthorized access attempt!");
//                        }
//                        break;
//                    case 2:
//                        System.out.println("Enter department name: ");
//                        String deptName=sc.nextLine();
//                        if(findDept.containsKey(deptName)){
//                            System.out.println("Students in "+deptName+": ");
//                            for(Level level:findDept.get(deptName).getLevels()){
//                                for(Term term:level.getTerms()){
//                                    for(Student stu:term.getStudents()){
//                                        System.out.println(stu.getName()+" , id: "+stu.getID());
//                                    }
//                                }
//                            }
//
//                        }else{
//                            System.out.println("Department not found");
//                        }
//                        break;
//                    case 3:
//                        System.out.println("Enter department name: ");
//                        String deptName2=sc.nextLine();
//                        if(findDept.containsKey(deptName2)){
//                            System.out.println("Teachers in "+deptName2+": ");
//                            for(Teacher teacher:findDept.get(deptName2).getTeachers()){
//                                System.out.println(teacher.getName()+" , id: "+teacher.getID());
//                            }
//                        }else{
//                            System.out.println("Department not found");
//                        }
//                        break;
//                    default:
//                        System.out.println("Invalid choice");
//
//                }
//            }catch (NumberFormatException e) {
//                System.out.println("Please enter a valid number");
//            }
//        }






        // all schedules for department
        Department dp=findDept.get("Computer Science and Engineering");
        for(var date:dp.getLevel(3).getTerm(1).getDates()){
            System.out.println("Date: "+date.getDate());
            for(var schedule:date.getExamSchedules()){
                System.out.println("Course Code: " + schedule.getCourse().getCourseCode()+", Teacher:"+schedule.getCourse().getInstructor().getName());
                System.out.println("Start Time: " + schedule.getStartTime());
                System.out.println("End Time: " + schedule.getEndTime());
                System.out.println("Room: " + schedule.getLocation());
                System.out.println("-----------------------");
            }
            System.out.println("\n\n");
        }

    }

 */
    /*
    static{
        varsityName="Bangladesh University of Engineering and Technology";


//        String deptFile_Name="DataBase/Data/department.txt";
//        // department.txt
//        try (BufferedReader br = new BufferedReader(new InputStreamReader(Server.class.getResourceAsStream(deptFile_Name)))) {
//            String line;
//            while((line=br.readLine())!=null){
//                String[] parts=line.trim().split(",");
//                String deptName=parts[0];
//                String deptCode=parts[1];
//                Department department=new Department(deptName,deptCode);
//
//                // updating deptName
//                findDept.put(deptName,department);
//
//                // adding in list
//                departments.add(department);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }


        String courseFile_Name="/Date/course.txt";
        // course code,course name,dept name, level, term
        try(BufferedReader br = new BufferedReader(new InputStreamReader(
                Server.class.getResourceAsStream(courseFile_Name)))){
            String line;
            while((line=br.readLine())!=null){
                String[] parts=line.trim().split(",");

                String courseCode=new String(parts[0]);
                String courseName=new String(parts[1]);
                String deptName=parts[2];
                int level=Integer.valueOf(parts[3]);
                int term=Integer.valueOf(parts[4]);

                Course course=new Course(courseCode,courseName,level,term);

                // adding course to which dept and  level and terms it belongs to
                if(findDept.containsKey(deptName)){
                    findDept.get(deptName).getLevel(level).getTerm(term).addCourse(course);
                }else{
                    // department not exist in the server datas
                    Department department=new Department(deptName);
                    departments.add(department);
                    findDept.put(deptName,department);
                    findDept.get(deptName).getLevel(level).getTerm(term).addCourse(course);
                }
                // adding to list
                courses.add(course);

                // adding in map
                findCourse.put(courseCode,course);
            }
        }catch(Exception e){
            e.printStackTrace();
        }


        String stuFile_Name="/Date/student.txt";
        // name,id,password,dept name,level,term
        try(BufferedReader br = new BufferedReader(new InputStreamReader(
                Server.class.getResourceAsStream(stuFile_Name)))){
            String line;
            while((line=br.readLine())!=null){
                String[] parts=line.trim().split(",");

                String name=parts[0];
                String id=parts[1];
                String password=parts[2];
                String deptName=parts[3];
                int level=Integer.valueOf(parts[4].trim());
                int term=Integer.valueOf(parts[5].trim());

                // if belong unknown dept,no add
                if(!findDept.containsKey(deptName)){
                    System.out.println("Error: student(name:"+name+") in text file with unknown department");
                    continue;
                }

                Student student=new Student(name,id,password,deptName,level,term);
                // add to list
                students.add(student);
                // add to map
                findStu.put(id,student);

                // set enrolled course
                student.setEnrolledCourses(findDept.get(deptName).getLevel(level).getTerm(term).getCourses());

                // add the student to the term and term
                findDept.get(deptName).getLevel(level).getTerm(term).addStudent(student);

                // add the student to the course
                for(Course takenCourse:findDept.get(deptName).getLevel(level).getTerm(term).getCourses()){
                    takenCourse.addStudent(student);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }


        String teacherFile_Name="/Date/teacher.txt";
        // Dr. Hossain Kabir,3003,hossain789,Electrical and Electronic Engineering,[EEE103;EEE203;EEE303]
        try(BufferedReader br = new BufferedReader(new InputStreamReader(
                Server.class.getResourceAsStream(teacherFile_Name)))){
            String line;
            while((line=br.readLine())!=null){
                String[] parts=line.trim().split(",");

                String name=parts[0];
                String id=parts[1];
                String password=parts[2];
                String deptName=parts[3];
                if(!findDept.containsKey(deptName)){
                    System.out.println("Error: Teacher(name:"+name+") in text file with unknown department");
                    continue;
                }
                // Last part (index 4 here) contains assigned courses string
                String assignedCourses = parts[4];  // "[CE101;CE201;CE301]"

                // Remove brackets and split
                assignedCourses = assignedCourses.trim().substring(1, assignedCourses.length() - 1);
                String[] courseCodes = assignedCourses.trim().split(";");


                Teacher teacher=new Teacher(name,id,password,deptName);
                //System.out.println(teacher.getName());
                for (int i = 0; i < courseCodes.length; i++) {
                    courseCodes[i] = courseCodes[i].trim();
                    //System.out.println(courseCodes[i]);

                    // searching if it is valid course code
                    if(findCourse.containsKey(courseCodes[i])){
                        // add course to the course list of teacher
                        teacher.addCourse(findCourse.get(courseCodes[i]));

                        // assigning course teacher to the course
                        findCourse.get(courseCodes[i]).setInstructor(teacher);
                    }else{
                        System.out.println("Techer: "+teacher.getName()+" assigned to a non-exist course");
                    }
                }

                // add teacher to the department
                findDept.get(deptName).addTeacher(teacher);

                // add in the teacher list
                teachers.add(teacher);

                // add in the map
                findTeacher.put(id,teacher);
            }
        }catch(Exception e){
            e.printStackTrace();
        }

        String crFile_Name="/Date/cr.txt";
        // name,id,password,dept name,level,term
        try(BufferedReader br = new BufferedReader(new InputStreamReader(
                Server.class.getResourceAsStream(crFile_Name)))){
            String line;
            while((line=br.readLine())!=null){
                String[] parts=line.trim().split(",");

                String name=parts[0];
                String id=parts[1];
                String password=parts[2];
                String deptName=parts[3];
                int level=Integer.valueOf(parts[4]);
                int term=Integer.valueOf(parts[5]);

                CR cr=new CR(name,id,password,deptName,level,term);
                // add to list
                crs.add(cr);
                // add to map
                findCr.put(id,cr);

                // if belong dept not exist create it
                if(!findDept.containsKey(deptName)){
                    Department department=new Department(deptName);
                    departments.add(department);
                    findDept.put(deptName,department);
                    System.out.println("Added");
                }
                // set enrolled course
                cr.setEnrolledCourses(findDept.get(deptName).getLevel(level).getTerm(term).getCourses());

                // add the student to the term and term
                findDept.get(deptName).getLevel(level).getTerm(term).addCR(cr);

                // add the student to the course
                for(Course takenCourse:findDept.get(deptName).getLevel(level).getTerm(term).getCourses()){
                    takenCourse.addStudent((Student)cr);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }




        varsity=new Varsity(varsityName,departments);
        authority=new Authority(varsity);


        // Read all schedules for date [include all department] and  set them to its term's date list
        for(var dept:departments){
            String deptCode=dept.getDeptCode();
            for(int level=1;level<=4;level++){
                for(int term=1;term<=2;term++){
                    // fileName  ="/CSE/Level1_Term1.txt"
                    String fileName="/ClassRoutine/"+deptCode+"/Level"+level+"_Term"+term+".txt";
                    //System.out.println(fileName);
                    try{
                        BufferedReader br=new BufferedReader(new InputStreamReader(Server.class.getResourceAsStream(fileName)));
                        if(br==null){
                            System.out.println("wrong path");
                            break;
                        }
                        String line;
                        while((line=br.readLine())!=null){
                            // Step 1: Split the date from the rest
                            String[] parts = line.split(",", 2);// take date part, another schedules parts
                            String dateStr = parts[0];
                            String[] courseEntries = parts[1].split(",");

                            // System.out.println("Date: " + dateStr);
                            Date date=new Date(dateStr);
                            dept.getLevel(level).getTerm(term).addDate(date);
                            for (String entry : courseEntries) {
                                // Step 2: Extract course details
                                //   CSE101[08:00;09:00;Room-204]
                                String courseCode = entry.substring(0, entry.indexOf('[')); // prior to courseCode
                                String insideBrackets = entry.substring(entry.indexOf('[') + 1, entry.indexOf(']'));// time and locations inside brackets

                                String[] details = insideBrackets.split(";");

                                String startTime = details[0];
                                String endTime = details[1];
                                String room = details[2];

                                Schedule schedule=new Schedule(findCourse.get(courseCode),startTime,endTime,room);
                                if(details.length==4){
                                    schedule.setStatus(false);
                                }
                                date.addSchedule(schedule);
                            }

                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
        }



        // Read all exam schedules for date [include all department] and  set them to its term's date list
        for(var dept:departments){
            String deptCode=dept.getDeptCode();
            for(int level=1;level<=4;level++){
                for(int term=1;term<=2;term++){
                    // fileName  ="/CSE/Level1_Term1.txt"
                    String fileName="/ExamRoutine/"+deptCode+"/Level"+level+"_Term"+term+".txt";
                    //System.out.println(fileName);
                    try{
                        BufferedReader br=new BufferedReader(new InputStreamReader(Server.class.getResourceAsStream(fileName)));
                        if(br==null){
                            System.out.println("wrong path");
                            break;
                        }
                        String line;
                        while((line=br.readLine())!=null){
                            // Step 1: Split the date from the rest
                            String[] parts = line.split(",", 2);// take date part, another schedules parts
                            String dateStr = parts[0];
                            Date date=dept.getLevel(level).getTerm(term).getDate(dateStr.trim());
                            if(date==null){
                                date=new Date(dateStr);
                                dept.getLevel(level).getTerm(term).addDate(date);
                            }
                            if(parts.length<2){  // when no exam   [2025-7-12                           ]
                                break;
                            }

                            String[] courseEntries = parts[1].split(",");

                            // System.out.println("Date: " + dateStr);

                            for (String entry : courseEntries) {
                                // Step 2: Extract course details
                                //   CSE101[08:00;09:00;Room-204]
                                String courseCode = entry.substring(0, entry.indexOf('[')); // prior to courseCode
                                String insideBrackets = entry.substring(entry.indexOf('[') + 1, entry.indexOf(']'));// time and locations inside brackets

                                String[] details = insideBrackets.split(";");

                                String startTime = details[0];
                                String endTime = details[1];
                                String room = details[2];

                                examSchedule exam=new examSchedule(findCourse.get(courseCode),startTime,endTime,room);
                                date.addExamSchedule(exam);
                            }

                        }
                    }catch(Exception e){
                        System.out.println("Error: "+dept.getName()+" Term: "+term+"level: "+level);
                        e.printStackTrace();
                    }
                }
            }
        }

    }
    */
/*
  public static void main(String[] args) {
         for(var x:departments){
             System.out.println("dept Name: " +x.getName());
         }
          for(var x:courses){
             System.out.println("code: " + x.getCourseCode() + " ,Name: "+x.getCourseName()+" , Level: "+x.getLevel()+" , Term: "+x.getTerm());
         }
        Department dp=findDept.get("Computer Science and Engineering");
        for(var date:dp.getLevel(3).getTerm(1).getDates()){
            System.out.println("Date: "+date.getDate());
            for(var schedule:date.getExamSchedules()){
                System.out.println("Course Code: " + schedule.getCourse().getCourseCode()+", Teacher:"+schedule.getCourse().getInstructor().getName());
                System.out.println("Start Time: " + schedule.getStartTime());
                System.out.println("End Time: " + schedule.getEndTime());
                System.out.println("Room: " + schedule.getLocation());
                System.out.println("-----------------------");
            }
            System.out.println("\n\n");
        }
    }
 */
