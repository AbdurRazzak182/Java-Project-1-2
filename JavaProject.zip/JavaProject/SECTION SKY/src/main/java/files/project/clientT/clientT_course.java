package files.project.clientT;

import java.io.Serializable;

public class clientT_course implements Serializable {
    private String courseCode;
    private String courseTitle;

    // Default constructor
    public clientT_course() {
    }

    // Parameterized constructor
    public clientT_course(String courseCode, String courseTitle) {
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
    }

    // Getters and Setters
    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }
}
