package files.project.clientT;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class clientT_date implements Serializable {
    private static final long serialVersionUID = 1L;

    private String date;
    private List<clientT_schedule> schedules;
    private List<clientT_examSchedule> examSchedules;

    // Default constructor
    public clientT_date() {
        this.date = "";
        this.schedules = new ArrayList<>();
        this.examSchedules = new ArrayList<>();
    }
    public clientT_date(String date) {
        this.date = date;
        this.schedules = new ArrayList<>();
        this.examSchedules = new ArrayList<>();
    }
    // Parameterized constructor
    public clientT_date(String date, List<clientT_schedule> schedules, List<clientT_examSchedule> examSchedules) {
        this.date = date;
        this.schedules = schedules;
        this.examSchedules = examSchedules;
    }

    // Getters and Setters
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<clientT_schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(List<clientT_schedule> schedules) {
        this.schedules = schedules;
    }

    public List<clientT_examSchedule> getExamSchedules() {
        return examSchedules;
    }

    public void setExamSchedules(List<clientT_examSchedule> examSchedules) {
        this.examSchedules = examSchedules;
    }

    public void addSchedule(clientT_schedule schedule){
        if(schedule!=null){
            schedules.add(schedule);
        }
    }

    public void addExamSchedule(clientT_examSchedule examSchedule){
        if(examSchedule!=null){
            examSchedules.add(examSchedule);
        }
    }
}
