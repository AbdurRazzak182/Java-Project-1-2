package files.project;

import files.project.clientT.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

public class TeacherRoutineController implements Initializable {
    TeacherConnection conn;
    public void setConn(TeacherConnection conn){
        this.conn=conn;
    }

    private Stage stage;

    public void setStage(Stage stage) { this.stage = stage; }
    public Stage getStage() { return stage; }

    // Static teacher object to receive data from LoginController
    private clientT_teacher teacher;
    private int totalClass=0,totalLab=0,totalExam=0;

    @FXML
    private Label teacherIdLabel;
    @FXML
    private Button exitBtn;

    @FXML
    private Label totalClasses;

    @FXML
    private Label Exam;

    @FXML
    private Label labSessions;

    @FXML
    private Label universityNameLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label deptLabel;

    @FXML
    private Button viewScheduleBtn;

    @FXML
    private Button examScheduleBtn;

    @FXML
    private ScrollPane routineScrollPane;

    @FXML
    private GridPane routineTable;

    // Time slots from 8 AM to 5 PM
    private final String[] timeSlots = {
            "8 AM", "9 AM", "10 AM", "11 AM", "12 PM",
            "1 PM", "2 PM", "3 PM", "4 PM", "5 PM"
    };

    private final int[] timeHours = {8, 9, 10, 11, 12, 13, 14, 15, 16, 17};

    public void initTeacher(clientT_teacher teacherData) {
        this.teacher = teacherData;
        countSchedule(); // counting lab,exam,classes
        loadTeacherData();
        createRoutineTable();

        conn.setUiUpdateCallback(() -> Platform.runLater(() -> {
            countSchedule();// coutning lab,exam,classes
            createRoutineTable();
        }));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupUI();
        loadTeacherData();
        createRoutineTable();
    }


    private void setupUI() {
        universityNameLabel.setText("Bangladesh University Engineering and Technology");
        universityNameLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: white;");

        // Setup button actions
        examScheduleBtn.setOnAction(e -> handleExamSchedule());
    }


    private void loadTeacherData() {
        if (teacher != null) {
            nameLabel.setText(teacher.getName());
            deptLabel.setText(teacher.getDeptName());
            teacherIdLabel.setText(teacher.getID());
            Exam.setText(""+totalExam);
            labSessions.setText(""+totalLab);
            totalClasses.setText(""+totalClass);
        } else {
            // Default data for testing
            nameLabel.setText("Dr. Jane Smith");
            deptLabel.setText("Computer Science & Engineering");

            Exam.setText(""+totalExam);
            labSessions.setText(""+totalLab);
            totalClasses.setText(""+totalClass);
        }
    }


    private void createRoutineTable() {
        routineTable.getChildren().clear();

        // Create header row
        createHeaderRow();

        // Create data rows
        if (teacher != null && teacher.getDates() != null) {
            createDataRows(teacher.getDates());
        } else {
            // Create sample data for testing
            createSampleDataRows();
        }
    }

    // counting total exam,total class
    public void countSchedule(){
        for(clientT_date date: teacher.getDates()){
            for(clientT_schedule sch:date.getSchedules()){
                if(sch.getLocation().contains("Lab") | sch.getLocation().contains("lab")){
                    totalLab++;
                }else{
                    totalClass++;
                }
            }
            for(clientT_examSchedule exc:date.getExamSchedules()){
                totalExam++;
            }
        }
    }


    private void createHeaderRow() {
        // Date & Day header
        Label dateHeader = new Label("Date & Day");
        dateHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
        dateHeader.setAlignment(Pos.CENTER);
        dateHeader.setPrefWidth(120);
        dateHeader.setPrefHeight(40);
        dateHeader.setStyle(dateHeader.getStyle() + "-fx-background-color: #f0f0f0; -fx-border-color: #ccc; -fx-border-width: 1px;");

        routineTable.add(dateHeader, 0, 0);

        // Time slot headers
        for (int i = 0; i < timeSlots.length; i++) {
            Label timeHeader = new Label(timeSlots[i]);
            timeHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: #333;");
            timeHeader.setAlignment(Pos.CENTER);
            timeHeader.setPrefWidth(80);
            timeHeader.setPrefHeight(40);
            timeHeader.setStyle(timeHeader.getStyle() + "-fx-background-color: #ffebee; -fx-border-color: #ccc; -fx-border-width: 1px;");

            routineTable.add(timeHeader, i + 1, 0);
        }
    }


    private void createDataRows(List<clientT_date> dateEntries) {
        int rowIndex = 1;

        for (clientT_date dateEntry : dateEntries) {
            // Date and day column
            VBox dateBox = createDateColumn(dateEntry.getDate());
            routineTable.add(dateBox, 0, rowIndex);

            // Time slot columns
            for (int timeIndex = 0; timeIndex < timeHours.length; timeIndex++) {
                int currentHour = timeHours[timeIndex];
                Pane scheduleCell = createScheduleCell(dateEntry, currentHour);
                routineTable.add(scheduleCell, timeIndex + 1, rowIndex);
            }

            rowIndex++;
        }
    }


    private void createSampleDataRows() {
        String[] sampleDates = {"2025-07-14", "2025-07-15", "2025-07-16"};

        for (int i = 0; i < sampleDates.length; i++) {
            VBox dateBox = createDateColumn(sampleDates[i]);
            routineTable.add(dateBox, 0, i + 1);

            // Create some sample schedule cells
            for (int timeIndex = 0; timeIndex < timeHours.length; timeIndex++) {
                Pane cell = new Pane();
                cell.setPrefWidth(80);
                cell.setPrefHeight(50);
                cell.setStyle("-fx-background-color: white; -fx-border-color: #ccc; -fx-border-width: 1px;");

                // Add sample data
                if (i == 0 && timeIndex == 0) { // 8 AM on first day
                    createSampleScheduleCell(cell, "CSE105", "Room-306", true, false);
                } else if (i == 0 && timeIndex >= 6 && timeIndex <= 8) { // 2 PM to 4 PM on first day
                    createSampleScheduleCell(cell, "CSE114", "UCL-lab", true, true);
                }

                routineTable.add(cell, timeIndex + 1, i + 1);
            }
        }
    }


    private VBox createDateColumn(String dateString) {
        VBox dateBox = new VBox();
        dateBox.setAlignment(Pos.CENTER);
        dateBox.setPrefWidth(120);
        dateBox.setPrefHeight(50);
        dateBox.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #ccc; -fx-border-width: 1px;");

        try {
            LocalDate date = LocalDate.parse(dateString);

            Label dayLabel = new Label(date.getDayOfWeek().toString());
            dayLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");

            Label dateLabel = new Label(date.format(DateTimeFormatter.ofPattern("MMM, dd, yyyy")));
            dateLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #666;");

            dateBox.getChildren().addAll(dayLabel, dateLabel);
        } catch (Exception e) {
            Label errorLabel = new Label("Invalid Date");
            dateBox.getChildren().add(errorLabel);
        }

        return dateBox;
    }


    private Pane createScheduleCell(clientT_date dateEntry, int hour) {
        Pane cell = new Pane();
        cell.setPrefWidth(80);
        cell.setPrefHeight(50);

        // Check for regular schedule
        clientT_schedule schedule = findScheduleForHour(dateEntry.getSchedules(), hour);
        if (schedule != null) {
          //  System.out.println("getLocation: "+schedule.getLocation().contains("lab"));
            createScheduleContent(cell, schedule.getCourse().getCourseCode(),
                    schedule.getLocation(), schedule.status(), schedule.getLocation().contains("Lab")|schedule.getLocation().contains("lab"));
            return cell;
        }

        // Empty cell
        cell.setStyle("-fx-background-color: white; -fx-border-color: #ccc; -fx-border-width: 1px;");
        return cell;
    }

    /**
     * Find schedule that includes the given hour
     */
    private clientT_schedule findScheduleForHour(List<clientT_schedule> schedules, int hour) {
        if (schedules == null) return null;

        for (clientT_schedule schedule : schedules) {
            try {
                int startHour = Integer.parseInt(schedule.getStartTime().split(":")[0]);
                int endHour = Integer.parseInt(schedule.getEndTime().split(":")[0]);
               // System.out.println(schedule.getCourse().getCourseCode()+": "+startHour+", "+endHour+", "+hour);
                if (hour >= startHour && hour < endHour) {
                    //System.out.println("found");
                    return schedule;
                }
            } catch (Exception e) {
                // Handle parsing errors
            }
        }
        return null;
    }



    private void createScheduleContent(Pane cell, String courseCode, String location, boolean isOpen, boolean isLab) {
        VBox content = new VBox();
        content.setAlignment(Pos.CENTER);
        content.setPrefWidth(80);
        content.setPrefHeight(50);

        // Set background color based on status and type
        String backgroundColor;
        if (isLab) {
            backgroundColor = isOpen ? "#9c27b0" : "#f44336"; // Purple for lab, red if cancelled
        } else {
            backgroundColor = isOpen ? "#4caf50" : "#f44336"; // Green for class, red if cancelled
        }

        content.setStyle("-fx-background-color: " + backgroundColor + "; -fx-border-color: #ccc; -fx-border-width: 1px;");

        Label courseLabel = new Label(courseCode);
        courseLabel.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 10px;");

        Label locationLabel = new Label(location);
        locationLabel.setStyle("-fx-text-fill: white; -fx-font-size: 8px;");

        content.getChildren().addAll(courseLabel, locationLabel);

        if (isLab) {
            Label labLabel = new Label("LAB");
            labLabel.setStyle("-fx-text-fill: yellow; -fx-font-weight: bold; -fx-font-size: 8px;");
            content.getChildren().add(labLabel);
        }

        cell.getChildren().add(content);
    }


    private void createSampleScheduleCell(Pane cell, String courseCode, String location, boolean isOpen, boolean isLab) {
        createScheduleContent(cell, courseCode, location, isOpen, isLab);
    }


    private void handleViewSchedule() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("View Schedule");
        alert.setHeaderText("Full Schedule View");
        alert.setContentText("This feature will show detailed schedule information.");
        alert.showAndWait();
    }


    private void handleExamSchedule() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TeacherExamRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            TeacherExamRoutineController controller = loader.getController();
            controller.setConn(conn);
            controller.setStage(stage);
            controller.initTeacher(teacher);

            stage.setTitle("Teacher Exam Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Fallback alert if FXML file doesn't exist
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Exam Schedule");
            alert.setHeaderText("Examination Schedule");
            alert.setContentText("This feature will show upcoming examinations.");
            alert.showAndWait();
        }
    }


    public void refreshRoutineTable() {
        createRoutineTable();
    }

    @FXML
    private void handleExit() {
        // Create a confirmation dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Application");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("This will close the Teacher Routine Management System.");

        // Customize the buttons
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

        // Show the dialog and wait for user response
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.YES) {
            conn.running=false;
            conn.close();
            // Close the application
            Platform.exit();
            System.exit(0);
        }
    }
}