package files.project;

import files.project.Structure.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.util.List;

public class ManageCRController {

    private Stage stage;
    private Authority author;
    private List<CR> crList;
    private final ObservableList<String> crNames = FXCollections.observableArrayList();

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }

    @FXML private TextField levelField;
    @FXML private TextField termField;
    @FXML private TextField nameField;
    @FXML private TextField idField;
    @FXML private PasswordField passwordField;
    @FXML private TextField deptField;
    @FXML private TextArea crDisplayArea;
    @FXML private Label statusLabel;
    @FXML private Button addCRBtn;
    @FXML private Button deleteCRBtn;
    @FXML private Button viewCRBtn;
    @FXML private Button backBtn;
    @FXML private ListView<String> crListView;

    // Called when scene is initialized with authority object
    public void initialization(Authority author) {
        this.author = author;
        this.crList = author.getCrList();
        updateCRListView();
    }

    @FXML
    private void handleAddCR() {
        try {
            if (!validateCRInput()) return;

            String level = levelField.getText().trim();
            String term = termField.getText().trim();
            String name = nameField.getText().trim();
            String studentId = idField.getText().trim();
            String password = passwordField.getText().trim();
            String deptName = deptField.getText().trim();

            if (crExistsForLevelTerm(level, term, studentId)) {
                showError("A CR already exists for Level " + level + ", Term " + term + "!");
                return;
            }

            CR cr = new CR(name, studentId, password, deptName, Integer.parseInt(level), Integer.parseInt(term));
            crList.add(cr);
            author.getTerm().addCR(cr);

            showSuccess("✅ CR '" + name + "' added successfully!");
            clearFormFields();
            updateCRListView(); // Update ListView

        } catch (Exception e) {
            showError("Error adding CR: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteCR() {
        try {
            String studentId = idField.getText().trim();
            String level = levelField.getText().trim();
            String term = termField.getText().trim();

            if (studentId.isEmpty() && (level.isEmpty() || term.isEmpty())) {
                showError("Please enter Student ID OR both Level and Term to delete a CR!");
                return;
            }

            CR removedCR = deleteCR(studentId, level, term);
            CR removedFromTerm = null;

            for (CR obj : author.getTerm().getCrs()) {
                if (obj.getID().equals(studentId) && obj.getLevel() == Integer.parseInt(level)
                        && obj.getTerm() == Integer.parseInt(term)) {
                    removedFromTerm = obj;
                    author.getTerm().getCrs().remove(obj);
                    break;
                }
            }

            if (removedCR != null && removedFromTerm != null) {
                crList.remove(removedCR);
                showSuccess("✅ CR '" + removedCR.getName() + "' removed successfully!");
                clearFormFields();
                updateCRListView(); // Update ListView
            } else {
                showError("No matching CR found to delete!");
            }

        } catch (Exception e) {
            showError("Error deleting CR: " + e.getMessage());
        }
    }

    // Validates all fields before adding

    private boolean validateCRInput() {
        if (levelField.getText().trim().isEmpty()) {
            showError("Please enter academic level!");
            levelField.requestFocus();
            return false;
        }
        if (termField.getText().trim().isEmpty()) {
            showError("Please enter academic term!");
            termField.requestFocus();
            return false;
        }
        if (nameField.getText().trim().isEmpty()) {
            showError("Please enter CR name!");
            nameField.requestFocus();
            return false;
        }
        if (idField.getText().trim().isEmpty()) {
            showError("Please enter student ID!");
            idField.requestFocus();
            return false;
        }
        if (passwordField.getText().trim().isEmpty()) {
            showError("Please enter password!");
            passwordField.requestFocus();
            return false;
        }

        try {
            Integer.parseInt(levelField.getText().trim());
            Integer.parseInt(termField.getText().trim());
        } catch (NumberFormatException e) {
            showError("Level and Term must be valid numbers!");
            return false;
        }

        return true;
    }

    //checking of cr existence for a level-term

    private boolean crExistsForLevelTerm(String level, String term, String sid) {
        int lev = Integer.parseInt(level);
        int tm = Integer.parseInt(term);
        for (CR cr : crList) {
            if (lev == cr.getLevel() && tm == cr.getTerm() && sid.equals(cr.getID())) {
                return true;
            }
        }
        return false;
    }

    //deletion of CR

    private CR deleteCR(String sid, String level, String term) {
        int lev = Integer.parseInt(level);
        int tm = Integer.parseInt(term);
        for (CR cr : crList) {
            if (sid.equals(cr.getID()) && lev == cr.getLevel() && tm == cr.getTerm()) {
                return cr;
            }
        }
        return null;
    }

    //showing updated list view

    private void updateCRListView() {
        crNames.clear();
        for (CR cr : crList) {
            crNames.add(cr.getName());
        }
        crListView.setItems(crNames);
    }

    //clearing form fields

    private void clearFormFields() {
        levelField.clear();
        termField.clear();
        nameField.clear();
        idField.clear();
        passwordField.clear();
        deptField.clear();
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
    }

    private void showError(String message) {
        statusLabel.setText("❌ " + message);
        statusLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
    }

    //back to admin main page
    @FXML
    private void onBackButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Scene scene = new Scene(loader.load());

            AdminController controller = loader.getController();
            controller.setStage(stage);

            stage.setTitle("Admin Dashboard");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            showError("Error returning to admin dashboard: " + e.getMessage());
        }
    }
}
