module com.app.server {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;


    opens com.app.server to javafx.fxml;
    exports com.app.server;
    exports com.app.server.Shared;
}