package com.app.server.Shared;

import java.io.Serializable;

public class AdminInfo implements Serializable {

}
