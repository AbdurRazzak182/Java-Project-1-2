package com.app.server;

import com.app.server.Shared.AdminInfo;
import com.app.server.Shared.Login;
import com.app.server.Shared.StudentInfo;
import com.app.server.Shared.Wrapper;

public class ServerThread implements Runnable{
    Wrapper wrapper;
    ServerThread(Wrapper w){
        wrapper=w;
        new Thread(this).start();
    }
    public void run(){
        try{
            while(true){
                Object in=wrapper.read();
                if(in instanceof Login){
                    Login login=(Login)in;
                    String un=login.getName();
                    String up=login.getPassword();
                    if(un.equals("abc") && up.equals("123")){
                        wrapper.write(new StudentInfo());

                    }
                    else{
                        wrapper.write(new AdminInfo());
                    }
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
