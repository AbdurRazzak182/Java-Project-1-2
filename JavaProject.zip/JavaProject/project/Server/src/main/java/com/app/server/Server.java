package com.app.server;

import com.app.server.Shared.Wrapper;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try{
            ServerSocket serverSocket=new ServerSocket(12345);
            while(true){
                Socket socket=serverSocket.accept();
                Wrapper wrapper=new Wrapper(socket);
                new ServerThread(wrapper);
                
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
