package com.app.routinemanagementsystem;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseCode;
    private String courseName;
    private Teacher instructor;
    private List<Student> enrolledStudents;
    private int level,term;


    public Course() { }

    public Course(String courseCode, String courseName) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.instructor = null;
        this.level=-1;
        this.term=-1;
        enrolledStudents=new ArrayList<>();
    }
    public Course(String courseCode, String courseName, Teacher instructor) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.instructor = instructor;
        this.level=-1;
        this.term=-1;
        enrolledStudents=new ArrayList<>();
    }
    public Course(String courseCode, String courseName, int level,int term) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.instructor = null;
        this.level=level;
        this.term=term;
        enrolledStudents=new ArrayList<>();
    }
    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Teacher getInstructor() {
        if(instructor == null) {
            return null;
        }
        return instructor;
    }

    public void setInstructor(Teacher instructor) {
        this.instructor = instructor;
    }

    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public void setEnrolledStudents(List<Student> enrolledStudents) {
        this.enrolledStudents = enrolledStudents;
    }

    public boolean addStudent(Student student) {
        if (student != null && !enrolledStudents.contains(student)) {
            enrolledStudents.add(student);
            return true;
        }
        return false;
    }
    public boolean removeStudent(Student student){
        if(student!=null && enrolledStudents.contains(student)){
            enrolledStudents.remove(student);
            return true;
        }
        return false;
    }
    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }
    public int getTerm() {
        return term;
    }
    public void setTerm(int term) {
        this.term = term;
    }
}
