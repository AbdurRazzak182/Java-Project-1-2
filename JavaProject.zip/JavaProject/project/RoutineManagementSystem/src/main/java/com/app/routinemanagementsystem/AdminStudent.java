package com.app.routinemanagementsystem;

public class AdminStudent {
}
