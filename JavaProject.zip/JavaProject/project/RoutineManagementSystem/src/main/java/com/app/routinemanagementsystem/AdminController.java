package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class AdminController {
    private Stage stage;

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void onCreateRoutineButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("CreateRoutine.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  703,574);

        CreateRoutineController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Homepage");
        stage.setScene(scene);
        stage.show();
    }

    public void onManageTeacherButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AdminTeacher.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  703,574);

        AdminTeacherController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Admin teacher page");
        stage.setScene(scene);
        stage.show();
    }

    public void onManageCRButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ManageCR.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  703,574);

        ManageCRController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Homepage");
        stage.setScene(scene);
        stage.show();
    }

    public void onManageStudentButton(ActionEvent actionEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AdminStudent.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  703,574);

        AdminStudentController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Homepage");
        stage.setScene(scene);
        stage.show();
    }
}