package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminTeacherController {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private TextField teacherIdField;

    @FXML
    private TextField courseNameField;

    @FXML
    private Label statusLabel;

    // This should be replaced with your actual teacher lookup (list, map, or DB)
    private Teacher currentTeacher;

    /**
     * Set the current teacher object to manage courses for.
     * You should call this method from outside after loading the controller,
     * passing the teacher you want to manage.
     */
    public void setCurrentTeacher(Teacher teacher) {
        this.currentTeacher = teacher;
    }

    @FXML
    private void handleAddCourse() {
        String id = teacherIdField.getText().trim();
        String courseName = courseNameField.getText().trim();

        if (id.isEmpty() || courseName.isEmpty()) {
            statusLabel.setText("Please enter both Teacher ID and Course Name.");
            return;
        }

        if (currentTeacher == null || !currentTeacher.getID().equals(id)) {
            statusLabel.setText("Teacher ID not found.");
            return;
        }

        // Create course with only courseName for now (courseCode can be added similarly)
        Course newCourse = new Course();
        newCourse.setCourseName(courseName);

        boolean added = currentTeacher.addCourse(newCourse);
        if (added) {
            statusLabel.setText("Course '" + courseName + "' added.");
        } else {
            statusLabel.setText("Course already assigned.");
        }
    }

    @FXML
    private void handleRemoveCourse() {
        String id = teacherIdField.getText().trim();
        String courseName = courseNameField.getText().trim();

        if (id.isEmpty() || courseName.isEmpty()) {
            statusLabel.setText("Please enter both Teacher ID and Course Name.");
            return;
        }

        if (currentTeacher == null || !currentTeacher.getID().equals(id)) {
            statusLabel.setText("Teacher ID not found.");
            return;
        }

        Course toRemove = null;
        for (Course c : currentTeacher.getAssignedCourses()) {
            if (c.getCourseName().equalsIgnoreCase(courseName)) {
                toRemove = c;
                break;
            }
        }

        if (toRemove != null && currentTeacher.removeCourse(toRemove)) {
            statusLabel.setText("Course '" + courseName + "' removed.");
        } else {
            statusLabel.setText("Course not found.");
        }
    }

    public void onBackButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Admin.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 730, 462);

        AdminController controller = fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Admin page");
        stage.setScene(scene);
        stage.show();
    }
}
