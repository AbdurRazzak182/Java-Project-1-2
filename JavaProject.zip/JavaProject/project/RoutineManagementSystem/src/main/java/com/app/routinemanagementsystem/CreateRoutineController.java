package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CreateRoutineController {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML private TextField levelField, termField, dayField;
    @FXML private TextField nineTen, tenEleven, elevenTwelve, twelveOne, oneTwo, twoThree, threeFour, fourFive;
    @FXML private Label statusLabel;

    @FXML
    private void handleSaveRoutine() {

        String level = levelField.getText().trim();
        String term = termField.getText().trim();
        String day = dayField.getText().trim();

        if (level.isEmpty() || term.isEmpty() || day.isEmpty()) {
            statusLabel.setText("Level, Term, and Day are required.");
            return;
        }

        String filename = "routine_L" + level + "T" + term + ".txt";

        StringBuilder routineLine = new StringBuilder();
        routineLine.append(day).append(",");
        routineLine.append(nineTen.getText()).append(",");
        routineLine.append(tenEleven.getText()).append(",");
        routineLine.append(elevenTwelve.getText()).append(",");
        routineLine.append(twelveOne.getText()).append(",");
        routineLine.append(oneTwo.getText()).append(",");
        routineLine.append(twoThree.getText()).append(",");
        routineLine.append(threeFour.getText()).append(",");
        routineLine.append(fourFive.getText());

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(routineLine.toString());
            writer.newLine();
            statusLabel.setText("Routine saved successfully.");
            clearFields();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error saving routine.");
        }
    }

    private void clearFields() {
        dayField.clear();
        nineTen.clear(); tenEleven.clear(); elevenTwelve.clear(); twelveOne.clear();
        oneTwo.clear(); twoThree.clear(); threeFour.clear(); fourFive.clear();
    }

    public void onBackButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Admin.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 730, 462);

        AdminController controller = fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Admin page");
        stage.setScene(scene);
        stage.show();
    }
}
