package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;

import java.io.IOException;

public class CRUpdateExamController {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private Button onSaveButton;

    @FXML
    private TableColumn<?, ?> roomNo;

    @FXML
    private TableColumn<?, ?> subject;

    @FXML
    private TableColumn<?, ?> syllabus;

    @FXML
    private TableColumn<?, ?> time;

    @FXML
    void onSaveButton(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("CRexam.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  903,681);

        CRExamController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("CR Exam page");
        stage.setScene(scene);
        stage.show();
    }

}
