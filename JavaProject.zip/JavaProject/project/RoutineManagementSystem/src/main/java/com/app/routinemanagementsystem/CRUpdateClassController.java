package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;

import java.io.IOException;

public class CRUpdateClassController {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private TableColumn<?, ?> eleven_12;

    @FXML
    private TableColumn<?, ?> four_5;

    @FXML
    private TableColumn<?, ?> nine_10;

    @FXML
    private TableColumn<?, ?> one_2;

    @FXML
    private TableColumn<?, ?> ten_11;

    @FXML
    private TableColumn<?, ?> three_4;

    @FXML
    private TableColumn<?, ?> tweleve_1;

    @FXML
    private TableColumn<?, ?> two_3;

    @FXML
    void onSaveButton(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("CR.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  903,681);

        CRClassRoutineController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("CR page");
        stage.setScene(scene);
        stage.show();
    }

}
