package com.app.routinemanagementsystem;

public class TableStudentClass {
    private String day;
    private String nineTen;
    private String tenEleven;
    private String elevenTwelve;
    private String twelveOne;
    private String oneTwo;
    private String twoThree;
    private String threeFour;
    private String fourFive;

    // Constructor
    public TableStudentClass(String day, String nineTen, String tenEleven, String elevenTwelve,
                      String twelveOne, String oneTwo, String twoThree, String threeFour, String fourFive) {
        this.day = day;
        this.nineTen = nineTen;
        this.tenEleven = tenEleven;
        this.elevenTwelve = elevenTwelve;
        this.twelveOne = twelveOne;
        this.oneTwo = oneTwo;
        this.twoThree = twoThree;
        this.threeFour = threeFour;
        this.fourFive = fourFive;
    }

    // Getters
    public String getDay() { return day; }
    public String getNineTen() { return nineTen; }
    public String getTenEleven() { return tenEleven; }
    public String getElevenTwelve() { return elevenTwelve; }
    public String getTwelveOne() { return twelveOne; }
    public String getOneTwo() { return oneTwo; }
    public String getTwoThree() { return twoThree; }
    public String getThreeFour() { return threeFour; }
    public String getFourFive() { return fourFive; }
}

