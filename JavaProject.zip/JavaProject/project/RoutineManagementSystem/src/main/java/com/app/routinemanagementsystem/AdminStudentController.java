package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminStudentController {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML private TextField nameField;
    @FXML private TextField idField;
    @FXML private TextField passwordField;
    @FXML private TextField deptField;
    @FXML private TextField levelField;
    @FXML private TextField termField;

    @FXML
    private void handleAddStudent() {
        try {
            String name = nameField.getText();
            String id = idField.getText();
            String password = passwordField.getText();
            String dept = deptField.getText();
            int level = Integer.parseInt(levelField.getText());
            int term = Integer.parseInt(termField.getText());

            Student student = new Student(name, id, password, dept, level, term);
            System.out.println("✅ Added Student: " + student.getName() + " (" + student.getId() + ")");
            // TODO: save student to file or list
        } catch (Exception e) {
            System.out.println("❌ Error adding student: " + e.getMessage());
        }
    }

    @FXML
    private void handleRemoveStudent() {
        String id = idField.getText();
        System.out.println("🗑️ Removed student with ID: " + id);
        // TODO: remove logic from file or list
    }

    public void onBackButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Admin.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 730, 462);

        AdminController controller = fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Admin page");
        stage.setScene(scene);
        stage.show();
    }
}
