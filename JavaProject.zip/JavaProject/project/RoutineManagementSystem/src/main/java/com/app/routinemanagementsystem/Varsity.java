package com.app.routinemanagementsystem;
import java.util.List;
import java.util.ArrayList;
public class Varsity {
    private String name;
    private List<Department> departments;

    //default constructor
    public Varsity(){

    }

    public Varsity(String name) {
        this.name=name;
        departments= new ArrayList<>();
    }

    // Constructor with parameters
    public Varsity(String name, List<Department> departments) {
        this.name = name;
        this.departments = departments;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for departments
    public List<Department> getDepartments() {
        return departments;
    }

    // Setter for departments
    public void setDepartments(List<Department> departments) {
        this.departments = departments;
    }

    // ✅ Add a single department
    public void addDepartment(Department department) {
        if (department != null) {
            departments.add(department);
        }
    }
}
