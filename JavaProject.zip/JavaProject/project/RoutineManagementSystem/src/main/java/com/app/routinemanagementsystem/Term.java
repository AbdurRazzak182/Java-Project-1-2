package com.app.routinemanagementsystem;
import java.util.List;
import java.util.ArrayList;
public class Term {
    private List<Course> courses;
    private List<Student> students;
    private List<CR> crs;
    private List<Date> dates;

    public Term(){
        courses=new ArrayList<>();
        students=new ArrayList<>();
        crs=new ArrayList<>();
        dates=new ArrayList<>();
    }

    public List<Student> getStudents(){
        return students;
    }
    public void addCourse(Course course){
        if(course!=null){
            courses.add(course);
        }
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public void addStudent(Student student){
        if(student!=null){
            students.add(student);
        }
    }
    public void addCR(CR cr){
        if(cr!=null){
            crs.add(cr);
        }
    }
    public List<CR> getCrs() {
        return crs;
    }
    public void removeCR(CR cr){
        if(cr!=null){
            crs.remove(cr);
        }
    }
    public List<Date> getDates(){
        return dates;
    }
    public void addDate(Date date){
        if(date!=null){
            dates.add(date);
        }
    }
    public void removeDate(Date date){
        if(date!=null){
            dates.remove(date);
        }
    }

    public boolean removeStudent(Student student){
        if(student!=null && students.contains(student)){
            students.remove(student);
            return true;
        }
        return false;
    }
    public boolean removeCourse(Course course){
        if(course!=null && courses.contains(course)){
            courses.remove(course);
            return true;
        }
        return false;
    }
}
