module com.app.routinemanagementsystem {
    requires javafx.controls;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires java.sql; requires com.app.server;

    opens com.app.routinemanagementsystem to javafx.fxml;
    exports com.app.routinemanagementsystem;
//    exports com.app.routinemanagementsystem;
//    opens com.app.routinemanagementsystem to javafx.fxml;
}