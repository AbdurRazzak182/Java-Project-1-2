package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

public class TeacherRoutineController {

    @FXML
    private Label dateLabel;

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private Label deptName;

    @FXML
    private TableColumn<?, ?> eleven_12;

    @FXML
    private TableColumn<?, ?> four_5;

    @FXML
    private TableColumn<?, ?> nine_ten;

    @FXML
    private TableColumn<?, ?> one_2;

    @FXML
    private Label setVarsityName;

    @FXML
    private Label statusName;

    @FXML
    private Label teacherName;

    @FXML
    private TableColumn<?, ?> ten_11;

    @FXML
    private TableColumn<?, ?> three_4;

    @FXML
    private TableColumn<?, ?> twelve_1;

    @FXML
    private TableColumn<?, ?> two_3;

    @FXML
    void onClassRoutineButton(ActionEvent event) {

    }

    @FXML
    void onExamRoutineButton(ActionEvent event) {

    }

}
