package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

public class TeacherExamController {

    @FXML
    private Label dateLabel;

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private TableColumn<?, ?> dept;

    @FXML
    private Label deptName;

    @FXML
    private TableColumn<?, ?> level;

    @FXML
    private TableColumn<?, ?> roomNo;

    @FXML
    private Label setVarsityName;

    @FXML
    private Label statusName;

    @FXML
    private TableColumn<?, ?> syllabus;

    @FXML
    private Label teacherName;

    @FXML
    private TableColumn<?, ?> term;

    @FXML
    private TableColumn<?, ?> time;

    @FXML
    void onClassRoutineButton(ActionEvent event) {

    }

    @FXML
    void onExamRoutineButton(ActionEvent event) {

    }

}