package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

public class CRExamController {

    @FXML
    private Label dateLabel;

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private Label level;

    @FXML
    private TableColumn<?, ?> roomNo;

    @FXML
    private Label sId;

    @FXML
    private Label setVarsityName;

    @FXML
    private Label studentName;

    @FXML
    private TableColumn<?, ?> subject;

    @FXML
    private TableColumn<?, ?> syllabus;

    @FXML
    private Label term;

    @FXML
    private TableColumn<?, ?> time;

    @FXML
    void onClassRoutineButton(ActionEvent event) {

    }

    @FXML
    void onExamRoutineButton(ActionEvent event) {

    }

    @FXML
    void onExamUpdateButton(ActionEvent event) {

    }

}