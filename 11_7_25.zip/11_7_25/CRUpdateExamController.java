package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;

public class CRUpdateExamController {

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private Button onSaveButton;

    @FXML
    private TableColumn<?, ?> roomNo;

    @FXML
    private TableColumn<?, ?> subject;

    @FXML
    private TableColumn<?, ?> syllabus;

    @FXML
    private TableColumn<?, ?> time;

    @FXML
    void onSaveButton(ActionEvent event) {

    }

}
