package com.app.routinemanagementsystem;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

public class StudentRoutineController implements Initializable {

    private Stage stage;

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML private TableColumn<TableStudentClass, String> day;
    @FXML private TableColumn<TableStudentClass, String> nine_ten;
    @FXML private TableColumn<TableStudentClass, String> ten_11;
    @FXML private TableColumn<TableStudentClass, String> eleven_12;
    @FXML private TableColumn<TableStudentClass, String> twelve_1;
    @FXML private TableColumn<TableStudentClass, String> one_2;
    @FXML private TableColumn<TableStudentClass, String> two_3;
    @FXML private TableColumn<TableStudentClass, String> three_4;
    @FXML private TableColumn<TableStudentClass, String> four_5;

    @FXML private TableView<TableStudentClass> routineTable;

    @FXML private Label studentName;
    @FXML private Label sId;
    @FXML private Label level;
    @FXML private Label term;
    @FXML private Label setVarsityName;
    @FXML private Label dateLabel;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH);
    private LocalDate lastDate = null;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set today's date
        updateDate();
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(60), e -> checkDateUpdate())
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        // Setup table
        routineTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        // Bind table columns
        day.setCellValueFactory(new PropertyValueFactory<>("day"));
        nine_ten.setCellValueFactory(new PropertyValueFactory<>("nineTen"));
        ten_11.setCellValueFactory(new PropertyValueFactory<>("tenEleven"));
        eleven_12.setCellValueFactory(new PropertyValueFactory<>("elevenTwelve"));
        twelve_1.setCellValueFactory(new PropertyValueFactory<>("twelveOne"));
        one_2.setCellValueFactory(new PropertyValueFactory<>("oneTwo"));
        two_3.setCellValueFactory(new PropertyValueFactory<>("twoThree"));
        three_4.setCellValueFactory(new PropertyValueFactory<>("threeFour"));
        four_5.setCellValueFactory(new PropertyValueFactory<>("fourFive"));

        // Load routine from file
        loadRoutine();
    }

    private void updateDate() {
        lastDate = LocalDate.now();
        dateLabel.setText(lastDate.format(formatter));
    }

    private void checkDateUpdate() {
        LocalDate currentDate = LocalDate.now();
        if (!currentDate.equals(lastDate)) {
            updateDate();
        }
    }

    private void loadRoutine() {
        try (InputStream input = getClass().getResourceAsStream("/com/app/routinemanagementsystem/classRoutine.txt");
             BufferedReader reader = new BufferedReader(new InputStreamReader(input))) {

            ObservableList<TableStudentClass> routineData = FXCollections.observableArrayList();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] tokens = line.trim().split("\\s+");
                if (tokens.length >= 9) {
                    routineData.add(new TableStudentClass(
                            tokens[0], tokens[1], tokens[2], tokens[3],
                            tokens[4], tokens[5], tokens[6], tokens[7], tokens[8]
                    ));
                }
            }

            routineTable.setItems(routineData);

        } catch (IOException | NullPointerException e) {
            System.err.println("Error loading classRoutine.txt");
            e.printStackTrace();
        }
    }

    // This method can be used to populate profile info dynamically from another class
    public void setStudentProfile(String name, String id, String levelStr, String termStr) {
        studentName.setText(name);
        sId.setText(id);
        level.setText(levelStr);
        term.setText(termStr);
    }

    @FXML
    void onClassRoutineButton(ActionEvent event) {
        // You can add logic here if switching to a class routine view
    }

    @FXML
    void onExamRoutineButton(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("StudentExam.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 903, 681);

            StudentExamController controller = fxmlLoader.getController();
            controller.setStage(stage);

            stage.setTitle("Student Exam Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
