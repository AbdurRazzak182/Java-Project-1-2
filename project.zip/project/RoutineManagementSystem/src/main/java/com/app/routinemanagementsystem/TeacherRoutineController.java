package com.app.routinemanagementsystem;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

public class TeacherRoutineController implements Initializable {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private Label dateLabel;
    private final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH);

    private LocalDate lastDate = null;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateDate(); // Set initial date

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(60), e -> checkDateUpdate()) // check every 60 sec
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void updateDate() {
        lastDate = LocalDate.now();
        dateLabel.setText(lastDate.format(formatter));
    }

    private void checkDateUpdate() {
        LocalDate currentDate = LocalDate.now();
        if (!currentDate.equals(lastDate)) {
            updateDate(); // date changed, update label
        }
    }

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private Label deptName;

    @FXML
    private TableColumn<?, ?> eleven_12;

    @FXML
    private TableColumn<?, ?> four_5;

    @FXML
    private TableColumn<?, ?> nine_ten;

    @FXML
    private TableColumn<?, ?> one_2;

    @FXML
    private Label setVarsityName;

    @FXML
    private Label statusName;

    @FXML
    private Label teacherName;

    @FXML
    private TableColumn<?, ?> ten_11;

    @FXML
    private TableColumn<?, ?> three_4;

    @FXML
    private TableColumn<?, ?> twelve_1;

    @FXML
    private TableColumn<?, ?> two_3;

    @FXML
    void onClassRoutineButton(ActionEvent event) {

    }

    @FXML
    void onExamRoutineButton(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("TeacherExam.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  903,681);

        TeacherExamController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Teacher Exam Routine");
        stage.setScene(scene);
        stage.show();
    }

}
