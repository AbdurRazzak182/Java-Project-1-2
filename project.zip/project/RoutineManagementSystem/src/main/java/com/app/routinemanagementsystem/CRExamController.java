package com.app.routinemanagementsystem;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

public class CRExamController implements Initializable {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private Label dateLabel;
    private final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH);

    private LocalDate lastDate = null;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateDate(); // Set initial date

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(60), e -> checkDateUpdate()) // check every 60 sec
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void updateDate() {
        lastDate = LocalDate.now();
        dateLabel.setText(lastDate.format(formatter));
    }

    private void checkDateUpdate() {
        LocalDate currentDate = LocalDate.now();
        if (!currentDate.equals(lastDate)) {
            updateDate(); // date changed, update label
        }
    }

    @FXML
    private TableColumn<?, ?> day;

    @FXML
    private Label level;

    @FXML
    private TableColumn<?, ?> roomNo;

    @FXML
    private Label sId;

    @FXML
    private Label setVarsityName;

    @FXML
    private Label studentName;

    @FXML
    private TableColumn<?, ?> subject;

    @FXML
    private TableColumn<?, ?> syllabus;

    @FXML
    private Label term;

    @FXML
    private TableColumn<?, ?> time;

    @FXML
    void onClassRoutineButton(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("CR.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  903,681);

        CRClassRoutineController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("CR page");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void onExamRoutineButton(ActionEvent event) {

    }

    @FXML
    void onExamUpdateButton(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("CRUpdateExam.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),  903,681);

        CRUpdateExamController controller=fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("CR Update Exam Page");
        stage.setScene(scene);
        stage.show();
    }

}