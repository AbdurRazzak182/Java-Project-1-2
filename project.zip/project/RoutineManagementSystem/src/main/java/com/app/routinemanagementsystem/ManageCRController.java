package com.app.routinemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ManageCRController {
    private Stage stage;

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private TextField levelField;

    @FXML
    private TextField termField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField idField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextArea crDisplayArea;

    @FXML
    private Label statusLabel;

    public void onBackButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Admin.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 730, 462);

        AdminController controller = fxmlLoader.getController();
        controller.setStage(stage);

        stage.setTitle("Admin page");
        stage.setScene(scene);
        stage.show();
    }

    // Internal class to hold CR info
    private static class CR {
        String level;
        String term;
        String name;
        String id;
        String password;

        CR(String level, String term, String name, String id, String password) {
            this.level = level;
            this.term = term;
            this.name = name;
            this.id = id;
            this.password = password;
        }

        @Override
        public String toString() {
            return String.format("Level: %s, Term: %s, Name: %s, ID: %s", level, term, name, id);
        }
    }

    // In-memory list to simulate database
    private final List<CR> crList = new ArrayList<>();

    @FXML
    private void handleAddCR() {
        String level = levelField.getText();
        String term = termField.getText();
        String name = nameField.getText();
        String id = idField.getText();
        String password = passwordField.getText();

        if (level.isEmpty() || term.isEmpty() || name.isEmpty() || id.isEmpty() || password.isEmpty()) {
            statusLabel.setText("All fields are required.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        CR newCR = new CR(level, term, name, id, password);
        crList.add(newCR);
        statusLabel.setText("CR added successfully.");
        statusLabel.setStyle("-fx-text-fill: green;");
        clearFields();
    }

    @FXML
    private void handleDeleteCR() {
        String id = idField.getText();

        if (id.isEmpty()) {
            statusLabel.setText("Enter CR ID to delete.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        boolean found = false;
        Iterator<CR> iterator = crList.iterator();
        while (iterator.hasNext()) {
            CR cr = iterator.next();
            if (cr.id.equals(id)) {
                iterator.remove();
                found = true;
                break;
            }
        }

        if (found) {
            statusLabel.setText("CR deleted successfully.");
            statusLabel.setStyle("-fx-text-fill: green;");
        } else {
            statusLabel.setText("CR ID not found.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }

        clearFields();
    }

    @FXML
    private void handleViewCRs() {
        StringBuilder builder = new StringBuilder();
        for (CR cr : crList) {
            builder.append(cr.toString()).append("\n");
        }

        crDisplayArea.setText(builder.toString());
        statusLabel.setText("Displaying all CRs.");
        statusLabel.setStyle("-fx-text-fill: blue;");
    }

    private void clearFields() {
        levelField.clear();
        termField.clear();
        nameField.clear();
        idField.clear();
        passwordField.clear();
    }
}
