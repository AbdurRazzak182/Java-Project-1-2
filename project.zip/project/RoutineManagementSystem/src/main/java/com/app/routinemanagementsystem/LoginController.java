package com.app.routinemanagementsystem;

import com.app.server.Shared.AdminInfo;
import com.app.server.Shared.Login;
import com.app.server.Shared.StudentInfo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;

import static com.app.routinemanagementsystem.Main.wrapper;

public class LoginController {
    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    Stage stage;

    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private Button loginButton;
    boolean val,pass_val;
    @FXML
    private Label  labelShow;

    boolean flag=true;

    

//        static Person searchMethod(String userName,String passWord){
//
//
//            return null;
//        }



         public void onLogInButtonClick(ActionEvent actionEvent)throws IOException {
                String userName = username.getText();
                String passWord = password.getText();
                Login login=new Login();
                login.setName(userName);
                login.setPassword(passWord);
                wrapper.write(login);

                Object in;
                String open="";
                try{
                    in=wrapper.read();
                    if(in instanceof StudentInfo){
                        open="student";
                    }
                    else if(in instanceof AdminInfo){
                        open="admin";
                    }
                }
                catch(Exception e){
                    e.printStackTrace();
                }


//
             Person person=new Person();

                if(open.equals("student")){
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("studentRoutine.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(),  903,681);

                    StudentRoutineController controller=fxmlLoader.getController();
                    controller.setStage(stage);

                    stage.setTitle("Student Class Routine");
                    stage.setScene(scene);
                    stage.show();
                }
                 if(person instanceof CR){
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("CR.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(),  903,681);

                    CRClassRoutineController controller=fxmlLoader.getController();
                    controller.setStage(stage);

                    stage.setTitle("CR page");
                    stage.setScene(scene);
                    stage.show();
                }
                else if(person instanceof Teacher){
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("TeacherRoutine.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(),  903,681);

                    TeacherRoutineController controller=fxmlLoader.getController();
                    controller.setStage(stage);

                    stage.setTitle("Teacher page");
                    stage.setScene(scene);
                    stage.show();
               }
               else if(open.equals("admin")) {
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Admin.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(), 730, 462);

                    AdminController controller = fxmlLoader.getController();
                    controller.setStage(stage);

                    stage.setTitle("Admin page");
                    stage.setScene(scene);
                    stage.show();
                }
               else {
                    labelShow.setText("Wrong usename or password");
                    username.clear();
                    password.clear();
                }



    }
}
