package com.app.routinemanagementsystem;

import java.util.ArrayList;
import java.util.List;

public class Date {
    public String date;
    public List<Schedule> schedules;

    public Date(String date){
        this.date=date;
        schedules=new ArrayList<>();
    }

    public String getDate(){
        return date;
    }
    public void setDate(String date){
        this.date=date;
    }
    public List<Schedule> getSchedules(){
        return schedules;
    }
    public void addSchedule(Schedule schedule){
        schedules.add(schedule);
    }

}
