package com.app.routinemanagementsystem;

import javafx.stage.Stage;

public class Test {
    Stage stage;

    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }
}
