package com.app.server.Shared;

import java.io.Serializable;

public class StudentInfo implements Serializable {

}
