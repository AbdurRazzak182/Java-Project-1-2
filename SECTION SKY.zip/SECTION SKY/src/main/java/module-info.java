module files.project {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    opens files.project to javafx.fxml;
    exports files.project;
}