package files.project;

import files.project.ClientS.*;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.application.Platform;

import java.io.IOException;

public class LoginController {
    private Stage stage;

    @FXML private TextField Id;
    @FXML private PasswordField password;
    @FXML private Button loginButton;
    @FXML private Label labelShow;

    public void setStage(Stage stage) { this.stage = stage; }
    public Stage getStage() { return stage; }

    @FXML
    public void onLogInButtonClick(ActionEvent actionEvent) {
        final String id = Id.getText().trim();
        final String passWord = password.getText().trim();

        if (id.isEmpty() || passWord.isEmpty()) {
            labelShow.setText("Please enter both ID and password.");
            labelShow.setStyle("-fx-text-fill: red;");
            return;
        }

        labelShow.setText("Logging in...");
        labelShow.setStyle("-fx-text-fill: #000dff;");

        // Run network call in background
        Task<Void> loginTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                ClientConnection conn = ClientConnection.getInstance();
                try {
                    conn.send(id + "," + passWord);
                    String response = conn.receiveString();
                    handleLoginResponse(id, response);
                } catch (IOException e) {
                    Platform.runLater(() -> {
                        labelShow.setText("Error communicating with server.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };

        new Thread(loginTask, "LoginTask").start();
    }

    /** Process server login reply on JavaFX thread */
    private void handleLoginResponse(String id, String response) {
        Platform.runLater(() -> {
            if (response == null) {
                labelShow.setText("No response from server.");
                labelShow.setStyle("-fx-text-fill: red;");
                return;
            }

            if (response.startsWith("SUCCESS")) {
                // Format: SUCCESS,ROLE
                String role = "UNKNOWN";
                int idx = response.indexOf(',');
                if (idx >= 0 && idx < response.length() - 1) {
                    role = response.substring(idx + 1);
                }


                labelShow.setText("Login successful (" + role + ")!");
                labelShow.setStyle("-fx-text-fill: green;");

                // Load next screen based on role
                if (role.equals("STUDENT")) {
                    receiveStudentAndSwitch();
                }else if(role.equals("CR")){
                    receiveCRAndSwitch();
                }else {
                    switchToRoleScene(role);
                }
            } else {
                labelShow.setText("Invalid username or password.");
                labelShow.setStyle("-fx-text-fill: red;");
                Id.clear();
                password.clear();
            }
        });
    }
    private void receiveCRAndSwitch(){
        Task<Void> receiveTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                try {
                    ClientConnection conn = ClientConnection.getInstance();
                    Object obj = conn.receiveObject();
                    if (obj instanceof clientS_stu stu) {
                        Platform.runLater(() -> switchToCRScene(stu));
                    } else {
                        Platform.runLater(() -> {
                            labelShow.setText("Unexpected data received for cr.");
                            labelShow.setStyle("-fx-text-fill: red;");
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> {
                        labelShow.setText("Error receiving cr object.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };
        new Thread(receiveTask).start();
    }
    private void receiveStudentAndSwitch() {
        Task<Void> receiveTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                try {
                    ClientConnection conn = ClientConnection.getInstance();
                    Object obj = conn.receiveObject();
                    if (obj instanceof clientS_stu stu) {
                        Platform.runLater(() -> switchToStudentScene(stu));
                    } else {
                        Platform.runLater(() -> {
                            labelShow.setText("Unexpected data received for student.");
                            labelShow.setStyle("-fx-text-fill: red;");
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> {
                        labelShow.setText("Error receiving student object.");
                        labelShow.setStyle("-fx-text-fill: red;");
                    });
                }
                return null;
            }
        };
        new Thread(receiveTask).start();
    }

    private void switchToCRScene(clientS_stu stu){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CR-Routine.fxml"));
            Scene scene = new Scene(loader.load());

            CRRoutineController controller = loader.getController();
            controller.setStage(stage);
            controller.initStudent(stu);

            stage.setTitle("Class Representative Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load Student UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }
    private void switchToStudentScene(clientS_stu stu) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("StudentRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            StudentRoutineController controller = loader.getController();
            controller.setStage(stage);
            controller.initStudent(stu);

            stage.setTitle("Student Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load Student UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }


    private void switchToRoleScene(String role) {
        String fxml;
        String title;
        switch (role) {
            case "AUTHORITY" -> {
                fxml = "/client/files/AuthorityDashboard.fxml";
                title = "Authority Dashboard";
            }
            case "TEACHER" -> {
                fxml = "/client/files/TeacherDashboard.fxml";
                title = "Teacher Dashboard";
            }
            case "CR" -> {
                fxml = "/client/files/CRDashboard.fxml";
                title = "Class Representative Dashboard";
            }
            case "STUDENT" -> {
                fxml = "hello-view.fxml";
                title = "Student Dashboard";
            }
            default -> {
                // fallback: unknown role
                labelShow.setText("Unknown role from server: " + role);
                labelShow.setStyle("-fx-text-fill: red;");
                return;
            }
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Scene scene = new Scene(loader.load());

            // Optionally pass session info to the next controller
            Object controller = loader.getController();
//            if (controller instanceof RoleAware c) {
//                c.initSession(ClientSession.getUserId(), ClientSession.getRole());
//            }

            stage.setTitle(title);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            labelShow.setText("Failed to load " + role + " UI.");
            labelShow.setStyle("-fx-text-fill: red;");
        }
    }

    /**
     * Simple interface you can have each dashboard controller implement
     * so we can pass userId+role after login.
     */
    public interface RoleAware {
        void initSession(String userId, String role);
    }
}
