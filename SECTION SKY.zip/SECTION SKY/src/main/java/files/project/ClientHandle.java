package files.project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ClientHandle extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Connect once at startup
        ClientConnection.getInstance().connect("localhost", 5000); // or server host

       // System.out.println(this.getClass());
        FXMLLoader fxmlLoader = new FXMLLoader(ClientHandle.class.getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1300, 700);

        // Give LoginController a ref to the stage (optional but handy)
        LoginController controller = fxmlLoader.getController();
        controller.setStage(stage);

        stage.setResizable(false);
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}