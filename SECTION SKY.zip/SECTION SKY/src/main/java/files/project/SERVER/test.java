package files.project.SERVER;

import java.io.*;

public class test {
    public static void main(String[] args) {
//        try {
//            // Create folder if not exists
////            File folder = new File("output");
////            if (!folder.exists()) {
////                folder.mkdirs();
////            }
//
//            // Write to file inside output/
//            File file = new File("DataBase/hello.txt");
//            BufferedWriter writer = new BufferedReader(new FileReader(file)); // append=true
//            writer.write("hello\n");
//            writer.write("Hello from Java! This is a test.");
//            writer.newLine();
//            writer.close();
//
//            System.out.println("File written to: " + file.getAbsolutePath());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        File file = new File("DataBase/ClassRoutine/CSE/Level1_Term2.txt");

        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {
                System.out.println(line); // print each line
            }

            reader.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
