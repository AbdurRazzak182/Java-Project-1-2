package files.project;

import files.project.ClientS.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
//import com.university.model.*;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class StudentRoutineController implements Initializable {
    private Stage stage;

    public void setStage(Stage stage) { this.stage = stage; }
    public Stage getStage() { return stage; }

    // Static student object to receive data from LoginController
    private clientS_stu student;
    private int totalClass=0,totalLab=0,totalExam=0;
    @FXML
    private Button exitBtn;

    @FXML
    private Label totalClasses;

    @FXML
    private Label Exam;

    @FXML
    private Label labSessions;

    @FXML
    private Label universityNameLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label idLabel;

    @FXML
    private Label deptLabel;

    @FXML
    private Label levelLabel;

    @FXML
    private Label termLabel;

    @FXML
    private Button viewScheduleBtn;

    @FXML
    private Button examScheduleBtn;

    @FXML
    private ScrollPane routineScrollPane;

    @FXML
    private GridPane routineTable;

    // Time slots from 8 AM to 5 PM
    private final String[] timeSlots = {
            "8 AM", "9 AM", "10 AM", "11 AM", "12 PM",
            "1 PM", "2 PM", "3 PM", "4 PM", "5 PM"
    };

    private final int[] timeHours = {8, 9, 10, 11, 12, 13, 14, 15, 16, 17};

    public void initStudent(clientS_stu studentData) {
        // System.out.println("it is running");
        this.student = studentData;
        countSchedule();// coutning lab,exam,classes
        loadStudentData();
        createRoutineTable();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       // System.out.println("its location");
        setupUI();
        loadStudentData();
        createRoutineTable();
    }

    /**
     * Method to initialize student data from LoginController
     */


    /**
     * Setup basic UI components
     */
    private void setupUI() {
        universityNameLabel.setText("Bangladesh University Engineering and Technology");
        universityNameLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: white;");

        // Setup button actions
       // viewScheduleBtn.setOnAction(e -> handleViewSchedule());
        examScheduleBtn.setOnAction(e -> handleExamSchedule());

    }

    /**
     * Load student data into UI components
     */
    private void loadStudentData() {
        if (student != null) {
            nameLabel.setText(student.getName());
            idLabel.setText(student.getId());
            deptLabel.setText(student.getDepartmentName());
            levelLabel.setText(student.getLevel()+"");
            termLabel.setText(student.getTerm()+"");


            Exam.setText(""+totalExam);
            labSessions.setText(""+totalLab);
            totalClasses.setText(""+totalClass);
        } else {
            // Default data for testing
            nameLabel.setText("John Doe");
            idLabel.setText("CSE-2021-001");
            deptLabel.setText("Computer Science & Engineering");
            levelLabel.setText("3rd Year");
            termLabel.setText("1st Term");

            Exam.setText(""+totalExam);
            labSessions.setText(""+totalLab);
            totalClasses.setText(""+totalClass);
        }
    }

    /**
     * Create and populate the routine table
     */
    private void createRoutineTable() {
        routineTable.getChildren().clear();

        // Create header row
        createHeaderRow();

        // Create data rows
        if (student != null && student.getDates() != null) {
            createDataRows(student.getDates());
        } else {
            // Create sample data for testing
            createSampleDataRows();
        }
    }

    // counting total exam,total class
    public void countSchedule(){
        for(clientS_date date: student.getDates()){
            for(clientS_schedule sch:date.getSchedules()){
                if(sch.getLocation().contains("Lab") | sch.getLocation().contains("lab")){
                    totalLab++;
                }else{
                    totalClass++;
                }
            }
            for(clientS_examSchedule exc:date.getExamSchedules()){
                totalExam++;
            }
        }
    }

    /**
     * Create table header with time slots
     */
    private void createHeaderRow() {
        // Date & Day header
        Label dateHeader = new Label("Date & Day");
        dateHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
        dateHeader.setAlignment(Pos.CENTER);
        dateHeader.setPrefWidth(120);
        dateHeader.setPrefHeight(40);
        dateHeader.setStyle(dateHeader.getStyle() + "-fx-background-color: #f0f0f0; -fx-border-color: #ccc; -fx-border-width: 1px;");

        routineTable.add(dateHeader, 0, 0);

        // Time slot headers
        for (int i = 0; i < timeSlots.length; i++) {
            Label timeHeader = new Label(timeSlots[i]);
            timeHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: #333;");
            timeHeader.setAlignment(Pos.CENTER);
            timeHeader.setPrefWidth(80);
            timeHeader.setPrefHeight(40);
            timeHeader.setStyle(timeHeader.getStyle() + "-fx-background-color: #e3f2fd; -fx-border-color: #ccc; -fx-border-width: 1px;");

            routineTable.add(timeHeader, i + 1, 0);
        }
    }

    /**
     * Create data rows from student's date entries
     */
    private void createDataRows(List<clientS_date> dateEntries) {
        int rowIndex = 1;

        for (clientS_date dateEntry : dateEntries) {
            // Date and day column
            VBox dateBox = createDateColumn(dateEntry.getDate());
            routineTable.add(dateBox, 0, rowIndex);

            // Time slot columns
            for (int timeIndex = 0; timeIndex < timeHours.length; timeIndex++) {
                int currentHour = timeHours[timeIndex];
                Pane scheduleCell = createScheduleCell(dateEntry, currentHour);
                routineTable.add(scheduleCell, timeIndex + 1, rowIndex);
            }

            rowIndex++;
        }
    }

    /**
     * Create sample data rows for testing
     */
    private void createSampleDataRows() {
        String[] sampleDates = {"2025-07-14", "2025-07-15", "2025-07-16"};

        for (int i = 0; i < sampleDates.length; i++) {
            VBox dateBox = createDateColumn(sampleDates[i]);
            routineTable.add(dateBox, 0, i + 1);

            // Create some sample schedule cells
            for (int timeIndex = 0; timeIndex < timeHours.length; timeIndex++) {
                Pane cell = new Pane();
                cell.setPrefWidth(80);
                cell.setPrefHeight(50);
                cell.setStyle("-fx-background-color: white; -fx-border-color: #ccc; -fx-border-width: 1px;");

                // Add sample data
                if (i == 0 && timeIndex == 0) { // 8 AM on first day
                    createSampleScheduleCell(cell, "CSE105", "Room-306", true, false);
                } else if (i == 0 && timeIndex >= 6 && timeIndex <= 8) { // 2 PM to 4 PM on first day
                    createSampleScheduleCell(cell, "CSE114", "UCL-lab", true, false);
                }

                routineTable.add(cell, timeIndex + 1, i + 1);
            }
        }
    }

    /**
     * Create date column with date and day name
     */
    private VBox createDateColumn(String dateString) {
        VBox dateBox = new VBox();
        dateBox.setAlignment(Pos.CENTER);
        dateBox.setPrefWidth(120);
        dateBox.setPrefHeight(50);
        dateBox.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #ccc; -fx-border-width: 1px;");

        try {
            LocalDate date = LocalDate.parse(dateString);

            Label dayLabel = new Label(date.getDayOfWeek().toString());
            dayLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");

            Label dateLabel = new Label(date.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")));
            dateLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #666;");

            dateBox.getChildren().addAll(dayLabel, dateLabel);
        } catch (Exception e) {
            Label errorLabel = new Label("Invalid Date");
            dateBox.getChildren().add(errorLabel);
        }

        return dateBox;
    }

    /**
     * Create schedule cell for specific time slot
     */
    private Pane createScheduleCell(clientS_date dateEntry, int hour) {
        Pane cell = new Pane();
        cell.setPrefWidth(80);
        cell.setPrefHeight(50);

        // Check for regular schedule
        clientS_schedule schedule = findScheduleForHour(dateEntry.getSchedules(), hour);
        if (schedule != null) {
            createScheduleContent(cell, schedule.getCourse().getCourseCode(),
                    schedule.getLocation(), schedule.status(), schedule.getLocation().contains("Lab")|schedule.getLocation().contains("lab"));
           // System.out.println(schedule.getCourse().getCourseCode()+": "+schedule.status());
            return cell;
        }

        // Check for exam schedule
//        clientS_examSchedule examSchedule = findExamScheduleForHour(dateEntry.getExamSchedules(), hour);
//        if (examSchedule != null) {
//            createScheduleContent(cell, examSchedule.getCourse().getCourseCode(),
//                    examSchedule.getLocation(),true, true);
//            return cell;
//        }

        // Empty cell
        cell.setStyle("-fx-background-color: white; -fx-border-color: #ccc; -fx-border-width: 1px;");
        return cell;
    }

    /**
     * Find schedule that includes the given hour
     */
    private clientS_schedule findScheduleForHour(List<clientS_schedule> schedules, int hour) {
        if (schedules == null) return null;

        for (clientS_schedule schedule : schedules) {
            try {
                int startHour = Integer.parseInt(schedule.getStartTime().split(":")[0]);
                int endHour = Integer.parseInt(schedule.getEndTime().split(":")[0]);

                if (hour >= startHour && hour < endHour) {
                    return schedule;
                }
            } catch (Exception e) {
                // Handle parsing errors
            }
        }
        return null;
    }

    /**
     * Find exam schedule that includes the given hour
     */
    private clientS_examSchedule findExamScheduleForHour(List<clientS_examSchedule> examSchedules, int hour) {
        if (examSchedules == null) return null;

        for (clientS_examSchedule examSchedule : examSchedules) {
            try {
                int startHour = Integer.parseInt(examSchedule.getStartTime().split(":")[0]);
                int endHour = Integer.parseInt(examSchedule.getEndTime().split(":")[0]);

                if (hour >= startHour && hour < endHour) {
                    return examSchedule;
                }
            } catch (Exception e) {
                // Handle parsing errors
            }
        }
        return null;
    }

    /**
     * Create content for schedule cell
     */
    //   private void createScheduleContent(Pane cell, String courseCode, String location, boolean isOpen, boolean isExam)
    private void createScheduleContent(Pane cell, String courseCode, String location, boolean isOpen, boolean isLab) {
        VBox content = new VBox();
        content.setAlignment(Pos.CENTER);
        content.setPrefWidth(80);
        content.setPrefHeight(50);

        // Set background color based on status and type
        String backgroundColor;
        if (isLab) {
            backgroundColor = isOpen ? "#9c27b0" : "#f44336"; // Purple for exam, red if cancelled
        } else {
            backgroundColor = isOpen ? "#4caf50" : "#f44336"; // Green for class, red if cancelled
        }

        content.setStyle("-fx-background-color: " + backgroundColor + "; -fx-border-color: #ccc; -fx-border-width: 1px;");

        Label courseLabel = new Label(courseCode);
        courseLabel.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 10px;");

        Label locationLabel = new Label(location);
        locationLabel.setStyle("-fx-text-fill: white; -fx-font-size: 8px;");

        content.getChildren().addAll(courseLabel, locationLabel);

        if (isLab) {
            Label labLabel = new Label("LAB");
            labLabel.setStyle("-fx-text-fill: yellow; -fx-font-weight: bold; -fx-font-size: 8px;");
            content.getChildren().add(labLabel);
        }

        cell.getChildren().add(content);
    }

    /**
     * Create sample schedule cell for testing
     */
    private void createSampleScheduleCell(Pane cell, String courseCode, String location, boolean isOpen, boolean isLab) {
        createScheduleContent(cell, courseCode, location, isOpen, isLab);
    }

    /**
     * Handle view schedule button action
     */
    private void handleViewSchedule() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("View Schedule");
        alert.setHeaderText("Full Schedule View");
        alert.setContentText("This feature will show detailed schedule information.");
        alert.showAndWait();
    }

    /**
     * Handle exam schedule button action
     */
    private void handleExamSchedule() {
//        Alert alert = new Alert(Alert.AlertType.INFORMATION);
//        alert.setTitle("Exam Schedule");
//        alert.setHeaderText("Examination Schedule");
//        alert.setContentText("This feature will show upcoming examinations.");
//        alert.showAndWait();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("StudentExamRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            StudentExamRoutineController controller = loader.getController();
            controller.setStage(stage);
            controller.initStudent(student);

            stage.setTitle("Student Exam Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Refresh the routine table (can be called when data is updated)
     */
    public void refreshRoutineTable() {
        createRoutineTable();
    }

    @FXML
    private void handleExit() {
        // Create a confirmation dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Application");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("This will close the Student Routine Management System.");

        // Customize the buttons
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

        // Show the dialog and wait for user response
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.YES) {
            ClientConnection conn = ClientConnection.getInstance();
            conn.close();
            // Close the application
            Platform.exit();
            System.exit(0);
        }
    }
}