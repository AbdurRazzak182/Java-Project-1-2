package files.project;

import files.project.ClientS.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.application.Platform;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;

public class CRExamRoutineUpdateController implements Initializable {
    private Stage stage;
    private clientS_stu student;
    private int totalExams = 0, totalMidTerms = 0, totalFinals = 0;

    // FXML Elements
    @FXML
    private Label universityNameLabel;

    @FXML
    private ChoiceBox<String> dateChooseBox;

    @FXML
    private ChoiceBox<String> courseChooseBox;

    @FXML
    private ChoiceBox<String> startTimeChooseBox;

    @FXML
    private ChoiceBox<String> endTimeChooseBox;

    @FXML
    private TextField locationField;

    @FXML
    private Button submitBtn;

    @FXML
    private Button backToRoutineBtn;

    @FXML
    private Button clearFormBtn;

    @FXML
    private Button exitBtn;

    @FXML
    private Label statusLabel;

    @FXML
    private ScrollPane examRoutineScrollPane;

    @FXML
    private GridPane examRoutineTable;

    // Time slots from 8 AM to 5 PM
    private final String[] timeSlots = {
            "8 AM", "9 AM", "10 AM", "11 AM", "12 PM",
            "1 PM", "2 PM", "3 PM", "4 PM", "5 PM"
    };

    private final int[] timeHours = {8, 9, 10, 11, 12, 13, 14, 15, 16, 17};

    // Time options for choice boxes
    private final String[] timeOptions = {
            "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
            "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"
    };

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }

    public void initStudent(clientS_stu studentData) {
        this.student = studentData;
        countExamSchedules();
        populateChoiceBoxes();
        createExamRoutineTable();
        updateStatusLabel("Ready to add exam schedule");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupUI();
        setupChoiceBoxes();
    }

    /**
     * Setup basic UI components
     */
    private void setupUI() {
        universityNameLabel.setText("Bangladesh University Engineering and Technology");
        universityNameLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: white;");

        // Setup text fields
        locationField.setPromptText("e.g., Room 301");

        // Initialize status label
        updateStatusLabel("Ready to add exam schedule");
    }

    /**
     * Setup choice boxes with default options
     */
    private void setupChoiceBoxes() {
        // Setup time choice boxes
        startTimeChooseBox.getItems().addAll(timeOptions);
        endTimeChooseBox.getItems().addAll(timeOptions);
    }

    /**
     * Populate choice boxes with student data
     */
    private void populateChoiceBoxes() {
        if (student == null) return;

        // Populate date choice box
        dateChooseBox.getItems().clear();
        if (student.getDates() != null) {
            for (clientS_date date : student.getDates()) {
                dateChooseBox.getItems().add(date.getDate());
            }
        }

        // Populate course choice box
        courseChooseBox.getItems().clear();
        if (student.getEnrolledCourses() != null) {
            for (clientS_course course : student.getEnrolledCourses()) {
                courseChooseBox.getItems().add(course.getCourseCode());
            }
        } else {
            // If no courses available, add some default ones for testing
            courseChooseBox.getItems().addAll("CSE101", "CSE102", "CSE105", "CSE114", "MAT101", "PHY101");
        }
    }

    /**
     * Count total exam schedules by type
     */
    public void countExamSchedules() {
        totalExams = 0;
        totalMidTerms = 0;
        totalFinals = 0;

        if (student == null || student.getDates() == null) return;

        for (clientS_date date : student.getDates()) {
            if (date.getExamSchedules() != null) {
                for (clientS_examSchedule exam : date.getExamSchedules()) {
                    totalExams++;
                    // Since we removed examTopic field, we'll just count all as general exams
                    // You can modify this later if you want to categorize differently
                }
            }
        }
    }

    /**
     * Convert display time to 24-hour format
     */
    private String convertTo24Hour(String displayTime) {
        if (displayTime == null) return "";

        try {
            String[] parts = displayTime.split(" ");
            String time = parts[0];
            String ampm = parts[1];

            String[] timeParts = time.split(":");
            int hour = Integer.parseInt(timeParts[0]);
            String minute = timeParts[1];

            if (ampm.equals("PM") && hour != 12) {
                hour += 12;
            } else if (ampm.equals("AM") && hour == 12) {
                hour = 0;
            }

            return String.format("%02d:%s", hour, minute);
        } catch (Exception e) {
            return displayTime; // Return original if parsing fails
        }
    }

    /**
     * Update status label
     */
    private void updateStatusLabel(String message) {
        if (statusLabel != null) {
            statusLabel.setText(message);
        }
    }

    /**
     * Find course by course code
     */
    private clientS_course findCourseByCode(String courseCode) {
        if (student == null || student.getEnrolledCourses() == null) return null;

        for (clientS_course course : student.getEnrolledCourses()) {
            if (course.getCourseCode().equals(courseCode)) {
                return course;
            }
        }
        return null;
    }

    /**
     * Find date object by date string
     */
    private clientS_date findDateByString(String dateString) {
        if (student == null || student.getDates() == null) return null;

        for (clientS_date date : student.getDates()) {
            if (date.getDate().equals(dateString)) {
                return date;
            }
        }
        return null;
    }

    /**
     * Show alert dialog
     */
    private void showAlert(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Clear form fields
     */
    private void clearForm() {
        dateChooseBox.setValue(null);
        courseChooseBox.setValue(null);
        startTimeChooseBox.setValue(null);
        endTimeChooseBox.setValue(null);
        locationField.clear();
    }

    /**
     * Handle submit button action
     */
    @FXML
    private void handleSubmit() {
        try {
            // Validate input
            if (!validateInput()) {
                return;
            }

            // Get selected values
            String selectedDate = dateChooseBox.getValue();
            String selectedCourseCode = courseChooseBox.getValue();
            String selectedStartTime = startTimeChooseBox.getValue();
            String selectedEndTime = endTimeChooseBox.getValue();
            String location = locationField.getText();

            // Convert time to 24-hour format
            String startTime24 = convertTo24Hour(selectedStartTime);
            String endTime24 = convertTo24Hour(selectedEndTime);

            // Find the course object
            clientS_course selectedCourse = findCourseByCode(selectedCourseCode);

            // Create new exam schedule with default exam topic as "Exam"
            clientS_examSchedule newExamSchedule = new clientS_examSchedule(
                    selectedCourse, location, startTime24, endTime24, "Exam"
            );

            // Find the date and add the exam schedule
            clientS_date targetDate = findDateByString(selectedDate);
            if (targetDate != null) {
                if (targetDate.getExamSchedules() == null) {
                    targetDate.setExamSchedules(new ArrayList<>());
                }
                targetDate.addExamSchedule(newExamSchedule);

                updateStatusLabel("Exam schedule added successfully!");

                // Refresh the exam routine table and statistics
                countExamSchedules();
                createExamRoutineTable();

                // Clear the form
                clearForm();

              //  updateStatusLabel("Added exam schedule successfully");

            } else {
                updateStatusLabel("Error: Selected date not found");
                showAlert(Alert.AlertType.ERROR, "Error", "Date Not Found",
                        "The selected date could not be found in the system.");
            }

        } catch (Exception e) {
            updateStatusLabel("Error: Failed to add exam schedule");
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to Add Exam Schedule",
                    "An error occurred while adding the exam schedule: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Validate form input
     */
    private boolean validateInput() {
        if (dateChooseBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "Date Required",
                    "Please select an exam date.");
            return false;
        }

        if (courseChooseBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "Course Required",
                    "Please select a course code.");
            return false;
        }

        if (startTimeChooseBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "Start Time Required",
                    "Please select a start time.");
            return false;
        }

        if (endTimeChooseBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "End Time Required",
                    "Please select an end time.");
            return false;
        }

        if (locationField.getText() == null || locationField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "Location Required",
                    "Please enter an exam location.");
            return false;
        }

        // Validate time logic
        String startTime = convertTo24Hour(startTimeChooseBox.getValue());
        String endTime = convertTo24Hour(endTimeChooseBox.getValue());

        if (startTime.compareTo(endTime) >= 0) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "Invalid Time Range",
                    "End time must be after start time.");
            return false;
        }

        return true;
    }

    /**
     * Handle back to routine button action
     */
    @FXML
    private void handleBackToRoutine() {
        try {
            // Navigate back to exam routine view (you'll need to create this FXML)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CRExamRoutine.fxml"));
            Scene scene = new Scene(loader.load());

            // Assuming you have a CRExamRoutineController
             CRExamRoutineController controller = loader.getController();
             controller.setStage(stage);
             controller.initStudent(student);

            stage.setTitle("Student Exam Routine");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Navigation Error",
                    "Could not navigate back to exam routine view.");
        }
    }

    /**
     * Handle clear form button action
     */
    @FXML
    private void handleClearForm() {
        clearForm();
        updateStatusLabel("Form cleared");
    }

    /**
     * Handle exit button action
     */
    @FXML
    private void handleExit() {
        // Create a confirmation dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Application");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("This will close the Student Exam Routine Management System.");

        // Customize the buttons
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

        // Show the dialog and wait for user response
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.YES) {
            ClientConnection conn = ClientConnection.getInstance();
            conn.close();
            // Close the application
            Platform.exit();
            System.exit(0);
        }
    }

    /**
     * Create and populate the exam routine table
     */
    private void createExamRoutineTable() {
        examRoutineTable.getChildren().clear();

        // Create header row
        createHeaderRow();

        // Create data rows
        if (student != null && student.getDates() != null) {
            createDataRows(student.getDates());
        } else {
            // Create sample data for testing
            createSampleDataRows();
        }
    }

    /**
     * Create table header with time slots
     */
    private void createHeaderRow() {
        // Date & Day header
        Label dateHeader = new Label("Date & Day");
        dateHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
        dateHeader.setAlignment(Pos.CENTER);
        dateHeader.setPrefWidth(120);
        dateHeader.setPrefHeight(40);
        dateHeader.setStyle(dateHeader.getStyle() + "-fx-background-color: #f0f0f0; -fx-border-color: #ccc; -fx-border-width: 1px;");

        examRoutineTable.add(dateHeader, 0, 0);

        // Time slot headers
        for (int i = 0; i < timeSlots.length; i++) {
            Label timeHeader = new Label(timeSlots[i]);
            timeHeader.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: #333;");
            timeHeader.setAlignment(Pos.CENTER);
            timeHeader.setPrefWidth(80);
            timeHeader.setPrefHeight(40);
            timeHeader.setStyle(timeHeader.getStyle() + "-fx-background-color: #ffebee; -fx-border-color: #ccc; -fx-border-width: 1px;");

            examRoutineTable.add(timeHeader, i + 1, 0);
        }
    }

    /**
     * Create data rows from student's date entries
     */
    private void createDataRows(List<clientS_date> dateEntries) {
        int rowIndex = 1;

        for (clientS_date dateEntry : dateEntries) {
            // Date and day column
            VBox dateBox = createDateColumn(dateEntry.getDate());
            examRoutineTable.add(dateBox, 0, rowIndex);

            // Time slot columns
            for (int timeIndex = 0; timeIndex < timeHours.length; timeIndex++) {
                int currentHour = timeHours[timeIndex];
                Pane examCell = createExamScheduleCell(dateEntry, currentHour);
                examRoutineTable.add(examCell, timeIndex + 1, rowIndex);
            }

            rowIndex++;
        }
    }

    /**
     * Create sample data rows for testing
     */
    private void createSampleDataRows() {
        String[] sampleDates = {"2025-07-14", "2025-07-15", "2025-07-16"};

        for (int i = 0; i < sampleDates.length; i++) {
            VBox dateBox = createDateColumn(sampleDates[i]);
            examRoutineTable.add(dateBox, 0, i + 1);

            // Create some sample exam cells
            for (int timeIndex = 0; timeIndex < timeHours.length; timeIndex++) {
                Pane cell = new Pane();
                cell.setPrefWidth(80);
                cell.setPrefHeight(50);
                cell.setStyle("-fx-background-color: white; -fx-border-color: #ccc; -fx-border-width: 1px;");

                // Add sample exam data
                if (i == 0 && timeIndex == 1) { // 9 AM on first day
                    createSampleExamCell(cell, "CSE105", "Room-306", "Mid-term");
                } else if (i == 1 && timeIndex == 3) { // 11 AM on second day
                    createSampleExamCell(cell, "CSE114", "Room-301", "Final");
                }

                examRoutineTable.add(cell, timeIndex + 1, i + 1);
            }
        }
    }

    /**
     * Create date column with date and day name
     */
    private VBox createDateColumn(String dateString) {
        VBox dateBox = new VBox();
        dateBox.setAlignment(Pos.CENTER);
        dateBox.setPrefWidth(120);
        dateBox.setPrefHeight(50);
        dateBox.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #ccc; -fx-border-width: 1px;");

        try {
            LocalDate date = LocalDate.parse(dateString);

            Label dayLabel = new Label(date.getDayOfWeek().toString());
            dayLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");

            Label dateLabel = new Label(date.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")));
            dateLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #666;");

            dateBox.getChildren().addAll(dayLabel, dateLabel);
        } catch (Exception e) {
            Label errorLabel = new Label("Invalid Date");
            dateBox.getChildren().add(errorLabel);
        }

        return dateBox;
    }

    /**
     * Create exam schedule cell for specific time slot
     */
    private Pane createExamScheduleCell(clientS_date dateEntry, int hour) {
        Pane cell = new Pane();
        cell.setPrefWidth(80);
        cell.setPrefHeight(50);

        // Check for exam schedule
        clientS_examSchedule examSchedule = findExamScheduleForHour(dateEntry.getExamSchedules(), hour);
        if (examSchedule != null) {
            createExamContent(cell, examSchedule.getCourse().getCourseCode(),
                    examSchedule.getLocation());
            return cell;
        }

        // Empty cell
        cell.setStyle("-fx-background-color: white; -fx-border-color: #ccc; -fx-border-width: 1px;");
        return cell;
    }

    /**
     * Find exam schedule that includes the given hour
     */
    private clientS_examSchedule findExamScheduleForHour(List<clientS_examSchedule> examSchedules, int hour) {
        if (examSchedules == null) return null;

        for (clientS_examSchedule examSchedule : examSchedules) {
            try {
                int startHour = Integer.parseInt(examSchedule.getStartTime().split(":")[0]);
                int endHour = Integer.parseInt(examSchedule.getEndTime().split(":")[0]);

                if (hour >= startHour && hour < endHour) {
                    return examSchedule;
                }
            } catch (Exception e) {
                // Handle parsing errors
            }
        }
        return null;
    }

    /**
     * Create content for exam cell
     */
    private void createExamContent(Pane cell, String courseCode, String location) {
        VBox content = new VBox();
        content.setAlignment(Pos.CENTER);
        content.setPrefWidth(80);
        content.setPrefHeight(50);

        // Set background color - using a standard exam color since no topic differentiation
        String backgroundColor = "#b300b3"; // Red for all exams
        content.setStyle("-fx-background-color: " + backgroundColor + "; -fx-border-color: #ccc; -fx-border-width: 1px;");

        Label courseLabel = new Label(courseCode);
        courseLabel.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 10px;");

        Label locationLabel = new Label(location);
        locationLabel.setStyle("-fx-text-fill: white; -fx-font-size: 8px;");

        Label examLabel = new Label("CT");
        examLabel.setStyle("-fx-text-fill: yellow; -fx-font-weight: bold; -fx-font-size: 8px;");

        content.getChildren().addAll(courseLabel, locationLabel, examLabel);
        cell.getChildren().add(content);
    }

    /**
     * Create sample exam cell for testing
     */
    private void createSampleExamCell(Pane cell, String courseCode, String location, String examType) {
        // For sample cells, we'll just use the simplified version without examTopic
        createExamContent(cell, courseCode, location);
    }

    /**
     * Refresh the exam routine table (can be called when data is updated)
     */
    public void refreshExamRoutineTable() {
        createExamRoutineTable();
    }
}