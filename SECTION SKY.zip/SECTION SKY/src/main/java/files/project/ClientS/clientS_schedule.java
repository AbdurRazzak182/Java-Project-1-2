package files.project.ClientS;

import java.io.Serializable;

public class clientS_schedule implements Serializable {
    private static final long serialVersionUID = 1L;

    private String location;
    private clientS_course course;
    private String startTime;
    private String endTime;
    private boolean isOpen;

    // Default constructor
    public clientS_schedule() {
        this.location = "";
        this.course = null;
        this.startTime = "";
        this.endTime = "";
        this.isOpen = true;
    }

    // Parameterized constructor
    public clientS_schedule( clientS_course course, String startTime, String endTime,String location) {
        this.location = location;
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isOpen = true;
    }

    public clientS_schedule( clientS_course course, String startTime, String endTime,String location,boolean isOpen) {
        this.location = location;
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isOpen = isOpen;
    }

    // Getters and Setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public clientS_course getCourse() {
        return course;
    }

    public void setCourse(clientS_course course) {
        this.course = course;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public boolean status() {
        return isOpen;
    }

    public void setStatus(boolean open) {
        // System.out.println("has finished");
        this.isOpen = open;
    }
}
