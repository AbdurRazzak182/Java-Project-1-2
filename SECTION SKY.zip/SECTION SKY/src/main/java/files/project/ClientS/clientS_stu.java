package files.project.ClientS;

import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;

public class clientS_stu implements Serializable {
    private static final long serialVersionUID = 1L; // recommended for Serializable

    private String name,id;
    private String departmentName; // department name
    private List<clientS_course> enrolledCourses;
    private List<clientS_date> dates;
    private int level, term;

    // Constructor
    public clientS_stu() {
        this.enrolledCourses = new ArrayList<>();
        this.dates=new ArrayList<>();
        name="";
    }

    public clientS_stu(String id,String name,String departmentName,int level,int term){
        this.id=id;
        this.name=name;
        this.departmentName=departmentName;
        this.level=level;
        this.term=term;
        this.enrolledCourses = new ArrayList<>();
        this.dates=new ArrayList<>();
    }
    public List<clientS_date> getDates() {
        return dates;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName(){return name;}
    public void setName(String name){this.name=name;}
    public void setDates(List<clientS_date> dates){
        this.dates=dates;
    }

    public void addDate(clientS_date date){
        if(date!=null){
            dates.add(date);
        }
    }
    // Getter and Setter for departmentName
    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    // Getter and Setter for enrolledCourses
    public List<clientS_course> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(List<clientS_course> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }

    // Add a single course
    public void addCourse(clientS_course course) {
        if (course != null) {
            enrolledCourses.add(course);
        }
    }

    // Remove a single course
    public void removeCourse(clientS_course course) {
        enrolledCourses.remove(course);
    }

    // Getter and Setter for level
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    // Getter and Setter for term
    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }
}
