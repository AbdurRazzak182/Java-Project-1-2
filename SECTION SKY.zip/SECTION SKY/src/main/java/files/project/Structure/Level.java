package files.project.Structure;

import java.util.List;
import java.util.ArrayList;

public class Level {
    List<Term> terms;

    public Level(){
        terms=new ArrayList<>(2);
        for(int i=0;i<2;i++) terms.add(new Term());
    }

    // give input 1 or 2
    public Term getTerm(int nth){
        try{
            return terms.get(nth-1);
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Error: "+e.getMessage());
            return null;
        }
    }

    public List<Term> getTerms(){
        return terms;
    }
}