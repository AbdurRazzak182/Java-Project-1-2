package files.project.Structure;


public class examSchedule {
    private String location;
    private Course course;
    private String startTime;
    private String endTime;
    private String examTopic;

    // Constructor
    public examSchedule(Course course, String startTime, String endTime, String location) {
        this.course = course;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
        examTopic="";
    }

    // Getters
    public Course getCourse() {
        return course;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getLocation() {
        return location;
    }

    // Setters
    public void setCourse(Course course) {
        this.course = course;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setExamTopic(String topic){
        this.examTopic=topic;
    }
    public String getExamTopic(){
        return examTopic;
    }
}
