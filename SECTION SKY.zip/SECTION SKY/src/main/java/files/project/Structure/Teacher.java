package files.project.Structure;
import java.util.List;
import java.util.ArrayList;

public class Teacher extends Person{
    private String department;
    private List<Course> assignedCourses;
    // Constructors, getters, setters


    public Teacher() {
        super();
        assignedCourses=new ArrayList<>();
    }

    public Teacher(String name,String id,String password, String deptName) {
        super(name,id,password);
        this.department = deptName;
        assignedCourses=new ArrayList<>();
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    // Getters and setters for assignedCourses
    public List<Course> getAssignedCourses() {
        return assignedCourses;
    }

    public void setAssignedCourses(List<Course> assignedCourses) {
        this.assignedCourses = assignedCourses;
    }

    public boolean addCourse(Course course) {
        if (course != null && !assignedCourses.contains(course)) {
            assignedCourses.add(course);
            course.setInstructor(this);
            return true;
        }
        return false;
    }
    public boolean removeCourse(Course course){
        if(course!=null && assignedCourses.contains(course)){
            assignedCourses.remove(course);
            course.setInstructor(null);
            return true;
        }
        return false;
    }
}