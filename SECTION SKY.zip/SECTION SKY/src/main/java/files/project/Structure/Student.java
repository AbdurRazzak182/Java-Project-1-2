package files.project.Structure;
import java.util.List;
import java.util.ArrayList;

public class Student extends Person{
    private String departmentName;// department name
    private List<Course> enrolledCourses;
    private int level,term;


    public Student(String name, String id,String password,String deptName,int level,int term) {
        super(name,id,password);
        this.departmentName = deptName;
        this.level=level;
        this.term=term;
        enrolledCourses=new ArrayList<>();
    }

    public Student() {
        super();
        enrolledCourses=new ArrayList<>();
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }
    public int getTerm() {
        return term;
    }
    public void setTerm(int term) {
        this.term = term;
    }
    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(List<Course> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }

    public void addCourse(Course course){
        if(course!=null){
            enrolledCourses.add(course);
            course.addStudent(this);
        }
    }
}
