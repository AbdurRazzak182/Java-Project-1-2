package files.project.Structure;

public class CR extends Student{
    public CR(String name, String id,String password,String deptName,int level,int term) {
        super(name,id,password,deptName,level,term);
    }
}
