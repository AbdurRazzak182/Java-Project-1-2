package files.project.Structure;

public class Authority {
    private Varsity handleVarsity;
    private String varifyID="Buet-1962";
    private String password="#@Buet1962";
    public Authority(){
        handleVarsity=null;
    }

    public Authority(Varsity varsity){
        if(varsity!=null){
            this.handleVarsity=varsity;
        }
    }
    public boolean verify(String id, String pass) {
        return this.varifyID.equals(id) && this.password.equals(pass);
    }
    public String getId(){return varifyID;}

    public Varsity getVarsity(String id, String pass) {
        if (this.varifyID.equals(id) && this.password.equals(pass)) {
            return handleVarsity;
        }
        System.out.println("Unauthorized access attempt!");
        return null;
    }
    public boolean modifyPassword(String varifyID,String previousPassword,String newPassword){
        if(this.varifyID.equals(varifyID) && this.password.equals(previousPassword)){
            this.password=newPassword;
            return true;
        }
        return false;
    }
    public String getPassword(){
        return password;
    }
}