package files.project.Structure;


import java.util.List;
import java.util.ArrayList;

public class Department {
    private String name;
    private String deptCode;
    private List<Teacher> teachers;
    private List<Level> levels;


    public Department() {
        teachers = new ArrayList<>();
        levels = new ArrayList<>(4);
    }

    public Department(String name,String deptCode) {
        this.name = name;
        this.deptCode=deptCode;
        teachers = new ArrayList<>();
        levels = new ArrayList<>(4);// 4 level only
        for(int i=0;i<4;i++) levels.add(new Level());
    }
    public Department(String name) {
        this.name = name;
        this.deptCode="null";
        teachers = new ArrayList<>();
        levels = new ArrayList<>(4);// 4
        // level only
        for(int i=0;i<4;i++) levels.add(new Level());
    }
    public String getDeptCode(){
        return deptCode;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public List<Teacher> getTeachers() {
        return teachers;
    }
    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public List<Level> getLevels() {
        return levels;
    }
    public void setLevels(List<Level> levels) {
        this.levels = levels;
    }
    public boolean addTeacher(Teacher teacher) {
        if (teacher != null && !teachers.contains(teacher)) {// here we checking if teacher is really a valid object
            teachers.add(teacher);
            return true;
        }
        return false;
    }

    public Level getLevel(int nth){
        try {
            return levels.get(nth-1);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: "+e.getMessage());
            return null;
        }
    }
    public boolean removeTeacher(Teacher teacher){
        if(teacher!=null && teachers.contains(teacher)){
            teachers.remove(teacher);
            return true;
        }
        return false;
    }
}