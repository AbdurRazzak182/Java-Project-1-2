package files.project;


import java.io.*;
import java.net.Socket;

public final class ClientConnection {
    private static ClientConnection INSTANCE;
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    private ClientConnection() {}

    public static synchronized ClientConnection getInstance() {
        if (INSTANCE == null) INSTANCE = new ClientConnection();
        return INSTANCE;
    }

    public void connect(String host, int port) throws IOException {
        if (socket != null && socket.isConnected()) return;
        socket = new Socket(host, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(socket.getInputStream());
    }

    public synchronized void send(String msg) throws IOException {
        out.writeObject(msg);
        out.flush();
    }

    /** Read next object raw. */
    public synchronized Object receiveObject() throws IOException, ClassNotFoundException {
        return in.readObject();
    }

    /** Convenience: read expecting String; returns null if not String. */
    public synchronized String receiveString() throws IOException, ClassNotFoundException {
        Object o = receiveObject();
        return (o instanceof String s) ? s : null;
    }

    public void close() {
        try { if (in != null) in.close(); } catch (IOException ignored) {}
        try { if (out != null) out.close(); } catch (IOException ignored) {}
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
    }
}