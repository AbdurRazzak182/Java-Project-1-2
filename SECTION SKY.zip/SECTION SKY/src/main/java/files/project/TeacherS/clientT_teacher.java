package files.project.TeacherS;

import java.io.Serializable;
import java.util.List;

public class clientT_teacher implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String dept;
    private List<clientT_course> assignCourses;
    private List<clientT_date> assignCourse;


}
